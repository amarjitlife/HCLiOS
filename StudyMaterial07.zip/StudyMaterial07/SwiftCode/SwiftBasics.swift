//___________________________________________________________

/*
Command To Compile Code
swiftc SwiftBasics.swift -o basics

Command To Run Code
./basics
*/

//___________________________________________________________

print("Hello World!")

let greeting = "Hello World!!!" // Default Type Is String
print( greeting )

let someNumber = 999   // Default Type Is Int 
print( someNumber )

let someNumberAgain = 999.99 // Default Type Is Double
print( someNumberAgain )

// error: cannot assign to value: 'someNumber' is a 'let' constant
// Identifiers Created With let Are IMMUTABLE In Nature
// someNumber = 100 
// print( someNumber )

// Creating MUTABLE Identifier Using var
var someNumber1 = 999  // Default Type Is Int
print( someNumber1 )

someNumber1 = 100
print( someNumber1 )

//___________________________________________________________

// Following Two Lines Of Code Are Equivalent
// Implicitly Assigned Type Int
let implicitInteger 		= 70
// Explicitly Annotated With Type Int
let explicitInteger: Int 	= 70

// Following Two Lines Of Code Are Equivalent
// Implicitly Assigned Type Double
let implicitDouble 			= 70.90
// Explicitly Annotated With Type Double
let explicitDouble: Double  = 70.90

print( implicitInteger )
print( explicitInteger )
print( implicitDouble )
print( explicitDouble )

//_____________________________


// error: type annotation missing in pattern
// let something
// print( something )

let something: Int
// error: constant 'something' used before being initialized
something = 99
print( something )

// Implicitly Assigned Type Double
let someValue = 90.90
print( someValue )

// Explicitly Annotated With Type Float
let someValue1: Float = 90.90
print( someValue1 )

// BEST PRACTICE
// All Variables/Constants Created Must Be Initialised

//___________________________________________________________
//
// EXPLICIT TYPE CASTING
//___________________________________________________________

// NOTE: In Swift
// 		Values are NEVER Implicitly Converted To Another Type.

let label = "The width is "
let width = 94

// error: binary operator '+' cannot be applied to operands of 
// type 'String' and 'Int
// let widthLabel = label + width

// Require Explicit Type Cast To String Type
let widthLabel = label + String( width )

print( widthLabel )

//___________________________________________________________
//
// STRING INTERPOLATION
//___________________________________________________________

let apples = 3
let oranges = 5 

// apples Value Getting Substituted In String
let appleSummary = " I Have \(apples) apples"

// (apples + organges) Calcualted Value Getting Substituted In String
let fruitSummary = " I Have \( apples + oranges ) pieces of fruits"

print( appleSummary )
print( fruitSummary )

let century: Int = 100
let name = "Virat Kohli"

let centuryName = "\(name) Likes The Number \(century)s"

print( centuryName )

//___________________________________________________________
//
// DEFINING MULTIPLE VALUES WITH DEFINITION
//___________________________________________________________

let maximumNumberOfLoginAttempts = 10
var currentLoginAttempt = 0

var x = 0.0, y = 0.0, z = 0.0

print( maximumNumberOfLoginAttempts )
print( currentLoginAttempt )
print( x, y, z )

var welcomeMessage: String

// error: variable 'welcomeMessage' used before being initialized
welcomeMessage = "Good Evening!"
print( welcomeMessage )

//___________________________________________________________
//
// IDENTIFIERS CAN BE MADE OF UNICODE CHARACTERS
// EVEN STRING IN SWIFT ARE UNICODE STRINGS
//		UNICODE STRING MEANS EACH CHARACTER IS UNICODE CHARACTER
//___________________________________________________________

let pi = 3.14159
print( pi )

let π = 3.14159
print( π )

let 你好 = "你好世界"
let 🐶🐮 = "dogcow"

print( 你好 )
print( 🐶🐮 )

let नमस्ते = "Namsate : नमस्ते"
print( नमस्ते )

let vanakaam = "வணக்கம்"
print( vanakaam )

let playWithTamil = "கவனத்தை தன்பால் ஈர்க்கும் வியப்பிடைச் சொல்"
print( playWithTamil )

//___________________________________________________________
//
// USING SEMICOLON TO WRITE MULTIPLE STATEMENTS IN ONE LINE
//___________________________________________________________

// Following Both Codes Are Equivalent
let cat = "CAT "
print( cat )

let cat1 = "CAT " ; print( cat1 )

// Always Prefer Above Coding Style!

//___________________________________________________________
//
// INTERGER BOUNDS
//___________________________________________________________

let minValue = UInt8.min
let maxValue = UInt8.max

print( minValue, maxValue )
// 0 To 255

// Assume N is Number Of Bits i.e. 8, 19, 32, 64
// Signed Int8 :  -128 To 127
print( Int8.min, Int8.max ) // [ - 2 ^ ( N - 1 ) , 2 ^ ( N - 1 ) - 1]
// Unsigned Int8 :  0 To 255
print( UInt8.min, UInt8.max ) // [0, (2 ^ N) - 1  ]

// Signed Int16 : -32768 To 32767
print( Int16.min, Int16.max )

// Unsigned Int16: 0 To 65535
print( UInt16.min, UInt16.max )

// Signed Int32: -2147483648 To 2147483647
print( Int32.min, Int32.max )

// Unsigned Int32: 0 To 4294967295
print( UInt32.min, UInt32.max )

// Signed Int64: -9223372036854775808 To 9223372036854775807
print( Int64.min, Int64.max )

// Unsigned Int64: 0 To 18446744073709551615
print( UInt64.min, UInt64.max )

//___________________________________________________________
//
// INTEGERS IN DIFFERENT BASES Or NUMBER SYSTEMS
//___________________________________________________________


// Same Decimal Number System 17 Value Is Written In Differet Bases 
let decimalInteger = 17 	// Base 10
print( decimalInteger )

let binaryInteger = 0b10001 // Base 02
print( binaryInteger )

let octalInteger = 0o21 	// Base 08
print( octalInteger )

let hexadecimalInteger = 0x11 // Base 16
print( hexadecimalInteger)


//___________________________________________________________
//
// EXPLICIT TYPE CONVERSION
//___________________________________________________________

let three = 3
let fractionPart = 0.14159

// error: binary operator '+' cannot be applied to operands of type 'Int' and 'Double'
// let piAgain = three + fractionPart

let piAgain = Double( three )  + fractionPart
print( piAgain )

let integerPiAgain = Int( piAgain )
print( integerPiAgain )


//___________________________________________________________
//
// TYPE ALIASES
//___________________________________________________________

// Creating One More Name For Type UInt16
typealias AudioSample = UInt16

let music : AudioSample = 300
print( music )

typealias BowlingSpeed = UInt8

let saami: BowlingSpeed = 150 
print( saami )

let boomra: BowlingSpeed = 140 
print( boomra )

//___________________________________________________________
// 
// BOOLEAN TYPES
//___________________________________________________________


let orangesAreOrange = true
let turnipsAreDelicious = false

print( orangesAreOrange )
print( turnipsAreDelicious )

if turnipsAreDelicious {
	print("Tasty Turnips!!!")
} else {
	print("Tasteless Turnips!!!")
}

let value = 10

	// Boolean Expression : Expression Evaluates To true/false Value
if value == 10 {
	print(" It's TEN ")
} else {
	print(" It's NOT TEN")
}

//___________________________________________________________
//
// TUPLE TYPES
//___________________________________________________________

// Tuple Of 2 Values Of Int and String Type
let http404Error = ( 404, "Not Found" )

print( http404Error )

// Accessing Tuple Member Values
print( http404Error.0 )
print( http404Error.1 )

// Tuple Unpacking/Decluttering
//		Tuple Member Values Are Assigned To LHS Identifiers
let ( statusCode, statusMessage )  = http404Error 
print( "Status Code : \( statusCode )" )
print( "Status Message : \( statusMessage )" )

// Tuple Unpacking/Decluttering
//	Tuple Member Values Are Assigned To LHS Identifiers
//		Second Value Is Assigned To _ i.e. Variable To Be Ignored

let ( statusCodeAgain, _ )  = http404Error 
print( "Status Code : \( statusCodeAgain )" )

// Named Tuples 
// 	To Make Code More Readable

let http404ErrorAgain = (statusCode: 404, statusMessage: "Not Found")

print( http404ErrorAgain.0 )
print( http404ErrorAgain.1 )

print( http404ErrorAgain.statusCode )
print( http404ErrorAgain.statusMessage )

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

 

