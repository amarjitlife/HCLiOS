//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftEnumeration.swift -o enumeration

Command To Run Code
./enumeration
*/
//___________________________________________________________


//___________________________________________________________
//
// Enumerations
//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE RAISE YOUR HAND!!!

//	Enumerations: Used For Creating Related Constants

enum CompassPoint {
	case North
	case South
	case East
	case West 
}

enum Planet {
	case Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

var directionToHead 				= CompassPoint.West
var directionToHead1: CompassPoint  = .West

directionToHead = CompassPoint.East
directionToHead = .East

switch directionToHead {
	case .North:
		print("Going North")
	case .South:
		print("Going South")
	case .East:
		print("Going East")
	case .West:
		print("Going West")
}

let somePlanet = Planet.Earth

switch somePlanet {
case .Earth: 
	print("Liveable Planet!!!")
default:
	print("Not Liveable Planet!!!")	
}

//___________________________________________________________
//
// Enumerations With Associative Values
//___________________________________________________________

enum Barcode {
	// Associative Values
case UPCA( Int, Int, Int )
case QRCode( String )
}

var productBarCode = Barcode.UPCA( 10, 85909, 30 )
print( productBarCode )

switch productBarCode {
	// Associative Values Are Binded To Local Values To Access Them
case .UPCA( let numberSystem, let indentifier, let check):
	print( numberSystem, indentifier, check)
case .QRCode( let productCode ):
	print( productCode )
}

productBarCode = Barcode.QRCode("ABCEDEFGHI")
print( productBarCode )

switch productBarCode {
	// Associative Values Are Binded To Local Values To Access Them
case .UPCA( let numberSystem, let indentifier, let check):
	print( numberSystem, indentifier, check)
case .QRCode( let productCode ):
	print( productCode )
}

//___________________________________________________________
//
//
//___________________________________________________________

enum Colors {
case Wall(UInt8, UInt8, UInt8)
case Roof(UInt8, UInt8, UInt8)
case Floor(UInt8, UInt8, UInt8)
case Name( String )
case Brand( String, String, Int )
}

//___________________________________________________________
//
//
//___________________________________________________________

enum PlanetAgain : Int {
case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

print( PlanetAgain.Mercury )
print( PlanetAgain.Mercury.rawValue )

print( PlanetAgain.Earth )
print( PlanetAgain.Earth.rawValue )

let possiblePlanet = PlanetAgain( rawValue: 7 )
print( possiblePlanet! )

let positionToFind = 9

if let somePlanet = PlanetAgain( rawValue: positionToFind ) {
	switch somePlanet {
		case .Earth: 
			print("Liveable Planet!!!")
		default:
			print("Not Liveable Planet!!!")	
	}
} else {
	print( "There No Planet Found At 9th Position... Pluto We Already Kicked Out!")
}

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________


