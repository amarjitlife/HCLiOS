//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftNestedTypes.swift -o nested

Command To Run Code
./nested
*/
//___________________________________________________________

// Nested Types

// Swift enables you to define nested types, whereby you nest 
// supporting enumerations, classes, and structures within the 
// definition of the type they support.

// To nest a type within another type, write its definition within   
// the outer braces of the type it supports. Types can be nested 
// to as many levels as are required.

struct BlackjackCard {
    
    // nested Suit enumeration
    enum Suit: Character {
        case Spades = "♠", Hearts = "♡", Diamonds = "♢", Clubs = "♣"
    }
    
    // nestedRank enumeration
    enum Rank: Int {
        case Two = 2, Three, Four, Five, Six, Seven, Eight, Nine, Ten
        case Jack, Queen, King, Ace
        struct Values {
            let first: Int, second: Int?
        }
        var values: Values {
            switch self {
            case .Ace:
                return Values(first: 1, second: 11)
            case .Jack, .Queen, .King:
                return Values(first: 10, second: nil)
            default:
                return Values(first: self.rawValue, second: nil)
            }
        }
    }
    
    // BlackjackCard properties and methods
    let rank: Rank, suit: Suit
    var description: String {
        var output = "suit is \(suit.rawValue),"
        output += " value is \(rank.values.first)"
        if let second = rank.values.second {
            output += " or \(second)"
        }
        return output
    }
}

let theAceOfSpades = BlackjackCard(rank: .Ace, suit: .Spades)
print("theAceOfSpades: \(theAceOfSpades.description)")


// Referring to Nested Types
let heartsSymbol = BlackjackCard.Suit.Hearts.rawValue
print("heartsSymbol is \(heartsSymbol)")

//___________________________________________________________

class One {

    class OneInside {

    }

    struct TwoInside {

    }

    enum ThreeInside {

    }
}

struct Two {
    class OneInside {

    }

    struct TwoInside {

    }

    enum ThreeInside {

    }
}


//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
