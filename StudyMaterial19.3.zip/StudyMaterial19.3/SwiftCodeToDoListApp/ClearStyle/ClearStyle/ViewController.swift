//
//  ViewController.swift
//  ClearStyle
//
//  Created by XCode on 7/30/15.
//  Copyright (c) 2015 TechHue Systems. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, TableViewCellDelegate
{

    @IBOutlet weak var tableView: UITableView!
    var toDoItems = [ToDoItem]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(TableViewCell.self , forCellReuseIdentifier: "cell")
        tableView.backgroundColor = UIColor.black
        tableView.separatorStyle = .none
        tableView.rowHeight = 50.0
        if toDoItems.count > 0
        {
            return
        }
        
        toDoItems.append(ToDoItem(text: "feed the cat"))
        toDoItems.append(ToDoItem(text: "buy eggs"))
        toDoItems.append(ToDoItem(text: "watch WWDC videos"))
        toDoItems.append(ToDoItem(text: "rule the web"))
        toDoItems.append(ToDoItem(text: "buy a new iPhone"))
        toDoItems.append(ToDoItem(text: "darn holes in socks"))
        toDoItems.append(ToDoItem(text: "write this tutorial"))
        toDoItems.append(ToDoItem(text: "master swift"))
        toDoItems.append(ToDoItem(text: "learn to draw"))
        toDoItems.append(ToDoItem(text: "get more exercise"))
        toDoItems.append(ToDoItem(text: "catch up with mom"))
        toDoItems.append(ToDoItem(text: "get a hair cut"))
    }

    
    // MARK - Table view data source
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return toDoItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell",
            for: indexPath) as! TableViewCell
        let item = toDoItems[indexPath.row]
        //cell.textLabel?.text = item.text
        //cell.textLabel?.backgroundColor = UIColor.clearColor()
        cell.selectionStyle = .none
        cell.delegate = self
        cell.toDoItem = item
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return tableView.rowHeight
    }
    
    // Mark: TableViewCellDelegate
    
    func toDoItemDeleted(_ todoItem: ToDoItem) {
        let index = (toDoItems as NSArray).index(of: todoItem)
        if index == NSNotFound
        {
            return
        }
        
        // could removeAtIndex in the loop but keep it here for when indexOfObject works
        toDoItems.remove(at: index)
        
        // loop over the visible cells to animate delete
        let visibleCells = tableView.visibleCells as! [TableViewCell]
        let lastView = visibleCells[visibleCells.count - 1] as TableViewCell
        var delay = 0.0
        var startAnimating = false
        
        for i in 0..<visibleCells.count
        {
            let cell = visibleCells[i]
            if startAnimating
            {
                UIView.animate(withDuration: 0.3,
                    delay: delay,
                    options: UIView.AnimationOptions(),
                    animations: {() in
                        cell.frame = cell.frame.offsetBy(dx: 0.0,
                            dy: -cell.frame.size.height)},
                    completion: {(finished: Bool) in
                        if (cell == lastView)
                        {
                            self.tableView.reloadData()
                        }
                }
                )
                delay += 0.3
            }
            
            if cell.toDoItem === todoItem
            {
                startAnimating = true
                cell.isHidden = true
            }
        }
        
        // use the UITableView to animate the removal of this row
        tableView.beginUpdates()
        let indexPathForRow = IndexPath(row: index, section: 0)
        tableView.deleteRows(at: [indexPathForRow], with: .fade)
        tableView.endUpdates()
    }
    
    // Mark: - Table View delegate
    func colorForIndex(_ index: Int) -> UIColor
    {
        let itemCount = toDoItems.count
        let val = (CGFloat(index) / CGFloat(itemCount)) * 0.6
        return UIColor(red: 1.0, green: val, blue: 0.0, alpha: 1.0)
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    {
        cell.backgroundColor = colorForIndex(indexPath.row)
    }

}

