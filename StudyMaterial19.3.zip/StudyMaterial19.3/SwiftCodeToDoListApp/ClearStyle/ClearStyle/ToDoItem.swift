//
//  ToDoItem.swift
//  ClearStyle
//
//  Created by XCode on 7/30/15.
//  Copyright (c) 2015 TechHue Systems. All rights reserved.
//

import UIKit

class ToDoItem: NSObject
{
    // A text description of this item
    var text: String
    
    // A Boolean value that determines the completed state of this item
    var completed: Bool
    
    // Returns a ToDoItem initialized with the given text and default completed value.
    
    init(text: String)
    {
        self.text = text
        self.completed = false
    }
    
}
