// 
//  Copyright © 2020 Big Nerd Ranch
//

import Foundation

protocol MoodsConfigurable {
    func add(_ moodEntry: MoodEntry)
}
