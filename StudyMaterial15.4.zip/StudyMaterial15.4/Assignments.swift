
________________________________________________________________

DAY 01
________________________________________________________________

	Assignment A1: Prepare Enviornment
		Install Swift Compiler and Code Editors

	Assignment A2: Revise and Practice Topics Done In Class
		Practice Code Examples Till Now Done

________________________________________________________________

DAY 02
________________________________________________________________

	Assignment A1: Revise and Practice Topics Done In Class
		Practice and Revise Swift Code Examples Till Now Done

		├── StudyMaterial02
		│ ├── SwiftCode
		│ │ ├── Hello.swift
		│ │ ├── SwiftBasics.swift
		│ │ ├── SwiftCollections.swift
		│ │ ├── SwiftControlFlow.swift
		│ │ ├── SwiftOperators.swift
		│ │ └── SwiftStringsAndCharacters.swift

	Assignment A2: Reading Tutorials and Practice Code Assignment
		1. Read All Following Tutorials
			├── StudyMaterial02
			│ └── SwiftTutorials
			│     ├── SwiftTutorials01.pdf
			│     └── SwiftTutorials02.pdf
					
		2. Practice Code In Each Tutorials

		3. Solve All Challenges At The End Of Each Topic/Tutorials
			├── StudyMaterial02
			│ └── SwiftTutorials
			│     ├── SwiftTutorials01.pdf
	
		4. Solve All Challenges At The End Of Each Topic/Tutorials
			├── StudyMaterial02
			│ └── SwiftTutorials
			│     └── SwiftTutorials02.pdf

________________________________________________________________

DAY 03
________________________________________________________________

	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		├── StudyMaterial03
		    ├── SwiftCode
		    │ ├── Assignments.swift
		    │ ├── Experiments.class
		    │ ├── Experiments.java
		    │ ├── Hello.swift
		    │ ├── SwiftBasics.swift
		    │ ├── SwiftCollections.swift
		    │ ├── SwiftControlFlow.swift
		    │ ├── SwiftFunctions.swift
		    │ ├── SwiftOperators.swift
		    │ ├── SwiftOptionals.swift
		    │ ├── SwiftStringsAndCharacters.swift
		    │ └── SwiftTypes.swift
    

	Assignment A2: Reading Tutorials Assignment

		Read ALL Following Tutorials
			├── StudyMaterial03
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        └── SwiftTutorials04.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial03
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        └── SwiftTutorials04.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			├── StudyMaterial03
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			├── StudyMaterial03
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			├── StudyMaterial03
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			├── StudyMaterial03
			│     └── SwiftTutorials04.pdf


________________________________________________________________

DAY 04
________________________________________________________________

	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		└── StudyMaterial04
		    ├── SwiftCode
		    │ ├── Assignments.swift
		    │ ├── Experiments.java
		    │ ├── Hello.swift
		    │ ├── SwiftBasics.swift
		    │ ├── SwiftClosures.swift
		    │ ├── SwiftCollections.swift
		    │ ├── SwiftControlFlow.swift
		    │ ├── SwiftFunctions.swift
		    │ ├── SwiftOperators.swift
		    │ ├── SwiftOptionals.swift
		    │ ├── SwiftStringsAndCharacters.swift
		    │ └── SwiftTypes.swift
	
	Assignment A2: Reading Tutorials Assignment
	
		Read ALL Following Tutorials
			├── StudyMaterial04
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial04
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
				    ├── SwiftTutorials05.pdf
			        └── SwiftTutorials04.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials04.pdf

		5. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials05.pdf


	//___________________________________________________________
	// 
	// PROGRAMMING EXCERCISES
	//___________________________________________________________


	Programming Excercise 01 
		Write a function that computes the list of the first 100 
		Fibonacci numbers.  The first two Fibonacci numbers are 1 and 1. 
		The n+1-st Fibonacci number can  be computed by adding the 
		n-th and the n-1-th Fibonacci number. 

		The first few are therefore 1, 1, 1+1=2, 1+2=3, 2+3=5, 3+5=8.

	Programming Excercise 02
		Write A Function To Calculate Sum Of Digits
		Function Must Takes Any Integer As Argument and Returns The Sum Of Digits

	Programming Excercise 03
		Solve Following Problem
		https://leetcode.com/problems/letter-combinations-of-a-phone-number/


________________________________________________________________

DAY 05
________________________________________________________________

	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		└── StudyMaterial05
			├── SwiftCode
			│ ├── Assignments.swift
			│ ├── Experiments.java
			│ ├── Hello.swift
			│ ├── SwiftBasics.swift
			│ ├── SwiftClosures.swift
			│ ├── SwiftCollections.swift
			│ ├── SwiftControlFlow.swift
			│ ├── SwiftEnumeration.swift
			│ ├── SwiftFunctions.swift
			│ ├── SwiftMethods.swift
			│ ├── SwiftOperators.swift
			│ ├── SwiftOptionals.swift
			│ ├── SwiftStringsAndCharacters.swift
			│ ├── SwiftStructureAndClasses.swift
			│ └── SwiftTypes.swift

	Assignment A2: Reading Tutorials Assignment
	
		Read ALL Following Tutorials
			├── StudyMaterial05
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf				    
				    ├── SwiftTutorials06.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial05
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf
				    ├── SwiftTutorials06.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials04.pdf

		5. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials05.pdf

		6. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials06.pdf


________________________________________________________________

DAY 06
________________________________________________________________

	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		└── StudyMaterial06
			├── SwiftCode
			│ ├── Experiments.java
			│ ├── Hello.swift
			│ ├── SwiftBasics.swift
			│ ├── SwiftClosures.swift
			│ ├── SwiftCollections.swift
			│ ├── SwiftControlFlow.swift
			│ ├── SwiftEnumeration.swift
			│ ├── SwiftFunctions.swift
			│ ├── SwiftInheritance.swift
			│ ├── SwiftInitialisation.swift
			│ ├── SwiftMethods.swift
			│ ├── SwiftOperators.swift
			│ ├── SwiftOptionals.swift
			│ ├── SwiftStringsAndCharacters.swift
			│ ├── SwiftStructureAndClasses.swift
			│ ├── SwiftSubscript.swift
			│ └── SwiftTypes.swift

	Assignment A2: Reading Tutorials Assignment
	
		Read ALL Following Tutorials
			├── StudyMaterial06
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf				    
				    ├── SwiftTutorials06.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial06
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf
				    ├── SwiftTutorials06.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials04.pdf

		5. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials05.pdf

		6. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials06.pdf


________________________________________________________________

DAY 07
________________________________________________________________

	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		└── StudyMaterial07
			├── SwiftCode
			│ ├── Experiments.java
			│ ├── Experiments.swift
			│ ├── Hello.swift
			│ ├── SwiftBasics
			│ ├── SwiftBasics.swift
			│ ├── SwiftClosures.swift
			│ ├── SwiftCollections.swift
			│ ├── SwiftControlFlow.swift
			│ ├── SwiftDesinitialisers.swift
			│ ├── SwiftEnumeration.swift
			│ ├── SwiftErrorHandling.swift
			│ ├── SwiftExtensions.swift
			│ ├── SwiftFunctions.swift
			│ ├── SwiftInheritance.swift
			│ ├── SwiftInitialisation.swift
			│ ├── SwiftMethods.swift
			│ ├── SwiftNestedTypes.swift
			│ ├── SwiftOperators.swift
			│ ├── SwiftOptionalChaining.swift
			│ ├── SwiftOptionals.swift
			│ ├── SwiftStringsAndCharacters.swift
			│ ├── SwiftStructureAndClasses.swift
			│ ├── SwiftSubscript.swift
			│ ├── SwiftTypeCasting.swift
			│ ├── SwiftTypes.swift
			│ └── Test.swift

	Assignment A2: Reading Tutorials Assignment
	
		Read ALL Following Tutorials
			├── StudyMaterial07
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf
				    ├── SwiftTutorials06.pdf
				    ├── SwiftTutorials07.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial07
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf
				    ├── SwiftTutorials06.pdf
				    ├── SwiftTutorials07.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials04.pdf

		5. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials05.pdf

		6. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials06.pdf

		7. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials07.pdf


________________________________________________________________

DAY 08
________________________________________________________________

	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		└── StudyMaterial08
			├── SwiftCode
			    ├── Discusssions.swift
			    ├── Experiments.c
			    ├── Experiments.java
			    ├── Experiments.swift
			    ├── Hello.swift
			    ├── Human.swift
			    ├── SwiftBasics
			    ├── SwiftBasics.swift
			    ├── SwiftClosures.swift
			    ├── SwiftCollections.swift
			    ├── SwiftControlFlow.swift
			    ├── SwiftDesinitialisers.swift
			    ├── SwiftEnumeration.swift
			    ├── SwiftErrorHandling.swift
			    ├── SwiftExtensions.swift
			    ├── SwiftFunctions.swift
			    ├── SwiftInheritance.swift
			    ├── SwiftInitialisation.swift
			    ├── SwiftMethods.swift
			    ├── SwiftNestedTypes.swift
			    ├── SwiftOperators.swift
			    ├── SwiftOptionalChaining.swift
			    ├── SwiftOptionals.swift
			    ├── SwiftStringsAndCharacters.swift
			    ├── SwiftStructureAndClasses.swift
			    ├── SwiftSubscript.swift
			    ├── SwiftTypeCasting.swift
			    ├── SwiftTypes.swift
			    └── Test.swift


	Assignment A2: Reading Tutorials Assignment
	
		Read ALL Following Tutorials
			├── StudyMaterial08
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf				    
				    ├── SwiftTutorials06.pdf
				    ├── SwiftTutorials07.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial08
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf
				    ├── SwiftTutorials06.pdf
				    ├── SwiftTutorials07.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials04.pdf

		5. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials05.pdf

		6. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials06.pdf

		7. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials07.pdf


	Assignment A5: In Depth Reading Assignments
		
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/classesandstructures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/methods/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/subscripts/


________________________________________________________________

DAY 09
________________________________________________________________


	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		└── StudyMaterial09
			├── SwiftCode
			│ ├── Assignments.swift
			│ ├── Discusssions.swift
			│ ├── Experiments.c
			│ ├── Experiments.java
			│ ├── Experiments.swift
			│ ├── Hello.swift
			│ ├── Human.swift
			│ ├── SwiftBasics
			│ ├── SwiftBasics.swift
			│ ├── SwiftClosures.swift
			│ ├── SwiftCollections.swift
			│ ├── SwiftControlFlow.swift
			│ ├── SwiftDesinitialisers.swift
			│ ├── SwiftEnumeration.swift
			│ ├── SwiftErrorHandling.swift
			│ ├── SwiftExtensions.swift
			│ ├── SwiftFunctions.swift
			│ ├── SwiftInheritance.swift
			│ ├── SwiftInitialisation.swift
			│ ├── SwiftMethods.swift
			│ ├── SwiftNestedTypes.swift
			│ ├── SwiftOperators.swift
			│ ├── SwiftOptionalChaining.swift
			│ ├── SwiftOptionals.swift
			│ ├── SwiftProtocols.swift
			│ ├── SwiftStringsAndCharacters.swift
			│ ├── SwiftStructureAndClasses.swift
			│ ├── SwiftSubscript.swift
			│ ├── SwiftTypeCasting.swift
			│ ├── SwiftTypes.swift
			│ └── Test.swift

	Assignment A2: Reading Tutorials Assignment
	
		Read ALL Following Tutorials
			├── StudyMaterial09
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf				    
				    ├── SwiftTutorials06.pdf
				    ├── SwiftTutorials07.pdf
				    ├── SwiftTutorials08.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial09
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf				    
				    ├── SwiftTutorials06.pdf
				    ├── SwiftTutorials07.pdf
				    ├── SwiftTutorials08.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials04.pdf

		5. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials05.pdf

		6. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials06.pdf

		7. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials07.pdf

		8. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials08.pdf

	Assignment A5: In Depth Reading Assignments
		
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/classesandstructures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/methods/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/subscripts/

		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/extensions/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/protocols/#Declaring-Protocol-Adoption-with-an-Extension

________________________________________________________________

DAY 10
________________________________________________________________

	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		└── StudyMaterial10
			├── SwiftCode
			│ ├── Assignments.swift
			│ ├── Discusssions.swift
			│ ├── Experiments.c
			│ ├── Experiments.java
			│ ├── Experiments.swift
			│ ├── Hello.swift
			│ ├── Human.swift
			│ ├── MethodPrinter.java
			│ ├── SwiftAccessLevels.swift
			│ ├── SwiftBasics
			│ ├── SwiftBasics.swift
			│ ├── SwiftClosures.swift
			│ ├── SwiftCollections.swift
			│ ├── SwiftControlFlow.swift
			│ ├── SwiftDesinitialisers.swift
			│ ├── SwiftEnumeration.swift
			│ ├── SwiftErrorHandling.swift
			│ ├── SwiftExtensions.swift
			│ ├── SwiftFunctions.swift
			│ ├── SwiftGenertics.swift
			│ ├── SwiftInheritance.swift
			│ ├── SwiftInitialisation.swift
			│ ├── SwiftMethods.swift
			│ ├── SwiftNestedTypes.swift
			│ ├── SwiftOperators.swift
			│ ├── SwiftOperatorsOverloading.swift
			│ ├── SwiftOptionalChaining.swift
			│ ├── SwiftOptionals.swift
			│ ├── SwiftProtocols.swift
			│ ├── SwiftStringsAndCharacters.swift
			│ ├── SwiftStructureAndClasses.swift
			│ ├── SwiftSubscript.swift
			│ ├── SwiftTypeCasting.swift
			│ ├── SwiftTypes.swift
			│ └── Test.swift


	Assignment A2: Reading Tutorials Assignment

		Read ALL Following Tutorials
			├── StudyMaterial10
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf				    
				    ├── SwiftTutorials06.pdf
				    ├── SwiftTutorials07.pdf
				    ├── SwiftTutorials08.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial10
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf				    
				    ├── SwiftTutorials06.pdf
				    ├── SwiftTutorials07.pdf
				    ├── SwiftTutorials08.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials04.pdf

		5. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials05.pdf

		6. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials06.pdf

		7. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials07.pdf

		8. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials08.pdf

	Assignment A5: In Depth Reading Assignments
		
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/classesandstructures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/methods/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/subscripts/

		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/extensions/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/protocols/#Declaring-Protocol-Adoption-with-an-Extension

________________________________________________________________

DAY 11
________________________________________________________________

	Assignment A1: Explore Following iOS Sample Application Code 
			Understand And Reason Follwing Code!

			├── StudyMaterial10
				├── SampleApps
				│ ├── ObjectiveCCode
				│ │ └── 4.More User Interface Fun
				│ └── SwiftCode
				│     └── MoreUserInterfaceControls

	Assignment A2: In Depth iOS Guides Reading and Understanding Assignments
			Read and Understand First 40 Pages From Following Guides			
			Apple Guide: iPhone App Programming Guide


________________________________________________________________

DAY 12
________________________________________________________________

	Assignment A1: Explore Following iOS Sample Application Code 
			Understand And Reason Follwing Code!

			├── StudyMaterial12
			│ └── SampleApps
			│     ├── ObjectiveC
			│     │ └── ApplicationLifeCycle3
			│     └── SwiftCode
			│         ├── ApplicationLifeCycle1
			│         └── ApplicationLifeCycle3

			── StudyMaterial12.1
			│ └── SampleConcepts
			│     ├── ViewControllerLifeCycleObjectiveC
			│     └── ViewControllerLifeCycleSwift

			├── StudyMaterial12.2
			│ └── TableView
			│     ├── CountryList1
			│     ├── CountryList2
			│     ├── CountryList3
			│     ├── CountryList4
			│     └── CountryList5


	Assignment A2: In Depth iOS Guides Reading and Understanding Assignments
			Read and Understand First 60 Pages From Following Guides			
			Apple Guide: iPhone App Programming Guide

________________________________________________________________

DAY 13
________________________________________________________________

	Assignment A1: Explore Following iOS Sample Application Code 
		Understand And Reason Follwing Code!

			├── StudyMaterial13.1
			│ └── TableView
			│     ├── CountryList1
			│     ├── CountryList2
			│     ├── CountryList3
			│     ├── CountryList4
			│     └── CountryList5
			│     └── CountryList6
			│     └── CountryList7

			├── StudyMaterial13.2
			│ └── NavigationControllerSwift
			│ └── NavigationControllerObjectiveC

	Assignment A2: In Depth iOS Guides Reading and Understanding Assignments

		1. Read and Understand First 90 Pages From Apple TableView Programming Guide
				TableViewProgrammingGuide.pdf

	Assignment A3: Coding and Design TableViewController Swift Code 

			01 : Refactor CountryList Code To Incoporate MVC Architechture
			02 : Write Clean Model Classes
			03 : Implement Single Source Of Truth Design Principle In Your Code
			04 : Fix Add New Country Logic 

	Assignment A4: Coding and Design NavigationController Swift Code

			01 : Refactor CountryList Code To Incoporate MVC Architechture
			02 : Write Clean Model Classes
			03 : Implement Single Source Of Truth Design Principle In Your Code
			04 : Implement Don't Repeat Yourself (DRY) Practices

________________________________________________________________

DAY 14
________________________________________________________________

	Assignment A1: Explore Following iOS Sample Application Code 
		Understand And Reason Follwing Code!

			├── StudyMaterial14.1
			│ └── ViewControllerSwift
			│     ├── UIResponderChain
			│     └── ViewControllerPresenting
			
			├── StudyMaterial14.2
			│ └── ViewControllerObjectiveC
			│     ├── UIResponderChain
			│     └── ViewControllerPresenting
			
			├── StudyMaterial14.3
			│ ├── ViewControllerObjectiveC
			│ │ └── CustomViewController
			│ └── ViewControllerSwift
			│     └── CustomViewController

	Assignment A2: In Depth iOS Guides Reading and Understanding Assignments

		1. Read and Understand First 90 Pages From Apple TableView Programming Guide
				TableViewProgrammingGuide.pdf

	Assignment A3: Coding and Design TableViewController Swift Code 

			01 : Refactor CountryList Code To Incoporate MVC Architechture
			02 : Write Clean Model Classes
			03 : Implement Single Source Of Truth Design Principle In Your Code
			04 : Fix Add New Country Logic 

	Assignment A4: Coding and Design NavigationController Swift Code

			01 : Refactor CountryList Code To Incoporate MVC Architechture
			02 : Write Clean Model Classes
			03 : Implement Single Source Of Truth Design Principle In Your Code
			04 : Implement Don't Repeat Yourself (DRY) Practices

________________________________________________________________

DAY 15
________________________________________________________________

	Assignment A1: Explore Following iOS Sample Application Code 
		Understand And Reason Follwing Code!

			├── StudyMaterial14.1
			│ └── ViewControllerSwift
			│     ├── UIResponderChain
			│     └── ViewControllerPresenting
			
			├── StudyMaterial14.2
			│ └── ViewControllerObjectiveC
			│     ├── UIResponderChain
			│     └── ViewControllerPresenting
			
			├── StudyMaterial14.3
			│ ├── ViewControllerObjectiveC
			│ │ └── CustomViewController
			│ └── ViewControllerSwift
			│     └── CustomViewController

			├── StudyMaterial15.1
			│ └── UIGestureRecognizerSwift
			│     ├── UIGestureRecognizer1
			│     ├── UIGestureRecognizer2
			│     └── UIGestureRecognizer3
			├── StudyMaterial15.2
			│ └── UIGestureRecogniserObjectiveC
			│     ├── UIGestureRecognizer2
			│     └── UIGestureRecognizers1

			├── StudyMaterial15.3
			│ └── UIViewObjectiveC
			│     └── UIView1.Working
			│         ├── CALayerAnimation1
			│         ├── CustomShapeViews
			│         └── EventHandling1

	Assignment A2: In Depth iOS Guides Reading and Understanding Assignments

		1. Read and Understand Following Apple Programming Guide
				ViewControllerProgrammingGuide.pdf
				ViewProgrammibgGuideiPhoneOS.pdf

	Assignment A3: Coding and Design TableViewController Swift Code 

			01 : Refactor CountryList Code To Incoporate MVC Architechture
			02 : Write Clean Model Classes
			03 : Implement Single Source Of Truth Design Principle In Your Code
			04 : Fix Add New Country Logic 

	Assignment A4: Coding and Design NavigationController Swift Code

			01 : Refactor CountryList Code To Incoporate MVC Architechture
			02 : Write Clean Model Classes
			03 : Implement Single Source Of Truth Design Principle In Your Code
			04 : Implement Don't Repeat Yourself (DRY) Practices

________________________________________________________________

DAY 16
________________________________________________________________

	Assignment A4: Create Your Own Custom Navigation Controller
			By Subclassing UIViewController

________________________________________________________________

DAY 17
________________________________________________________________


________________________________________________________________

DAY 18
________________________________________________________________


________________________________________________________________
________________________________________________________________
________________________________________________________________
________________________________________________________________

