//
//  AddNameController.swift
//  prob
//
//  Created by XCode on 7/28/15.
//  Copyright (c) 2015 TechHue Systems. All rights reserved.
//

import UIKit

class AddNameController: UIViewController
{

    @IBOutlet weak var newName: UITextField!
    @IBOutlet weak var newEmailID: UITextField!
    @IBOutlet weak var newContactNO: UITextField!
    
    @IBOutlet var saveButton: UIBarButtonItem!
    @IBOutlet var cancelButton: UIBarButtonItem!
    
    var customer: Customer!
    var delegate: AddNameControllerDelegate!
    
    @IBAction func save(_ sender: AnyObject)
    {
        self.newName.resignFirstResponder()
        self.customer.name = newName.text!
        delegate.addNameController(self, selectedSave: true)
    }
    
    @IBAction func cancel(_ sender: AnyObject)
    {
        self.newName.resignFirstResponder()
        delegate.addNameController(self, selectedSave: false)
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?)
    {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }

    required init?(coder aDecoder: NSCoder)
    {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = "New Name"
        self.navigationItem.leftBarButtonItem = cancelButton
        self.navigationItem.rightBarButtonItem = saveButton
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

protocol AddNameControllerDelegate
{
    func addNameController(_ controller: AddNameController, selectedSave save: Bool)
}
