//
//  RootViewController.swift
//  prob
//
//  Created by XCode on 7/28/15.
//  Copyright (c) 2015 TechHue Systems. All rights reserved.
//

import UIKit
import Foundation
import CoreData

class RootViewController: UITableViewController, NSFetchedResultsControllerDelegate, AddNameControllerDelegate
{
    
    var fetchedResultsController: NSFetchedResultsController<NSFetchRequestResult>
    {
        if(self._fetchedResultsController != nil)
        {
            return self._fetchedResultsController!
        }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>()
        let entity = NSEntityDescription.entity(forEntityName: "Customer",
            in: self.managedObjectContext!)
        fetchRequest.entity = entity
        fetchRequest.fetchBatchSize = 20
        let sortDescriptor: NSSortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        let sortDescriptors: NSArray = NSArray(objects: sortDescriptor)
        fetchRequest.sortDescriptors = sortDescriptors as? [NSSortDescriptor]
        let aFetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest,
            managedObjectContext: self.managedObjectContext!,
            sectionNameKeyPath: nil,
            cacheName: "Root")
        aFetchedResultsController.delegate = self
        self._fetchedResultsController = aFetchedResultsController
        
        do
        {
            try self._fetchedResultsController!.performFetch()
        }
        catch let error as NSError
        {
            print("Unresolved error: \(error.localizedDescription) \(error.userInfo)")
            abort()
        }
        catch
        {
            print("Un caught error")
        }
        return self._fetchedResultsController!
    }
    
    var _fetchedResultsController: NSFetchedResultsController<NSFetchRequestResult>?
    
    var managedObjectContext: NSManagedObjectContext?
    
    convenience init()
    {
        self.init(nibName: nil, bundle: nil)
    }
    
    override init(style: UITableView.Style)
    {
        super.init(style: style)
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?)
    {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }

    required init(coder aDecoder: NSCoder)
    {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.title = "Customer List"

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        self.navigationItem.leftBarButtonItem = self.editButtonItem
        let addButton: UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.add,
            target: self, action: #selector(RootViewController.addCustomer))
        self.navigationItem.rightBarButtonItem = addButton
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int
    {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return self.fetchedResultsController.sections!.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        let sectionInfo: NSFetchedResultsSectionInfo = self.fetchedResultsController.sections![section] as NSFetchedResultsSectionInfo
        
        return sectionInfo.numberOfObjects
    }
    
    fileprivate func configureCell(_ cell: UITableViewCell, atIndexPath indexPath: IndexPath)
    {
        let managedObject: NSManagedObject = self.fetchedResultsController.object(at: indexPath)
         as! NSManagedObject
        cell.textLabel?.text = (managedObject.value(forKey: "name") as AnyObject).description
    }
    
    func addNameController(_ controller: AddNameController, selectedSave save: Bool)
    {
        if(!save)
        {
            self.fetchedResultsController.managedObjectContext.delete(controller.customer)
        }
        
        do
        {
            try self.fetchedResultsController.managedObjectContext.save()
        }
        catch let error as NSError
        {
            print("Unresolved error: \(error.localizedDescription) \(error.userInfo)")
            abort()
        }
        catch
        {
            print("Un caught error")
        }
        self.dismiss(animated: true , completion: nil)
        
    }
    
    override func setEditing(_ editing: Bool, animated: Bool)
    {
        super.setEditing(editing, animated: animated)
        self.navigationItem.rightBarButtonItem!.isEnabled = !editing
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let CellIdentifier: String = "Cell"
        var cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier as String) as UITableViewCell?
        
        if(cell == nil)
        {
            cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: CellIdentifier)
        }

        // Configure the cell...
        self.configureCell(cell!, atIndexPath: indexPath)

        return cell!
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return true
    }
    */
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let displayCustomerDetail: DisplayCustomerController = DisplayCustomerController(nibName: "DisplayCustomerController", bundle: nil)
        let selectedCustomer: Customer = self.fetchedResultsController.object(at: indexPath) as! Customer
        
        displayCustomerDetail.customer = selectedCustomer
        
        self.navigationController?.pushViewController(displayCustomerDetail, animated: true)
    }
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete
        {
            // Delete the row from the data source
            let context: NSManagedObjectContext = self.fetchedResultsController.managedObjectContext
            context.delete(self.fetchedResultsController.object(at: indexPath) as! NSManagedObject)
            
            do
            {
                try context.save()
            }
            catch let error as NSError
            {
                print("Unresolved error: \(error.localizedDescription) \(error.userInfo)")
                abort()
            }
            catch
            {
                print("Un caught error")
            }
        }
        else if editingStyle == .insert
        {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool
    {
        // Return NO if you do not want the item to be re-orderable.
        return false
    }
    
    @objc func addCustomer()
    {
        let addNameController: AddNameController = AddNameController(nibName: "AddNameController", bundle: nil)
        addNameController.delegate = self
        
        let customer = NSEntityDescription.insertNewObject(forEntityName: "Customer",
            into: self.fetchedResultsController.managedObjectContext) as! Customer
        addNameController.customer = customer
        
        let navController: UINavigationController = UINavigationController(rootViewController: addNameController)
        self.navigationController!.present(navController, animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>)
    {
        self.tableView.beginUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType)
    {
        switch(type)
        {
            case .insert:
                self.tableView.insertSections(IndexSet(integer: sectionIndex),
                    with: UITableView.RowAnimation.fade)
                break
            case .delete:
                self.tableView.deleteSections(IndexSet(integer: sectionIndex),
                    with: UITableView.RowAnimation.fade)
                break
            default:
                break
        }
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?)
    {
        let tableView: UITableView = self.tableView
        
        switch(type)
        {
            case .insert:
                tableView.insertRows(at: NSArray(object: newIndexPath!) as! [IndexPath],
                    with: UITableView.RowAnimation.fade)
                break
            case .delete:
                tableView.deleteRows(at: NSArray(object: indexPath!) as! [IndexPath],
                    with: UITableView.RowAnimation.fade)
                break
            case .update:
                let cell = self.tableView.cellForRow(at: indexPath!)
                self.configureCell(cell!, atIndexPath: indexPath!)
                self.tableView.reloadRows(at: NSArray(object: indexPath!) as! [IndexPath],
                    with: UITableView.RowAnimation.fade)
                break
            case .move:
                tableView.deleteRows(at: NSArray(object: indexPath!) as! [IndexPath],
                    with: UITableView.RowAnimation.fade)
                tableView.insertRows(at: NSArray(object: newIndexPath!) as! [IndexPath],
                    with: UITableView.RowAnimation.fade)
                break
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>)
    {
        self.tableView.endUpdates()
    }
    
    
}
