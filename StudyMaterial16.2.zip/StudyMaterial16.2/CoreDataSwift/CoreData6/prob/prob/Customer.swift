//
//  Customer.swift
//  prob
//
//  Created by XCode on 7/29/15.
//  Copyright (c) 2015 TechHue Systems. All rights reserved.
//

import Foundation
import CoreData

@objc(Customer)

class Customer: NSManagedObject
{

    @NSManaged var contactNo: String
    @NSManaged var emailID: String
    @NSManaged var name: String

}
