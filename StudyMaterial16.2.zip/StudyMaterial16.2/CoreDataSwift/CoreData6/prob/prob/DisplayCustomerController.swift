//
//  DisplayCustomerController.swift
//  prob
//
//  Created by XCode on 7/29/15.
//  Copyright (c) 2015 TechHue Systems. All rights reserved.
//

import UIKit

class DisplayCustomerController: UIViewController
{

    @IBOutlet weak var emailID: UITextField!
    @IBOutlet weak var contactNo: UITextField!
    @IBOutlet weak var name: UITextField!
    var customer: Customer!
    
    convenience init()
    {
        self.init(nibName: nil, bundle: nil)
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?)
    {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = "Customer Information"
        name.text = customer.name
        emailID.text = customer.emailID
        contactNo.text = customer.contactNo
        name.isEnabled = false
        emailID.isEnabled = false
        contactNo.isEnabled = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
