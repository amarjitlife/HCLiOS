//
//  ViewController.swift
//  CustomViewController
//
//  Created by Nagarajan on 8/27/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var contentView:UIView?
    var tabBarView:UIView?
    var firstTab:UIView?
    var secondTab:UIView?

    var firstTabController:     FirstTabController?
    var secondTabController:    SecondTabController?
    
    override func loadView() {
        super.loadView()
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.firstTabController  = FirstTabController()
        self.secondTabController = SecondTabController()

        configureContentView()
        configureTabBarView()
        configureFirstTabView()
        configureSecondTabView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func configureContentView()
    {
        self.contentView = UIView(frame: CGRect(x: self.view.bounds.origin.x,
            y: self.view.bounds.origin.y,
            width: self.view.bounds.size.width,
            height: self.view.bounds.size.height - 50))
        
        self.contentView!.backgroundColor = UIColor.brown
        
        self.view.addSubview(self.contentView!)
    }

    func configureTabBarView()
    {
        self.tabBarView = UIView(frame: CGRect(x: self.view.bounds.origin.x,
            y: self.view.bounds.size.height - 50,
            width: self.view.bounds.size.width,
            height: 50))
        self.tabBarView!.backgroundColor = UIColor.lightGray
        self.view.addSubview(self.tabBarView!)
    }

    func configureFirstTabView()
    {
        self.firstTab = UIView(frame: CGRect(x: self.tabBarView!.bounds.origin.x,
            y: self.tabBarView!.bounds.origin.y,
            width: self.tabBarView!.bounds.size.width/2,
            height: self.tabBarView!.bounds.size.height))
        
        self.firstTab!.backgroundColor = UIColor.orange
        
        let tabTitle = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 30))
        tabTitle.text = self.firstTabController!.title
        configureTitleLabel(tabTitle)
        self.firstTab!.addSubview(tabTitle)
        self.tabBarView!.addSubview(self.firstTab!)
        
        let singTap = UITapGestureRecognizer(target: self, action: #selector(ViewController.handleFirstTabGesture(_:)))
        singTap.numberOfTapsRequired = 1
        singTap.numberOfTouchesRequired = 1
        self.firstTab!.addGestureRecognizer(singTap)
    }
    
    func configureSecondTabView()
    {
        self.secondTab = UIView(frame: CGRect(x: self.tabBarView!.bounds.size.width/2,
            y: self.tabBarView!.bounds.origin.y,
            width: self.tabBarView!.bounds.size.width/2,
            height: self.tabBarView!.bounds.size.height))
        self.secondTab!.backgroundColor = UIColor.magenta
        
        let tabTitle = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 30))
        tabTitle.text = self.secondTabController!.title
        configureTitleLabel(tabTitle)
        self.secondTab!.addSubview(tabTitle)
        self.tabBarView!.addSubview(self.secondTab!)
        
        let singTap = UITapGestureRecognizer(target: self, action: #selector(ViewController.handleSecondTabGesture(_:)))
        singTap.numberOfTapsRequired = 1
        singTap.numberOfTouchesRequired = 1
        self.secondTab!.addGestureRecognizer(singTap)
    }
    
    
    func configureTitleLabel(_ label:UILabel)
    {
        label.textColor = UIColor.white
        label.font = UIFont.systemFont(ofSize: 14)
        label.textAlignment = NSTextAlignment.center
        label.backgroundColor = UIColor.clear
    }
    
    @objc func handleFirstTabGesture(_ recognizer: UITapGestureRecognizer) {
        self.secondTabController!.willMove(toParent: nil)
        self.secondTabController!.view.removeFromSuperview()
        self.secondTabController!.removeFromParent()
        
        self.addChild(self.firstTabController!)
 
        self.firstTabController!.view.frame = self.contentView!.frame
         
        self.contentView!.addSubview( self.firstTabController!.view )
        
        self.firstTabController!.didMove(toParent: self)
    }
    
    @objc func handleSecondTabGesture(_ recognizer:UITapGestureRecognizer) {
        self.firstTabController!.willMove(toParent: nil)
        self.firstTabController!.view.removeFromSuperview()
        self.firstTabController!.removeFromParent()
        
        self.addChild(self.secondTabController!)
        self.secondTabController!.view.frame = self.contentView!.frame
        
        self.contentView!.addSubview(self.secondTabController!.view)
        
        self.secondTabController!.didMove(toParent: self)
    }
}
