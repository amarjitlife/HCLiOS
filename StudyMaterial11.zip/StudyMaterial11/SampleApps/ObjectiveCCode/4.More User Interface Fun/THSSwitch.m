//
//  THSSwitch.m
//  4.More User Interface Fun
//
//  Created by naga on 1/5/14.
//  Copyright (c) 2014 TechHueSystems. All rights reserved.
//

#import "THSSwitch.h"

@implementation THSSwitch

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
