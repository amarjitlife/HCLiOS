
//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftClosures.swift -o closures

Command To Run Code
./closures
*/
//___________________________________________________________

//___________________________________________________________
//
// HIGHER ORDER FUNCTION
//___________________________________________________________

// Function Type
//		( Int, Int ) -> Int
func summation( first: Int, second: Int ) -> Int { return first + second }

// Function Type
//		( Int, Int ) -> Int
func substract( first: Int, second: Int ) -> Int { return first - second }

// Function Type
//		( Int, Int ) -> Int
func multiplication( first: Int, second: Int ) -> Int { return first * second }

// POLYMORPHIC FUNCTION

// HIGHER ORDER FUNCTION
//		FUNCTION TAKING FUNCTION AS ARGUMENT AND/OR RETURN FUNCTION

// Type Of Type Relation
//		(Int, Int, (Int, Int) -> ) -> Int
func calculator( first : Int, second: Int, operation: (Int, Int) -> Int ) -> Int {
	return operation( first, second )
}

func playWithCalculator() {
	let a = 40
	let b = 10

	var result = 0

	result = calculator( first: a, second: b, operation: summation )
	print( result )

	result = calculator( first: a, second: b, operation: substract )
	print( result )	

	result = calculator( first: a, second: b, operation: multiplication )
	print( result )	

	let something: (Int, Int) -> Int = summation
	result = something( 100, 200 )	
	print( result )	

	let somethingMore: (Int, Int, (Int, Int) -> Int ) -> Int = calculator
	result = somethingMore()
	print( result )	
}

playWithCalculator()


//___________________________________________________________
//
// CLOSURES/LAMBDAS
//___________________________________________________________

func playWithCalculatorAgain() {
	let a = 40
	let b = 10

	var result = 0

	// Lambdas Expressions Or Closures
	//		Simple Small Function Code
	
	// What Is The Data Type Of summationLambda, subtractLambda, multiplyLambda???
	//		(Int, Int) -> Int
	let summationLambda = { (first: Int, second: Int) -> Int in return first + second }
	let substractLambda = { (first: Int, second: Int) -> Int in return first - second }
	let multiplyLambda  = { (first: Int, second: Int) -> Int in return first * second }

	result = calculator( first: a, second: b, operation: summationLambda )
	print( result )

	result = calculator( first: a, second: b, operation: substractLambda )
	print( result )	

	result = calculator( first: a, second: b, operation: multiplyLambda )
	print( result )	

	result = calculator( first: a, second: b, operation: { 
		(first: Int, second: Int) -> Int in return first + second 
	})

	print( result )	
}

playWithCalculatorAgain()

//___________________________________________________________
//
// CLOSURE SYNTAX VARIATIONS
//___________________________________________________________

// Function Type
//		( String, String ) -> Bool
func backwards( first: String, second: String ) -> Bool {
	return first > second
}

// Function Type
//		( String, String ) -> Bool
func forwards( first: String, second: String ) -> Bool {
	return first < second
}

var names: [String] = ["Ram", "Rahim", "Shyam", "Kohli", "Anushaka", "Deepika"]
print( names )

names.sort( by: backwards )
print( names )

names.sort( by: forwards )
print( names )

names.sort( by: { (first: String, second: String) -> Bool in return first > second } )
print( names )

names.sort( by: { (first: String, second: String) -> Bool in return first < second } )
print( names )

// Swift Compiler Will Infer Types Of Arguments as Well As Return Type In Lambda/Closure
names.sort( by: { ( first, second ) in return first < second } )
print( names )

names.sort( by: { ( first, second ) in first < second } )
print( names )

names.sort( by: { $0 < $1 } )
print( names )

names.sort( by: < )
print( names )

//___________________________________________________________
//
// TRAILING LAMBDA/CLOSURE
//___________________________________________________________

// Following Function Takes LAST Argument As Of Function Type
//			Hence You Can Pass Either Function Or Lambda/Closure Of Function Type

// func calculator( first : Int, second: Int, operation: (Int, Int) -> Int ) -> Int {
// 		return operation( first, second )
// }

func playWithCalculatorOnceAgain() {
	let a = 40
	let b = 10

	var result = 0

	// Lambdas Expressions Or Closures
	//		Simple Small Function Code
	let summationLambda = { (first: Int, second: Int) -> Int in return first + second }
	let substractLambda = { (first: Int, second: Int) -> Int in return first - second }
	let multiplyLambda  = { (first: Int, second: Int) -> Int in return first * second }

	result = calculator( first: a, second: b, operation: summationLambda )
	print( result )

	result = calculator( first: a, second: b, operation: substractLambda )
	print( result )	

	result = calculator( first: a, second: b, operation: multiplyLambda )
	print( result )	

	result = calculator( first: a, second: b, operation: { 
		// (first: Int, second: Int) -> Int in return first + second 
		   (first, second) in first + second 
	} )

	print( result )	

	// TRAILING LAMBDA/CLOSURE SYNTAX
	//		If LAST Argument Is Lambda/Closure
	//			Than That Can Be Written Outside Of Function Call Paranthesis
	result = calculator( first: a, second: b ) { 
		// (first: Int, second: Int) -> Int in return first + second 
		(first , second) in first + second
	} 

	print( result )	

}

playWithCalculatorOnceAgain()


//___________________________________________________________
//
// MULTILINE LAMBDA/CLOSURE
//___________________________________________________________


// WHAT IS THE TYPE OF digitNames???

let digitsNames: [Int : String] = [0: "Zero", 1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five",6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"]

print( digitsNames )

let numbers = [16, 58, 510]

var words = numbers.map( {
	( number ) -> String in
	var number = number
	var output = ""

	while number > 0 {
		if let word = digitsNames[ number % 10 ] {
			output = word + output
		}
		number /= 10 			
	}

	return output
} )

print( words )

// Trailing Lambda/Closure Syntax
// Like map Is One Logic

words = numbers.map() { // Lambda Is Representing Extended Logic
	( number ) -> String in
	var number = number
	var output = ""

	while number > 0 {
		if let word = digitsNames[ number % 10 ] {
			output = word + output
		}
		number /= 10 			
	}

	return output
} 

print( words )


words = numbers.map { // Lambda Is Representing Extended Logic
	( number ) -> String in
	var number = number
	var output = ""

	while number > 0 {
		if let word = digitsNames[ number % 10 ] {
			output = word + output
		}
		number /= 10 			
	}

	return output
} 

print( words )

// func digitsToWords( numbers: [Int] ) -> String {

// } 


//___________________________________________________________
//
// FUNCTION TAKING MULTIPLE CLOSURES
//___________________________________________________________

func download( image: String, from: String) -> String? {
	print("Connecting To Server \(from)")
	print("Downloading \(image)...")

	return image
}

// Funtion Taking Two Lambdas/Closures
func loadPicture( 
	from: String, 
	completion: ( String ) -> (), 
	onFailure: () -> () 
) {
	if let picture = download(image: "India.png", from: from ) {
		// On Successful Download
		completion( picture ) // Calling Completion Handler 
	} else {
		// On UNSuccessful Download
		onFailure()
	}	
}

loadPicture( 
	from: "google.com", 
	completion: { (image) in print("Download Successful!") },
	onFailure:  { print("Download Failed... ") }
)

// Trailing Lambda Syntax
// If a function takes multiple closures, 
// you omit the argument label for the first trailing 
// closure and you label the remaining trailing closures

loadPicture( from: "google.com" ) { 
	(image) in print("Download Successful!") 
} onFailure: { 
	print("Download Failed... ") 
}


//___________________________________________________________
//
// Capturing Values
//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE RAISE YOUR HAND!!!

func makeIncrementor( forIncrement amount: Int ) -> () -> Int {
	// Local Variable To makeIncremetor Function
	var runningTotal = 0
	
	// Local/Nested Function
	//	It Captures The It's Copy Of runningTotal
	// 	Every Returned incrementor Will Have It's Own Copy
	func incrementor() -> Int {
		runningTotal += amount
		return runningTotal
	}

	return incrementor
}

var result = 0

// What Is Data Type of incrementByTen???
// Function Type
//		() -> Int

// incrementByTen Contains Function incrementor With It's Own Copy Of runningTotal
let incrementByTen = makeIncrementor( forIncrement: 10 )

result = incrementByTen()
print( result )

result = incrementByTen()
print( result )

result = incrementByTen()
print( result )

// Function Type
//		() -> Int

// incrementBySeven Contains Function incrementor With It's Own Copy Of runningTotal
let incrementBySeven = makeIncrementor( forIncrement: 7 )
result = incrementBySeven()
print( result )

result = incrementBySeven()
print( result )

result = incrementByTen()
print( result )

result = incrementByTen()
print( result )

result = incrementBySeven()
print( result )

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

