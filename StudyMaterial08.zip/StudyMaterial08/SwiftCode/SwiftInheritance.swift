//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftInheritance.swift -o inheritance

Command To Run Code
./inheritance
*/
//___________________________________________________________


//___________________________________________________________
//
//
//___________________________________________________________


class Vehicle {
	var numberOfWheels: Int
	var maxPassengers: Int

	init() {
		numberOfWheels = 0
		maxPassengers  = 1 
	}

	func description() -> String {
		return "\(numberOfWheels) Wheels and \(maxPassengers) Passengers"
	}
}

let someVehicle = Vehicle()

// Inheritance
class Bicycle : Vehicle {
	override init() {
		super.init()
		numberOfWheels = 2
	}
}

let bicycle = Bicycle()
print("Bicycle: ", bicycle.description() )

// Inheritance
class Tandem: Bicycle {
	override init() {
		super.init()
		maxPassengers = 2
	}
}

let tandem = Tandem()
print("Tandem: ", tandem.description() )


//___________________________________________________________
//___________________________________________________________

// A class can inherit methods, properties, and other characteristics 
// from another class. When one class inherits from another, the 
// inheriting class is known as a subclass, and the class it inherits 
// from is known as its superclass. 

// Inheritance is a fundamental behavior 
// that differentiates classes from other types in Swift.

// Classes in Swift can call and access methods, properties, and 
// subscripts belonging to their superclass and can provide their 
// own overriding versions of those methods, properties, and subscripts 
// to refine or modify their behavior. Swift helps to ensure your overrides 
// are correct by checking that the override definition has a matching 
// superclass definition.

// Classes can also add property observers to inherited properties 
// in order to be notified when the value of a property changes. 
// Property observers can be added to any property, regardless of 
// whether it was originally defined as a stored or computed property.

//___________________________________________________________
//___________________________________________________________

class Car: Vehicle {
	var speed: Double = 0.0

	override init() {
		super.init()
		maxPassengers = 5
		numberOfWheels = 4
	}

	override func description() -> String {
		let description = super.description()
		return description + " : " + "Travelling At \(speed) MPH"
	}
}

let car = Car()
print("Car : ", car.description() )

class SpeedLimitedCar: Car {
	override var speed: Double {
		get {
			return super.speed
		}

		set {
			super.speed = min( newValue, 40.0 )
		} 
	}
}

let limitedCar = SpeedLimitedCar()
limitedCar.speed = 90.0
print("SpeedLimitedCar: ", limitedCar.description() )


class AutomaticCar: Car {
	var gear = 1

	override var speed: Double {
		didSet {
			gear = Int( speed / 10.0 ) + 1
		}
	}

	override func description() -> String {
		return super.description() + "In Gear \(gear)"
	}
}

let automatic = AutomaticCar()
automatic.speed = 35.0
print("AutomaticCar:", automatic.description())


//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

