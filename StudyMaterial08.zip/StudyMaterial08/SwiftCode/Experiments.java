

class Experiments {
	public static void playWithNullables() {
		String greeting = "Hello HCL!";
		System.out.println( greeting );	

		greeting = null;
		System.out.println( greeting );	

		Integer something = 90;
		System.out.println( something );

		something = null;
		System.out.println( something );

		Double something1 = 99.9;
		System.out.println( something1 );

		something1 = null;
		System.out.println( something1 );

		Integer[] array = { 10, 20, 30, null, 50 };		
		for ( int i = 0; i < 5 ; i++) System.out.println( array[i] );
	}

	public static void problemWithNullables() {
		String greeting = "Hello HCL!";
		System.out.println( greeting );

		System.out.println( greeting.toUpperCase() );

		greeting = null;
		System.out.println( greeting );
		//Exception in thread "main" java.lang.NullPointerException
		// System.out.println( greeting.toUpperCase() );	

		if (greeting != null) { // Null Check
			System.out.println( greeting.toUpperCase() );	
		} else {
			System.out.println( "Greeting Contains Invalid Value" );	
		}
	}

	public static void main(String[] argv) {
		System.out.println("\nFunction : playWithNullables!");
		playWithNullables();

		System.out.println("\nFunction : problemWithNullables!");
		problemWithNullables();

	}
}

