//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftStructureAndClasses.swift -o classes

Command To Run Code
./classes
*/
//___________________________________________________________


//___________________________________________________________
//
// STRUCTURE AND CLASSES
//___________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE RAISE YOUR HAND!!!

struct Resolution {
	// Properties
	var width 	= 0 // Initialiation Value
	var height 	= 0 // Initialiation Value
}

class VideoMode {
	// Properties
	var resolution = Resolution() // Initialising With Instance Of Resolution
	var frameRate = 0.0 // Initialiation Value
	var name: String? 	// By DEFAULT Initialiation Value For Optional Type Is nil
}

// Calling Constructor Without Any Arguments
//		It Initialised Objects With Default Initial Values
let someResolution = Resolution()
let someVideoMode = VideoMode()

print( someResolution.width, someResolution.height )
print( someVideoMode.resolution, someVideoMode.frameRate, someVideoMode.name ?? "UNKNOWN" )

//___________________________________________________________
//
// STRUCTURE ARE VALUE TYPE
//___________________________________________________________

// Calling Constructor With Memberwise Initialiser
let vga = Resolution( width: 640, height: 480 )
print( vga )
print( vga.width, vga.height )

// Calling Constructor With Memberwise Initialiser
let hd = Resolution( width: 1920, height: 1080 )

// Value Assignment: Value Get Copied
//		Full Copy Of The Object IS Get Created
//		Both cinema and hd References/Addressses Points To DIFFERENT Objects
var cinema = hd

print( hd )
print( cinema )

cinema.width = 2048

print( hd )
print( cinema )

//___________________________________________________________
//
// CLASSES ARE REFERENCE TYPE
//___________________________________________________________

let tenEighty = VideoMode()
print( tenEighty.resolution, tenEighty.frameRate, tenEighty.name ?? "UNKNOWN"  )

// Intialising Object Members 
tenEighty.resolution = hd 
tenEighty.frameRate = 60.0
tenEighty.name = "1080i"

print( tenEighty.resolution, tenEighty.frameRate, tenEighty.name ?? "UNKNOWN"  )

// Reference Assignment: Only Reference Get Copied
//		Full Copy Of The Object IS NOT Get Created RATHER ONLY REFERNCE GETTING COPIED
//		Both tenEighty and alsoTenEigthy References/Addresss Points To Same SINGLE Object
let alsoTenEighty = tenEighty

alsoTenEighty.frameRate = 75.0

print( alsoTenEighty.resolution, alsoTenEighty.frameRate, alsoTenEighty.name ?? "UNKNOWN" )
print( tenEighty.resolution, tenEighty.frameRate, tenEighty.name ?? "UNKNOWN"  )

//___________________________________________________________
//
// STRCUTURE OBJECT MUTABILITY/IMMUTABILITY
//___________________________________________________________

// Stored Properties
struct FixedLengthRange {
	// Member Properties
	var firstValue: Int
	let length: Int
}

// Structure Object Is MUTABLE Than 
//		It's MUTABLE Member Properties Are MUTABLE
//		It's IMMUTABLE Member Properties Are IMMUTABLE

var rangeOfThreeItems = FixedLengthRange( firstValue: 10, length: 3)
print( rangeOfThreeItems )

rangeOfThreeItems.firstValue = 55
print( rangeOfThreeItems )


// Structure Object Is IMMUTABLE Than All It's Member Propertiees ALSO Becomes IMMUTABLE
//		Irrespective Of Member Properties Are let Or var

// error: cannot assign to property: 'rangeOfThreeItemsAgain' is a 'let' constant
// let rangeOfThreeItemsAgain = FixedLengthRange( firstValue: 10, length: 3)
// print( rangeOfThreeItemsAgain )

// rangeOfThreeItemsAgain.firstValue = 66
// print( rangeOfThreeItemsAgain )

//___________________________________________________________
//
// STRCUTURE STORED AND COMPUTED PROPERTIES
//___________________________________________________________

struct Point {
	var x = 0.0, y = 0.0
}

struct Size {
	var width = 0.0, height = 0.0
}

struct Rectangle {
	// origin and size Are Stored Properties
	var origin = Point()
	var size = Size()
	// center Is Computed Property
	var center: Point {
		get { // Getter
			print("center Getter Called...")
			let centerX = origin.x + ( size.width / 2 )
			let centerY = origin.y + ( size.height / 2 )
			
			return Point( x: centerX, y: centerY )
		}

		set( newCenter ) { // Setter
			print("center Setter Called...")
			origin.x = newCenter.x - ( size.width / 2 )
			origin.y = newCenter.y - ( size.height / 2 )
		}
	}
}

var square = Rectangle( origin: Point(x: 10.0, y: 10.0 ), size: Size(width: 20.0, height: 10.0) )

let initialSquareCenter = square.center 
print( square )

square.center = Point( x: 15.0, y: 15.0 )
print( square )


struct RectangleAgain {
	// origin and size Are Stored Properties
	var origin = Point()
	var size = Size()
	// center Is Computed Property
	var center: Point {
		get { // Getter
			print("center Getter Called...")
			let centerX = origin.x + ( size.width / 2 )
			let centerY = origin.y + ( size.height / 2 )
			
			return Point( x: centerX, y: centerY )
		}

		set { // Setter With Argument : Than Use newValue 
			print("center Setter Called...")
			origin.x = newValue.x - ( size.width / 2 )
			origin.y = newValue.y - ( size.height / 2 )
		}
	}
}

var square1 = RectangleAgain( origin: Point(x: 10.0, y: 10.0 ), size: Size(width: 20.0, height: 10.0) )

let initialSquareCenter1 = square1.center 
print( square1 )

square1.center = Point( x: 15.0, y: 15.0 )
print( square1 )


//___________________________________________________________
//
// COMPUTED PROPERTY WITH ONLY GETTER
//___________________________________________________________


struct Rectangle1 {
	// origin and size Are Stored Properties
	var origin = Point()
	var size = Size()
	// center Is Computed Property
	var center: Point {
		get { // Only Getter
			print("center Getter Called...")
			let centerX = origin.x + ( size.width / 2 )
			let centerY = origin.y + ( size.height / 2 )
			
			return Point( x: centerX, y: centerY )
		}
	}
}

var square2 = Rectangle1( origin: Point(x: 10.0, y: 10.0 ), size: Size(width: 20.0, height: 10.0) )
print( square2 )

// square.center = Point( x: 15.0, y: 15.0 )
// print( square )


struct Rectangle3 {
	// origin and size Are Stored Properties
	var origin = Point()
	var size = Size()

	// center Is Computed Property
	var center: Point { // Only Getter : Hence Can Skip get Keyword
		print("center Getter Called...")
		let centerX = origin.x + ( size.width / 2 )
		let centerY = origin.y + ( size.height / 2 )
		
		return Point( x: centerX, y: centerY )
	}
}

var square3 = Rectangle3( origin: Point(x: 10.0, y: 10.0 ), size: Size(width: 20.0, height: 10.0) )
print( square3 )

// square.center = Point( x: 15.0, y: 15.0 )
// print( square )


//___________________________________________________________
//
// PROPERTY OBSERVERS
//___________________________________________________________

class Counter {
	var count : Int = 0 {
		// Property Observers
		willSet {
			print("WillSet Called...")
		}

		didSet {
			print("DidSet Called...")		
		}
	}
}

let counter = Counter()
print( counter.count ) // 0

// WillSet Called...
// 		Calling Setter Function
counter.count = 10 // counter.setCount( 10 )
// DidSet Called...
print( counter.count ) // 10

//___________________________________________________________
// Property Observers Can Be Used To Write Validation Logic

class StepCounter {
	let maximumSteps = 1000
	var totalSteps: Int = 0 {
		
		willSet( newTotalSteps ) {
			print("About To Set totalSteps To:", newTotalSteps )
		}

		didSet {
			// Post Condition Logic : Validation Logic
			if totalSteps >= maximumSteps {
				print("Total Targets Achieve: ", totalSteps)
				totalSteps = 0
			} else if totalSteps < 0 {
				totalSteps = 0
			}
		}
	}
}

let stepCounter = StepCounter()

stepCounter.totalSteps = -100
print( stepCounter.totalSteps )

stepCounter.totalSteps = 200
print( stepCounter.totalSteps )

stepCounter.totalSteps = 900
print( stepCounter.totalSteps )

stepCounter.totalSteps = 1000
print( stepCounter.totalSteps )


//___________________________________________________________
//
// INSTANCE MEMBERS AND TYPE MEMBERS
//___________________________________________________________

struct SomeStructure {
	// Instance Properties: Access Using Instance/Object
	var storedInstanceProperty = 10
	var computedInstanceProperty: Int {
		set { print("Setter Called...") }
		get { 
			print("Getter Called...")
			return 888
		}
	}

	// Type (Class/Structure) Properties: Access Using Type i.e. i.e. Structure/Class Name
	static var storedTypeProperty = "Some Value"
	static var computedTypeProperty: Int {
		return 999
	}
}

let something = SomeStructure()
print( something.storedInstanceProperty )
print( something.computedInstanceProperty )
// print( something.storedTypeProperty )
// print( something.computedTypeProperty )

// print( SomeStructure.storedInstanceProperty )
// print( SomeStructure.computedInstanceProperty )
print( SomeStructure.storedTypeProperty )
print( SomeStructure.computedTypeProperty )


class SomeClass {
	// Instance Properties: Access Using Instance/Object
	var storedInstanceProperty = 10
	var computedInstanceProperty: Int {
		set { print("Setter Called...") }
		get { 
			print("Getter Called...")
			return 888
		}
	}

	// Type (Class/Structure) Properties: Access Using Type i.e. Structure/Class Name
	static var storedTypeProperty = "Some Value"
	static var computedTypeProperty: Int {
		return 999
	}
}

let someClass = SomeClass()
print( someClass.storedInstanceProperty )
print( someClass.computedInstanceProperty )
// print( someClass.storedTypeProperty )
// print( someClass.computedTypeProperty )

// print( SomeClass.storedInstanceProperty )
// print( SomeClass.computedInstanceProperty )
print( SomeClass.storedTypeProperty )
print( SomeClass.computedTypeProperty )

//___________________________________________________________
//
// Property Observers One More Example
//___________________________________________________________

struct AudioChannel {
	// Type Members
	static let thresholdLevel = 10
	static var maxInputLevelForAllChannels = 0

	var currentLevel: Int = 0 {
		// Property Observer
		didSet {
			if currentLevel > AudioChannel.thresholdLevel {
				currentLevel = AudioChannel.thresholdLevel
			}

			if currentLevel > AudioChannel.maxInputLevelForAllChannels {
				AudioChannel.maxInputLevelForAllChannels = currentLevel
			}
		}
	}
}

var leftChannel = AudioChannel()
var rightChannle = AudioChannel()

print( leftChannel.currentLevel )
leftChannel.currentLevel = 7
print( leftChannel.currentLevel )

print( rightChannle.currentLevel )
rightChannle.currentLevel = 11
print( rightChannle.currentLevel )


//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________



