//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftErrorHandling.swift -o errors

Command To Run Code
./errors
*/
//___________________________________________________________


import Foundation


// Can Define Your Own Error Types
enum VendingMachineError : Error {
	case invalidSelection
	case insufficientFunds( coinsNeeded: Int )
	case outOfStock
}

// Runtime Exception Throwing
// throw VendingMachineError.insufficientFunds( coinsNeeded: 6 )

struct Item {
    var price: Int
    var count: Int
}

class VendingMachine {

    var inventory = [
        "Candy Bar": Item(price: 12, count: 7),
        "Chips": Item(price: 10, count: 4),
        "Pretzels": Item(price: 7, count: 11)
    ]

    var coinsDeposited = 0

    func vend(itemNamed name: String) throws {
        guard let item = inventory[name] else {
            throw VendingMachineError.invalidSelection
        }

        guard item.count > 0 else {
            throw VendingMachineError.outOfStock
        }

        guard item.price <= coinsDeposited else {
            throw VendingMachineError.insufficientFunds(coinsNeeded: item.price - coinsDeposited)
        }

        coinsDeposited -= item.price
        var newItem = item
        newItem.count -= 1
        inventory[name] = newItem

        print("Dispensing \(name)")
    } 
}

let favoriteSnacks = [
    "Alice": "Chips",
    "Bob": "Licorice",
    "Eve": "Pretzels",
]


// Function Throwing The Error
//      Should Mention throws In Signature
// func buyFavoriteSnack(person: String, vendingMachine: VendingMachine) {
func buyFavoriteSnack(person: String, vendingMachine: VendingMachine) throws {
    let snackName = favoriteSnacks[person] ?? "Candy Bar"

    // error: errors thrown from here are not handled
    try vendingMachine.vend(itemNamed: snackName)
}

var vendingMachine = VendingMachine()
vendingMachine.coinsDeposited = 8

do {
    //error: call can throw but is not marked with 'try'
    // buyFavoriteSnack(person: "Alice", vendingMachine: vendingMachine)
    try buyFavoriteSnack(person: "Alice", vendingMachine: vendingMachine)
    print("Success! Yum.")
} catch VendingMachineError.invalidSelection {
    print("Invalid Selection.")
} catch VendingMachineError.outOfStock {
    print("Out of Stock.")
} catch VendingMachineError.insufficientFunds(let coinsNeeded) {
    print("Insufficient funds. Please insert an additional \(coinsNeeded) coins.")
} catch {
    print("Unexpected error: \(error).")
}
// Prints "Insufficient funds. Please insert an additional 2 coins."


//___________________________________________________________
//___________________________________________________________

/*
func nourish( with item: String ) {
    let vendingMachine = VendingMachine()
    vendingMachine.coinsDeposited = 10
    // error: call can throw, but it is not marked with 'try' 
    // and the error is not handled
    // vendingMachine.vend(itemNamed: item)

    // error: errors thrown from here are not handle
    // try vendingMachine.vend(itemNamed: item)

    do {
        // error: errors thrown from here are not handled because the 
        // enclosing catch is not exhaustive
        try vendingMachine.vend(itemNamed: item)
    } catch is VendingMachineError {
        print("VendingMachine Out Of Order" )
    }
}

nourish(with: "Cheese Cake!")
*/

// Either Handle The Error Fully Or Propogate Error


// Handling The Error
func nourishAgain( with item: String ) {
    let vendingMachine = VendingMachine()
    vendingMachine.coinsDeposited = 10
    // error: call can throw, but it is not marked with 'try' 
    // and the error is not handled
    // vendingMachine.vend(itemNamed: item)

    // error: errors thrown from here are not handle
    // try vendingMachine.vend(itemNamed: item)

    // Handling The Error Exaustingly, Fully and Specifically
    do {
        try vendingMachine.vend(itemNamed: item)
        print("Success! Got The Item!!!.") 
    } catch VendingMachineError.invalidSelection {
        print("Invalid Selection.")
    } catch VendingMachineError.outOfStock {
        print("Out of Stock.")
    } catch VendingMachineError.insufficientFunds(let coinsNeeded) {
        print("Insufficient funds. Please insert an additional \(coinsNeeded) coins.")
    } catch {
        print("Unexpected Error: \(error).")
    }
}

nourishAgain(with: "Cheese Cake!")


// Propagate The Error
func nourishOnceAgain( with item: String ) throws {
    let vendingMachine = VendingMachine()
    vendingMachine.coinsDeposited = 10
    // error: call can throw, but it is not marked with 'try' 
    // and the error is not handled
    // vendingMachine.vend(itemNamed: item)

    // error: errors thrown from here are not handle
    do {
        try vendingMachine.vend(itemNamed: item)
    } catch is VendingMachineError {
        print("VendingMachine Out Of Order" )
    }
}

// error: call can throw but is not marked with 'try'
// nourishOnceAgain(with: "Cheese Cake!")

do {
    try nourishOnceAgain(with: "Cheese Cake!")
} catch {
    print("Uknown Error..." )
}

//___________________________________________________________
//___________________________________________________________

// DESIGN PRINCIPLE
//      Exceptions/Errors Are Not That Exceptional Such That It Should Break Your Design

//  1. Always Design Towards NONNULLABILITY RATHER NULLABILITY
//  2. Bring NULLABILITY/OPTIONALS Only Required Siturations
//  3. Always Prefer NULLABILITY/OPTIONALS Over Exceptions/Errors
//  4. Exceptions/Errors Are Last Choice

// BEST PRACTICES FOR ERROR/EXCEPTIONS
//  5. Handle Error As Early As Possible
//        Handling The Error Exaustingly, Fully and Specifically
//  6. Prefer Handling Of Error Rather Propogation Of Error
//  7. Error Propogation Should Be Last Choice


// DESIGN PRACTICE
//      Prefer Preventive Mode Rather Than Reactive Mode

//___________________________________________________________
//___________________________________________________________


func someThrowingFunction( choice: Bool ) throws -> Int {
    // Some Logic Here... and There...
    if choice {
        return 99
    } else {
    // Assume This Function Throws Some Error...
        throw VendingMachineError.outOfStock
    }
}


// Converting Error/Exception To Nullable
let result: Int?
do {
    result = try someThrowingFunction( choice: true )
} catch {
    result = nil
}

// Following Line Of Code Is Similar To Above do-catch Block
let resultAgain: Int? = try? someThrowingFunction( choice: true )

//___________________________________________________________
//___________________________________________________________

enum Status : Error {
    case Unlucky
    case Lucky
}


struct Data {
    var value: Int
}

// Assume Some Framework/Library API's Throws Exceptions/Errors
// Function Throwing Exception/Error
func fetchDataFromDisk() throws -> Data {
    let success = arc4random_uniform( 5 )

    if success == 0 { throw Status.Unlucky }
    return Data( value: 888 )
}

// Function Throwing Exception/Error
func fetchDataFromServer() throws -> Data {
    let success = arc4random_uniform( 5 )

    if success == 0 { throw Status.Unlucky }
    return Data( value: 777 )
}

// Optional Data
func fetchData() -> Data? {
    // Try To Convert Exceptions/Errors To NULLABLE
    if let data = try? fetchDataFromDisk()      { return data }
    if let data = try? fetchDataFromServer()    { return data }

    return nil
}

let _ = fetchData()

// DESIGN PRACTICES
//      If You Come Across Exceptions/Errors
//      1. Try To Convert Exceptions/Errors To NULLABLE
//      2. Than To Non NUllable
//      3. Handling Exaustive Exceptions/Errors with/without Propogating Is Las Chioce

//___________________________________________________________
//___________________________________________________________


//___________________________________________________________
//___________________________________________________________

