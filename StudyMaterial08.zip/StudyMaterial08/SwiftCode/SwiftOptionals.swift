//___________________________________________________________

/*
Command To Compile Code
swiftc SwiftOptionals.swift -o optionals

Command To Run Code
./optionals
*/

//___________________________________________________________
//
// OPTIONAL TYPES
//___________________________________________________________


// IN SWIFT 
// 		BY DEFAULT ALL TYPES ARE NON OPIONAL TYPES/NON NULLABLES

// IN JAVA/C++/Python
// 		BY DEFAULT ALL TYPES ARE OPIONAL TYPES/NULLABLE TYPES

// DESIGN PRACTICE
//		ALWAYS PREFER NON NULLABLE TYPE RATHER THAN NULLABLE TYPES
//		ALWAYS PREFER NON OPTIONAL TYPE RATHER THAN OPTIONAL TYPES

// Non Optional Types/ Non Nullable Types
//		CANNOT Store nil 
// 		Int, String, Double, Float,...

// Int Type Can Have A VALID Value From Int Range
//		It Can't Store nil ( INVALID STATE )
// error: 'nil' cannot initialize specified type 'Int'
// let something: Int = nil
// print( something )

// error: 'nil' cannot initialize specified type 'String'
// let something1: String = nil
// print( something1 )

// error: 'nil' cannot initialize specified type 'Double'
// let something2: Double = nil
// print( something2 )

// let something3: Float = nil
// print( something3 )

//____________________________________________

// Optional Types/ Nullable Types
//		CAN Store nil 
		// Int?, String?, Double?, Float?,...

let something: Int? = nil
// print( something )

let something1: String? = nil
// print( something1 )

let something2: Double? = nil
// print( something2 )

let something3: Float? = nil
// print( something3 )

//___________________________________________________________
//___________________________________________________________

var possibleNumber: String = "123"
print( possibleNumber ) // 123

// var convertedNumber: Int = Int( possibleNumber )

// Type Casting With Int() 
//		On Successful Type Cast Will VALID Value From Range Of Int
//		On UnSuccessful Type Cast Will Give INVALID Value i.e nil

// Type Of LHS Is Int? Here Int? means Optional Int
//		It Can Have A VALID Value From Int Range
//		Or It Can Have Value nil i.e. INVALID VALUE

var convertedNumber: Int? = Int( possibleNumber )

// As convertedNumber Is Of Type Int? i.e. Nullable
// 		Hence It Requires Null Check i.e. nil Check

if ( convertedNumber != nil ) {
	// print( convertedNumber ) // Optional(123)
	// Unwrapping A Optional Value Of Type Int?
	//		Getting Int Value From Optional(123) is Like Bucket(123)
	//		To et Value 123 Out Of Bucket -> Use Unwrapping Symbol !
	print( convertedNumber! ) // 123
} else {
	print( "Invalid Number" )
}

convertedNumber = nil 

//		Getting Int Value From Optional( nil ) is Like Bucket( nil )
//		If You Try To Water Out Of Empty Bucket i.e. Bucket(nil)
//			You Will Get Disappointment i.e Runtime Error| Fatal Error

// : Fatal error: Unexpectedly found nil while unwrapping an Optional value
// zsh: trace trap  ./optionals
// let some = convertedNumber!

// Do The Null Check i.e. nil Check
if ( convertedNumber != nil ) {
	// Bucket Is NOT EMPTY
	print( convertedNumber! ) 
} else {
	// Bucket Is EMPTY CASE
	print( "Invalid Number" )
}

//___________________________________________________________
//
// OPTIONALS BINDING
//___________________________________________________________


possibleNumber = "123ABCGHJ"
// convertedNumber Is Becoming nil Because Unsuccessful Typecasting
convertedNumber = Int( possibleNumber )

if ( convertedNumber != nil ) {
	// Unwrapping A Optional Value Of Type Int?
	//		Getting Int Value From Optional(123) is Like Bucket(123)
	//		To et Value 123 Out Of Bucket -> Use Unwrapping Symbol !
	print( convertedNumber! ) // 123
} else {
	print( "Invalid Number" )
}

// Prefer Following Style Of Programming To Handle Optionals Using Optional Binding

// Optional Binding
if let actualNumber = Int( possibleNumber ) {
	print("\(possibleNumber) Have An Integer Value: \(actualNumber)" )
} else {
	print("Type Conversion Failed")
}

if var actualNumber = Int( possibleNumber ) {
	print("\(possibleNumber) Have An Integer Value: \(actualNumber)" )
	actualNumber = actualNumber +  10
	print("Updated Number", actualNumber)
} else {
	print("Type Conversion Failed")
}



//___________________________________________________________
//
// 	if-else Idioms
//___________________________________________________________


// 	Here Comma Means Logical AND
//	 	if Any Of The Items Leads To nil Than It's False...

if let firstNumber = Int( "42" ), let secondNumber = Int("100"), firstNumber < secondNumber {
	print(firstNumber, secondNumber)
} else {
	print( "Invalid Number" )
}


let aa: Int? = 44
let bb: Int? = nil
let cc: Int? = 88

if let someA = aa, let someB = bb, let someC = cc {
	print( someA, someB, someC )
} else {
	print("Atleast One Of The Optional Is nil")
}

if let someA = aa, let someC = cc {
	print( someA, someC )
} else {
	print("Atleast One Of The Optional Is nil")
}

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
