
// WHAT IS TYPE?
//		{ Operation, Range }


// What It Is?
// Abstract Type [ Mathematical ]
//		Operation = { fly, saveWorld }
//		Range = Phi Set Or Empty
protocol Superpower {
	func fly()
	func saveWorld()
}

// Concrete Classes
//		How, When, Where, Which Way... etc...
class BadSpiderman : Superpower {
	func fly() 			{ print("Flying Like Spiderman") }
	func saveWorld() 	{ print("Save World Like Spiderman") }
}

// Type Of Type Relationship
//		Spiderman Is Type Of Superpower
class Spiderman : Superpower {
	func fly() { print("Flying Like Spiderman") }
	func saveWorld() { print("Save World Like Spiderman") }
}

class Superman : Superpower {
	func fly() 			{ print("Flying Like Superman") }
	func saveWorld() 	{ print("Save World Like Superman") }
}

class Heman : Superpower {
	func fly() 			{ print("Flying Like Heman") }
	func saveWorld() 	{ print("Save World Like Heman") }
}

class Wonderwoman : Superpower {
	func fly() 			{ print("Flying Like Wonderwoman") }
	func saveWorld() 	{ print("Save World Like Wonderwoman") }
}

// class Human {
// 	func fly() { print("Flying Like Human") }
// 	func saveWorld() { print("Save World Like Human") }
// }

// 		Mechanism : Using Inheritance
// class Human: Spiderman {
// class Human: Superman {
class HumanOld: Heman {
	override func fly() 		{ super.fly() }
	override func saveWorld() 	{ super.saveWorld() }
}

print("\nHumanOld...")
let h = HumanOld()
h.fly()
h.saveWorld()

// Resuse Code
//		Mechanism: Using Composition
class HumanAgain {
	// var power: Spiderman = Spiderman()
	// var power: Superman = Superman()
	var power: Heman = Heman()
	func fly() 			{ power.fly() 		}
	func saveWorld() 	{ power.saveWorld() }
}

print("\nHuman Again...")
let ha = HumanAgain()
ha.fly()
ha.saveWorld()


// DESIGN PRACTICE
// Polymorphic Human Class
//		Using : Mechanism Composition
//		Composition Is Better Than Inheritance
//		Always Prefer Composition Over Inheritance

class Human {
	// var power: Spiderman = Spiderman()
	// var power: Superman = Superman()
	// var power: Heman = Heman()

	// Delagation To power
	var power: Superpower? = nil 
	func fly() 			{ power?.fly() }
	func saveWorld() 	{ power?.saveWorld() }
}

print("\nHuman Better...")
let hb = Human()
hb.fly()
hb.saveWorld()

hb.power = BadSpiderman()
hb.fly()
hb.saveWorld()

hb.power = Spiderman()
hb.fly()
hb.saveWorld()

hb.power = Superman()
hb.fly()
hb.saveWorld()

hb.power = Heman()
hb.fly()
hb.saveWorld()

hb.power = Won
derwoman()
hb.fly()
hb.saveWorld()

