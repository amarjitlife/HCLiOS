
//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftOptionalChaining.swift -o chaining

Command To Run Code
./chaining
*/

//___________________________________________________________
//
// SAFE MEMBER ACCESS OPERATOR
//___________________________________________________________

class Residence {
	var numberOfRooms = 1
}

class Person {
	var residence: Residence?
}

let alice = Person()

// error: value of optional type 'Residence?' must be unwrapped to refer 
// to member 'numberOfRooms' of wrapped base type 'Residence'
// let roomCount = alice.residence.numberOfRooms
// print( roomCount )

// CODE 01 AND CODE 02 ARE EQUIVALENT

// CODE 01

if alice.residence != nil {
	let residence = alice.residence!
	let roomCount = residence.numberOfRooms
	print( roomCount )	
} else {
	print("Alice Don't Have Residence")
}

// CODE 02
// IDIOM : OPTIONAL CHAINING

// ?. Is Safe Member Access Operator
if let roomCount = alice.residence?.numberOfRooms {
	print( roomCount )	
} else {
	print("Alice Don't Have Residence")
}

//___________________________________________________________

class Room2 {
	let name: String
	init( name: String ) { self.name = name }
}

class Address2 {
	var nation: String = "India"
	var buildingName: String?
	var buildingNumber: String?
	var street: String?

	func buildingIdentifier() -> String? {
		if ( buildingName != nil ) 		 { return buildingName }
		else if (buildingNumber != nil ) { return buildingNumber }
		else { return nil }
	}
}

class Residence2 {
	var rooms = [Room2]()
	var address: Address2?

	var numberOfRooms: Int {
		return rooms.count
	}

	subscript( index: Int ) -> Room2 {
		return rooms[index]
	}

	func printNumberOfRooms() {
		print("Room Count: ", numberOfRooms)
	}


}

class Person2 {
	var residence: Residence2?
}

let gabbar = Person2()
gabbar.residence = Residence2()
gabbar.residence?.address = Address2()

// if-let IDIOM With OPTIONAL CHAINING
// ?. Is Safe Member Access Operator
// Optional Chaining
if let nation = gabbar.residence?.address?.nation {
	print( nation )	
} else {
	print("Gabbar Don't Have Residence")
}

// Compiler Will Generate Following Code
// let nullableResult = if gabbar.residence != nil {
// 	if gabbar.residence!.address != nil {
// 		let nation = gabbar.residence!.address!.nation
// 		print(nation)
// 	} else {
// 		return nil
// 	}
// } else {
// 	return nil
// }

gabbar.residence?.printNumberOfRooms()

if let buildingIdentifier = gabbar.residence?.address?.buildingIdentifier() {
	print( buildingIdentifier )
} else {
	print("UNKONWN BUILDING")
}

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

