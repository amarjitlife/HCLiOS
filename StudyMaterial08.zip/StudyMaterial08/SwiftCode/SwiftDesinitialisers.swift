
//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftDenitialisation.swift -o deinitialisation

Command To Run Code
./deinitialisation
*/
//___________________________________________________________

struct Bank {
	static var coinsInBank = 10000

	static func vendCoins( numberOfCointsToVend: Int ) -> Int {
		let numberOfCointsToVendMinimum = min( numberOfCointsToVend, coinsInBank )
		coinsInBank -= numberOfCointsToVendMinimum
		return numberOfCointsToVendMinimum
	}

	static func receiveCoins( coins: Int ) {
		coinsInBank += coins 
	}
}


class Player {
	var coinsInPurse : Int

	init( coins: Int ) {
		print("Player: init Called...")
		coinsInPurse = Bank.vendCoins( numberOfCointsToVend: coins )
	}

	func winCoins( coins: Int ) {
		coinsInPurse += Bank.vendCoins( numberOfCointsToVend: coins )
	}

	deinit {
		print("Player: deinit Called...")
  		Bank.receiveCoins( coins: coinsInPurse )
	}
}


var playerOne: Player? = Player( coins: 100 )

print( playerOne!.coinsInPurse )

playerOne!.winCoins( coins: 50 )

playerOne = nil 

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
