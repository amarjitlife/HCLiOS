//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftSubscript.swift -o subscript

Command To Run Code
./subscript
*/
//___________________________________________________________


// In Array Subscript Operator Gives Value At Index
var numbers = [10, 20, 30, 40, 50]
print( numbers[1] )

// In Dictionary/Map Subscript Operator Gives Value For Key
var numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
numberOfLegs["bird"] = 2

//___________________________________________________________

struct TimesTable {
	let multiplier: Int

	// Function Named subscript : It's A Special Function
	//		It Doesn't Require func Keyword To Start With
	//		It's Role To Overload Subscript Operator []
	subscript( index: Int ) -> Int {
		return multiplier * index
	}
}

let threeTable = TimesTable( multiplier : 3 )
let fiveTable = TimesTable( multiplier : 5 )

var table: Int

// Compiler Will Convert Following Subscript Operator 
//		Into subscript Special Function Call
table = threeTable[1] // table = threeTable.subscript( index: 1 )
print( table )

table = threeTable[2] // table = threeTable.subscript( index: 2 )
print( table ) 
print( threeTable[3] )
print( threeTable[4] )
print( threeTable[5] )

table = threeTable[6]
print( table )

// Overloaded Subscript Operator []
//		Defined Subscript Operator [] As Per Our Structure/Class/Type
// 		In TimesTable Subscript Operator Gives Multiplier At Index
print( fiveTable[1] )
print( fiveTable[2] )
print( fiveTable[3] )
print( fiveTable[4] )
print( fiveTable[5] )

//___________________________________________________________
//
//
//___________________________________________________________

struct Matrix {
	let rows: Int, columns: Int
	var grid: [Double]

	init( rows: Int, columns: Int ) { // Constructor 
		self.rows 		= rows
		self.columns 	= columns

		grid = Array( repeating: 0.0, count: rows * columns )
	}

	func indexIsValid( row: Int, column: Int ) -> Bool {
		return row >= 0 && row < rows && column >= 0 && column < columns
	}

	//	Overloading Subscript Operator
	//	Simulating 2-Dimentional On Top Of 1-D
	subscript( row: Int, column: Int ) -> Double {
		get {
			assert( indexIsValid( row: row, column: column), "Index Out of Range" )
			return grid[ (row * columns) + column ]
		}

		set {
			assert( indexIsValid( row: row, column: column), "Index Out of Range" )
			grid[ (row * columns) + column ] = newValue		
		}
	}	
}

var matrix = Matrix( rows: 2, columns: 2 )
print( matrix[0, 0] )
print( matrix[1, 0] )
print( matrix[0, 1] )

matrix[1, 0] = 1.5
matrix[0, 1] = 3.2

print( matrix[1, 0] )
print( matrix[0, 1] )

print( matrix )

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
