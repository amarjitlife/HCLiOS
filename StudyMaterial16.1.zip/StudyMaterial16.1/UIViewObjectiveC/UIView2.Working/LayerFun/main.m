//
//  main.m
//  LayerFun
//
//  Created by Ray Wenderlich on 12/16/10.
//  Copyright 2010 Ray Wenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Classes/LayerFunAppDelegate.h"

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([LayerFunAppDelegate class]));

    [pool release];
    return retVal;
}
