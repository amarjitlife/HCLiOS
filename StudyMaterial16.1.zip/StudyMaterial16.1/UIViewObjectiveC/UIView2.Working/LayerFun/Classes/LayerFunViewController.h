//
//  LayerFunViewController.h
//  LayerFun
//
//  Created by Ray Wenderlich on 12/16/10.
//  Copyright 2010 Ray Wenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LayerFunViewController : UIViewController {

}

@end

