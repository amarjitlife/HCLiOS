//___________________________________________________________

/*
Command To Compile Code
swiftc SwiftTypes.swift -o types

Command To Run Code
./types
*/

//___________________________________________________________
//
// 
//___________________________________________________________


// Type Annotation: Annotating Identifier With Type Explicity

let something: Int = 90
print( something )

// Type Inferrence and Binding
//		1. Type Inferrencing Will Happen From RHS Value
//		2. Type Binding Will Happen To LHS
//				It Will Bind Inferred Type To LHS

// Type Inferrence and Binding
//		1. Type Inferrencing Will Happen From RHS Value i.e. 90 Value Is Int
//		2. Type Binding Will Happen To LHS
//				It Will Bind Inferred Type (Int) To LHS
//				Hence Type Of something1 Will Be Int

let something1 = 90 // Default Type Of Int
print( something1 )


// Type Inferrence and Binding
//		1. Type Inferrencing Will Happen From RHS Value i.e. 99.90 Value Is Double By Default
//		2. Type Binding Will Happen To LHS
//				It Will Bind Inferred Type (Double) To LHS
//				Hence Type Of somethingAgain Will Be Double

let somethingAgain = 99.90
print( somethingAgain )


// Type Inferrence and Binding
//		1. Type Inferrencing Will Happen From RHS Value i.e. 99.90 Value Is Double By Default
//		2. LHS Type Annotated Is Float
//		3. RHS Double Type Value Conveted To Float Type Value and Assigned To LHS

let somethingAgain1: Float = 99.90
print( somethingAgain )

let greeting = "Hello"





//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
