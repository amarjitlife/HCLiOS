//___________________________________________________________

/*
Command To Compile Code
swiftc SwiftCollections.swift -o collections

Command To Run Code
./collections
*/

//___________________________________________________________
//
// ARRAYS COLLECTION
//___________________________________________________________

// Creating Empty Arrays
let someInts = [Int]()
print( someInts )
if someInts.isEmpty {
	print("Empty Array")
} else {
	print("Array Have Elements")
}

// IMMUTABLE ARRAY
let someInts1: [Int] = [10, 20, 30, 40, 50 ]
print( someInts1 )

// error: cannot use mutating member on immutable value: 'someInts1' is a 'let' constant
// someInts1.append( 99 )
// print( someInts1 )

if someInts1.isEmpty {
	print("Empty Array")
} else {
	print("Array Have Elements")
}

// Iterating Over Array
for item in someInts1 {
	print( "\(item)", terminator: " " )
}

print()

// MUTABLE ARRAY
var someInts2: [Int] = [ 10, 20, 30, 40, 50 ]
print( someInts2 )
someInts2.append( 99 )
print( someInts2 )

someInts2 = [] // [Int]()
print( someInts2 )

if someInts2.isEmpty {
	print("Empty Array")
} else {
	print("Array Have Elements")
}

//___________________________________________________________
//
// Creating Arrays with Default Values
//___________________________________________________________

// Following Both Code Are Equivalent
let threeDoubles = Array( repeating: 0.0, count: 3 )
print( threeDoubles ) // [0.0, 0.0, 0.0]

let threeDoubles1: [Double] = Array( repeating: 0.0, count: 3 )
print( threeDoubles1 ) // [0.0, 0.0, 0.0]

let anotherThreeDoubles = Array( repeating: 9.0, count: 4 )
print( anotherThreeDoubles )

let sixDoubles = threeDoubles + anotherThreeDoubles
print( sixDoubles )

let fourInts = Array( repeating: 99, count: 4)
print( fourInts )

let fiveInts = Array( repeating: 55, count: 5)
print( fiveInts )

let nineInts = fourInts + fiveInts
print( nineInts )

// error: binary operator '+' cannot be applied to operands of type '[Double]' and '[Int]'
// let moreArray = threeDoubles + fourInts 

// NOTE: Array Of Similar Type Members Can Be Concatenated
//			Not Otherwise

//___________________________________________________________
//
// CREATING ARRAYS WITH LITERAL SYNTAX
//___________________________________________________________

// Following Both Codes Are Equivalent
var shoppingList: [String] = ["Milk", "Eggs"]
print( shoppingList )

var shoppingList1 = ["Milk", "Eggs"]
print( shoppingList1 )

if shoppingList.isEmpty {
	print("Empty Array Found")
} else {
	print("NON Empty Array Found")
}

shoppingList.append( "Flour" )
print( shoppingList )

shoppingList = shoppingList + ["Baking Powder", "Oil"]
print( shoppingList )

shoppingList += ["Choco Powder", "Coffee Powder", "Tea Powder"]
print( shoppingList )

let firstItem = shoppingList[0]
print( firstItem )

shoppingList[0] = "Butter"
print( shoppingList )

print( "Shopping List Length: ", shoppingList.count )

print( shoppingList[0...3])
print( shoppingList[4...6])

shoppingList.insert("Chocolate Syrup", at: 0)
print( shoppingList )

shoppingList.insert("Water", at: 3)
print( shoppingList )

shoppingList.remove(at: 0)
print( shoppingList )

shoppingList.removeLast()
print( shoppingList )

for item in shoppingList {
	print( item )
}

for ( index, value ) in shoppingList.enumerated() {
	print("Item At \( index ) : \(value)")
}

print( shoppingList[4...6])

print( shoppingList )
shoppingList[4...6] = ["Bananas", "Apples"]
print( shoppingList )

let array: Array<Int> = [1, 2, 3,4]
print( array )

//___________________________________________________________
//
// SET COLLECTION
//___________________________________________________________


var letters = Set<Character>()
print( letters )
print( "Elements In Set: ", letters.count )

if letters.isEmpty {
	print("Empty Set")
} else {
	print("Non Empty Set")
}

letters.insert("A")
print( letters )

letters.insert("B")
print( letters )

letters.insert("A")
print( letters )

letters = []
print( letters )

var favoriteGeneres: Set<String> = ["Rock", "Classical", "Hip Hop" ]
print( favoriteGeneres )

var favoriteGeneres1 = ["Rock", "Classical", "Hip Hop" ]
print( favoriteGeneres1 )

favoriteGeneres.insert("Jazz")
print( favoriteGeneres )

favoriteGeneres.insert("Rock")
print( favoriteGeneres )

print( "Elements In Set: ", favoriteGeneres.count )
if favoriteGeneres.isEmpty {
	print("Empty Set")
} else {
	print("Non Empty Set")
}

let removedGenere = favoriteGeneres.remove("Hip Hop")
// print( removedGenere )

let removedGenere1 = favoriteGeneres.remove("Bharatnatayam")
// print( removedGenere1 )

if favoriteGeneres.contains("Classical") {
	print("Classical Is There...")
} else {
	print("People Are Forgetting Classical...")
}

for genre in favoriteGeneres {
	print( genre )
}

for genre in favoriteGeneres.sorted() {
    print( genre)
}


let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [1, 3, 5, 7, 9]
let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]

let unionData = oddDigits.union( evenDigits )
print( unionData )
print( unionData.sorted() )

let intersectionData = oddDigits.intersection( evenDigits )
print( intersectionData )
print( intersectionData.sorted() )


//___________________________________________________________
// 
// DICTIONARY COLLECTION
//___________________________________________________________

// Dictionaries Stores Key/Value Pairs

// Following Both Codes Are Equivalent
var namesOfIntegers0: [ Int : String ] = [:]
print( namesOfIntegers0 )

var namesOfIntegers1 = [ Int : String ]()
print( namesOfIntegers1 )

if namesOfIntegers0.isEmpty {
	print("Empty Dictionary")
} else {
	print("Non Empty Dictionary")
}

// Following Both Codes Are Equivalent
var namesOfIntegers3: [ Int : String ] = [ 10 : "Ten", 11 : "Eleven", 1 : "One" ]
print( namesOfIntegers3 )

var namesOfIntegers4 = [ 10 : "Ten", 11 : "Eleven", 1 : "One" ]
print( namesOfIntegers4 )

if namesOfIntegers3.isEmpty {
	print("Empty Dictionary")
} else {
	print("Non Empty Dictionary")
}

var airports : [ String : String ] = [ "TRN" : "Toronto", "LDN" : "London", "BLR" : "Bangalore"]
print( airports )

var result = airports[ "BLR" ]
print( result )

print("Elements In Dictioary: ", airports.count )
if airports.isEmpty {
	print("Empty Dictionary")
} else {
	print("Non Empty Dictionary")
}

airports["PUN"] = "Pune"
print( airports )

airports["DEL"] = "Delhi"
print( airports )

airports["DEL"] = "New Delhi"
print( airports )

airports.updateValue("Heathrow Airport", forKey: "LDN")
print( airports )

airports["DEL"] = nil
print( airports )

airports.removeValue( forKey: "TRN" )
print( airports )


for airport in airports {
	print( airport )
}

for ( airportCode, airportName ) in airports {
	print(airportCode, airportName)
}

for airportCode in airports.keys {
	print( airportCode )
}

for airportValue in airports.values {
	print( airportValue )
}

let airportCodes = airports.keys
print( airportCodes )

let airportNames = airports.values
print( airportNames )

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

