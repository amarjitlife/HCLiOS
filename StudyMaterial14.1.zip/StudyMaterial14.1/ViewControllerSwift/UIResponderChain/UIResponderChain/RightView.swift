//
//  RightView.swift
//  UIResponderChain
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class RightView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        // Initialization code
        
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(RightView.handleDoubleTapGesture(_:)))
        doubleTap.numberOfTapsRequired = 2
        doubleTap.numberOfTouchesRequired = 1
        self.addGestureRecognizer(doubleTap)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect)
    {
        // Drawing code
    }
    */
    
    @objc func handleDoubleTapGesture(_ recognizer: UITapGestureRecognizer)
    {
        if(recognizer.state == UIGestureRecognizer.State.ended)
        {
            let alertView = UIAlertView(title: "Double Tap",
                message: "Right View Responder",
                delegate: nil,
                cancelButtonTitle: "OK")
            alertView.show()
        }
    }

}
