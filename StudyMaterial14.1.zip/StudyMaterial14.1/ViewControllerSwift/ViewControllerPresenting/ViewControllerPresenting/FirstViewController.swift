//
//  FirstViewController.swift
//  FirstViewControllerPresenting
//
//  Created by Nagarajan on 8/27/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    
    convenience init() {
        print("FirstViewController Function >>> ", #function);
        self.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        print("FirstViewController Function >>> ", #function);
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        print("FirstViewController Function >>> ", #function);
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        print("FirstViewController Function >>> ", #function);
    }
    
    override func loadView() {
        super.loadView()
        print("FirstViewController Function >>> ", #function);
        
        let contentLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
        contentLabel.backgroundColor = UIColor.clear
        contentLabel.numberOfLines = 3
        contentLabel.text = "HAI, RIGHT NOW WE ARE IN FIRST VIEW CONTROLLER"
        contentLabel.font = UIFont.systemFont(ofSize: 20)
        contentLabel.center = self.view.center
        contentLabel.textColor = UIColor.white
        
        self.view.addSubview(contentLabel)
        self.view.backgroundColor = UIColor.lightGray
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        print("FirstViewController Function >>> ", #function);
        // Do any additional setup after loading the view, typically from a nib.
        self.view.backgroundColor = UIColor.orange
        let singTap = UITapGestureRecognizer(target: self, action: #selector(FirstViewController.handleTapGesture(_:)))
        singTap.numberOfTapsRequired = 1
        singTap.numberOfTouchesRequired = 1
        self.view.addGestureRecognizer(singTap)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        print("FirstViewController Function >>> ", #function);
        // Dispose of any resources that can be recreated.
    }
            
    // Called when the view is about to made visible. Defaults does nothing
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("FirstViewController Function >>> ", #function);
    }
    
    // Called when the view has been fully transistioned onto the screen. Defaults does nothing
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("FirstViewController Function >>> ", #function);
    }
    
    // Called when the view is dismissed, covered or otherwise hidden. Default does nothing
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("FirstViewController Function >>> ", #function);
    }
    
    // Called after the view was dismissed, covered or otherwise hidden. Default does nothing
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("FirstViewController Function >>> ", #function);
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        print("FirstViewController Function >>> ", #function);
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        print("FirstViewController Function >>> ", #function);
    }

//___________________________________________________
// Handler's Functions
//___________________________________________________

    @objc func pressed(_ sender: UIButton!) {
        print("FirstViewController Function >>> ", #function);
        
        self.view.isHidden = true;
        self.view.removeFromSuperview()
    }
    
    @objc func handleTapGesture(_ recognizer: UITapGestureRecognizer) {
        print("FirstViewController Function >>> ", #function);
        
        if(recognizer.state == UIGestureRecognizer.State.ended) {
            let secondController = SecondViewController()
            self.present(secondController, animated: true,
                completion: {
                    let alertView = UIAlertView(title: "View Controller Presenting",
                        message: "Second View Controller Presented",
                        delegate: nil,
                        cancelButtonTitle: "OK")
                    alertView.show()
            })
        }
    }

}

