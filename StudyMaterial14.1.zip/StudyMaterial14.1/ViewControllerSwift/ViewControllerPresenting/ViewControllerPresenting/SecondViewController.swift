//
//  SecondViewController.swift
//  ViewControllerPresenting
//
//  Created by Nagarajan on 8/27/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    convenience init() {
        print("SecondViewController Function >>> ", #function);
        self.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        print("SecondViewController Function >>> ", #function);
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        print("SecondViewController Function >>> ", #function);
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    override func loadView() {
        super.loadView()
        print("SecondViewController Function >>> ", #function);
        
        let contentLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
        contentLabel.backgroundColor = UIColor.clear
        contentLabel.numberOfLines = 3
        contentLabel.text = "HAI, RIGHT NOW WE ARE IN SECOND VIEW CONTROLLER"
        contentLabel.font = UIFont.systemFont(ofSize: 20)
        contentLabel.center = self.view.center
        contentLabel.textColor = UIColor.white
        
        self.view.addSubview(contentLabel)
        self.view.backgroundColor = UIColor.lightGray
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        print("SecondViewController Function >>> ", #function);
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        print("SecondViewController Function >>> ", #function);
    }
    
// Called when the view is about to made visible. Defaults does nothing
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("SecondViewController Function >>> ", #function);
    }

    // Called when the view has been fully transistioned onto the screen. Defaults does nothing
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("SecondViewController Function >>> ", #function);
    }

    // Called when the view is dismissed, covered or otherwise hidden. Default does nothing
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("SecondViewController Function >>> ", #function);
    }

    // Called after the view was dismissed, covered or otherwise hidden. Default does nothing
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("SecondViewController Function >>> ", #function);
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        print("SecondViewController Function >>> ", #function);
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        print("SecondViewController Function >>> ", #function);
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
