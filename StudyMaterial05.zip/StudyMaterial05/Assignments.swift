
________________________________________________________________

DAY 01
________________________________________________________________

	Assignment A1: Prepare Enviornment
		Install Swift Compiler and Code Editors

	Assignment A2: Revise and Practice Topics Done In Class
		Practice Code Examples Till Now Done

________________________________________________________________

DAY 02
________________________________________________________________

	Assignment A1: Revise and Practice Topics Done In Class
		Practice and Revise Swift Code Examples Till Now Done

		├── StudyMaterial02
		│ ├── SwiftCode
		│ │ ├── Hello.swift
		│ │ ├── SwiftBasics.swift
		│ │ ├── SwiftCollections.swift
		│ │ ├── SwiftControlFlow.swift
		│ │ ├── SwiftOperators.swift
		│ │ └── SwiftStringsAndCharacters.swift

	Assignment A2: Reading Tutorials and Practice Code Assignment
		1. Read All Following Tutorials
			├── StudyMaterial02
			│ └── SwiftTutorials
			│     ├── SwiftTutorials01.pdf
			│     └── SwiftTutorials02.pdf
					
		2. Practice Code In Each Tutorials

		3. Solve All Challenges At The End Of Each Topic/Tutorials
			├── StudyMaterial02
			│ └── SwiftTutorials
			│     ├── SwiftTutorials01.pdf
	
		4. Solve All Challenges At The End Of Each Topic/Tutorials
			├── StudyMaterial02
			│ └── SwiftTutorials
			│     └── SwiftTutorials02.pdf

________________________________________________________________

DAY 03
________________________________________________________________

	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		├── StudyMaterial03
		    ├── SwiftCode
		    │ ├── Assignments.swift
		    │ ├── Experiments.class
		    │ ├── Experiments.java
		    │ ├── Hello.swift
		    │ ├── SwiftBasics.swift
		    │ ├── SwiftCollections.swift
		    │ ├── SwiftControlFlow.swift
		    │ ├── SwiftFunctions.swift
		    │ ├── SwiftOperators.swift
		    │ ├── SwiftOptionals.swift
		    │ ├── SwiftStringsAndCharacters.swift
		    │ └── SwiftTypes.swift
    

	Assignment A2: Reading Tutorials Assignment

		Read ALL Following Tutorials
			├── StudyMaterial03
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        └── SwiftTutorials04.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial03
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        └── SwiftTutorials04.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			├── StudyMaterial03
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			├── StudyMaterial03
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			├── StudyMaterial03
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			├── StudyMaterial03
			│     └── SwiftTutorials04.pdf

________________________________________________________________

DAY 04
________________________________________________________________

	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		└── StudyMaterial04
		    ├── SwiftCode
		    │ ├── Assignments.swift
		    │ ├── Experiments.java
		    │ ├── Hello.swift
		    │ ├── SwiftBasics.swift
		    │ ├── SwiftClosures.swift
		    │ ├── SwiftCollections.swift
		    │ ├── SwiftControlFlow.swift
		    │ ├── SwiftFunctions.swift
		    │ ├── SwiftOperators.swift
		    │ ├── SwiftOptionals.swift
		    │ ├── SwiftStringsAndCharacters.swift
		    │ └── SwiftTypes.swift
	
	Assignment A2: Reading Tutorials Assignment
	
		Read ALL Following Tutorials
			├── StudyMaterial04
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial04
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
				    ├── SwiftTutorials05.pdf
			        └── SwiftTutorials04.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials04.pdf

		5. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials05.pdf


________________________________________________________________

DAY 05
________________________________________________________________

	Assignment A1: Revise and Practice Topics/Code Done In Class
		
		Practice and Revise ALL Swift Code Examples Done Till Now

		└── StudyMaterial05
			├── SwiftCode
			│ ├── Assignments.swift
			│ ├── Experiments.java
			│ ├── Hello.swift
			│ ├── SwiftBasics.swift
			│ ├── SwiftClosures.swift
			│ ├── SwiftCollections.swift
			│ ├── SwiftControlFlow.swift
			│ ├── SwiftEnumeration.swift
			│ ├── SwiftFunctions.swift
			│ ├── SwiftMethods.swift
			│ ├── SwiftOperators.swift
			│ ├── SwiftOptionals.swift
			│ ├── SwiftStringsAndCharacters.swift
			│ ├── SwiftStructureAndClasses.swift
			│ └── SwiftTypes.swift

	Assignment A2: Reading Tutorials Assignment
	
		Read ALL Following Tutorials
			├── StudyMaterial05
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf
				    ├── SwiftTutorials06.pdf

	Assignment A3: Practice Tutorial Code Assignment
	
		Practice ALL Code From Following Tutorials
			├── StudyMaterial05
			    └── SwiftTutorials
			        ├── SwiftTutorials01.pdf
			        ├── SwiftTutorials02.pdf
			        ├── SwiftTutorials03.pdf
			        ├── SwiftTutorials04.pdf
				    ├── SwiftTutorials05.pdf
				    ├── SwiftTutorials06.pdf

	Assignment A4: Solve Challenges Assignment

		1. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     ├── SwiftTutorials01.pdf
	
		2. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials02.pdf

		3. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials03.pdf

		4. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials04.pdf

		5. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials05.pdf

		6. Solve All Challenges At The End Of Each Topic In Following Tutorials
			│     └── SwiftTutorials06.pdf


________________________________________________________________

DAY 06
________________________________________________________________


________________________________________________________________

DAY 07
________________________________________________________________


________________________________________________________________

DAY 08
________________________________________________________________


________________________________________________________________

DAY 09
________________________________________________________________


________________________________________________________________

DAY 10
________________________________________________________________


________________________________________________________________

DAY 11
________________________________________________________________


________________________________________________________________

DAY 12
________________________________________________________________


________________________________________________________________

DAY 13
________________________________________________________________


________________________________________________________________

DAY 14
________________________________________________________________



________________________________________________________________

DAY 15
________________________________________________________________



________________________________________________________________

DAY 16
________________________________________________________________



________________________________________________________________

DAY 17
________________________________________________________________



________________________________________________________________

DAY 18
________________________________________________________________

