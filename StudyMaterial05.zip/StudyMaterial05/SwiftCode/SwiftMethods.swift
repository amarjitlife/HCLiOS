//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftMethods.swift -o methods

Command To Run Code
./methods
*/
//___________________________________________________________

//___________________________________________________________
//
// INSTANCE METHODS
//___________________________________________________________

// Instance Methods Means Member Functions

class Counter {
	// Instance Member Property
	var count = 0

	// Methods: Instance Member Functions
	func increment() { count = count + 1 }
	func incrementBy( amount: Int ) { count += amount }
	func reset() { count = 0 }
}

let counter = Counter()
print( counter.count )

counter.increment()
print( counter.count )
counter.incrementBy( amount : 10 )
print( counter.count )

counter.reset()
print( counter.count )

class CounterTwo {
	var count : Int = 0

	func incrementBy( amount: Int, numberOfTimes: Int ) {
		count += amount * numberOfTimes
	}
}

let counter2 = CounterTwo()
print( counter2.count )

counter2.incrementBy( amount : 10, numberOfTimes: 2 )
print( counter2.count )


//___________________________________________________________
//
// STRUCTURE METHODS
//___________________________________________________________

struct Point {
	var x = 0.0, y = 0.0

	func isToTheRightOfX( x : Double ) -> Bool {
		// Here self Is Similar To this In Java/C++/C#
		//		It Points To Current Object
		return self.x > x
	}
}

let somePoint = Point( x: 4.0, y: 5.0 )
print( somePoint )

if somePoint.isToTheRightOfX( x: 1.0 ) {
	print("This Point Is Right OF Line x = 1.0 ")
}

//___________________________________________________________
//
// MUTATING METHODS
//___________________________________________________________

// In Structure self Is Immutbale
//		Method Mutating self Must Be Marked As mutating
struct PointAgain {
	var x = 0.0, y = 0.0

	mutating func moveByX( deltaX : Double, deltaY: Double ) {
		// Here self Is Similar To this In Java/C++/C#
		//		It Points To Current Object

 		// error: cannot assign to property: 'self' is immutable
		self.x = self.x + deltaX
		self.y = self.y + deltaX 
	}
}

var somePointAgain = PointAgain( x: 4.0, y: 5.0 )
print( somePointAgain )

somePointAgain.moveByX( deltaX: 2.0, deltaY: 2.0 )
print( somePointAgain )

var somePointAgain1 = PointAgain( x: 4.0, y: 5.0 )
print( somePointAgain1 )

somePointAgain1.moveByX( deltaX: 10.0, deltaY: 10.0 )
print( somePointAgain1 )


struct PointOnceAgain {
	var x = 0.0, y = 0.0

	mutating func moveByX( deltaX : Double, deltaY: Double ) {
		self = PointOnceAgain( x: x  + deltaX, y: y + deltaY )
	}
}

var somePointOnceAgain = PointOnceAgain( x: 4.0, y: 5.0 )
print( somePointOnceAgain )

somePointOnceAgain.moveByX( deltaX: 2.0, deltaY: 2.0 )
print( somePointOnceAgain )

//___________________________________________________________
//
// ENUMERATION METHODS
//___________________________________________________________

enum TriStateSwitch {
	case Off, Low, High

	// Instance Method
	mutating func next() {
		switch self {
		case .Off:
			self = .Low
		case .Low:
			self = .High
		case .High:
			self = .Off
		}
	}
}

var ovenLight = TriStateSwitch.Low
print( ovenLight )

ovenLight.next()
print( ovenLight )

ovenLight.next()
print( ovenLight )

//___________________________________________________________
//
// TYPE METHODS
//___________________________________________________________


struct LevelTracker {
	static var highestUnlockedLevel = 1
	// Type Member Function
	static func unlockLevel( level : Int ) {
		if level > highestUnlockedLevel { highestUnlockedLevel = level }
	}

	static func levelIsUnlocked( level: Int ) -> Bool {
		return level <= highestUnlockedLevel
	}

	var currentLevel = 1

	mutating func advancToLevel( level: Int ) -> Bool {
		if LevelTracker.levelIsUnlocked( level: level ) {
			currentLevel = level
			return true
		} else {
			return false
		}
	}
}


class Player {
	let playerName: String

	var tracker = LevelTracker()

	func completedLevel( level : Int ) {
		LevelTracker.unlockLevel( level: level + 1 )
		_ = tracker.advancToLevel( level: level + 1 )
	}

	init( name: String ) { // Constructor Definiton
		playerName = name
	}
}

var player = Player( name: "Virat Kohli")

player.completedLevel( level: 1 )
print( LevelTracker.highestUnlockedLevel )

player = Player(name: "Rohit Sharma")

if player.tracker.advancToLevel( level: 6 ) {
	print("Player Is Now On Level 6")
} else {
	print("Level 6 Has Not Locked")
}

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

/*

# Programming Excercise 01

	Write a Swift program to create a class called "Bank" with 
	a collection of accounts and methods to add and remove accounts, 
	and to deposit and withdraw money. 

	Also define a class called 
	"Account" to maintain account details of a particular customer.
	and Create a Customer class to track it's accounts, finances.

*/


