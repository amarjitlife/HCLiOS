//___________________________________________________________

/*
Command To Compile Code
swiftc SwiftControlFlow.swift -o controls

Command To Run Code
./controls
*/

//___________________________________________________________
//
// For-In Loop
//___________________________________________________________

for index in 1...10 {
	print( "\(index) X 5 = \(index * 5)" )
}

let base = 3
let power = 10
var answer = 1

// _ means Ignore Value
for _ in 1...power {
	answer *= base 
}

print( answer )

let names = ["Ram", "Sham", "Sita", "Lakshman", "Shiva" ]
for name in names {
	print( name )
}

let numberOfLegs = [ "Spider": 8, "Ant" : 6, "Cat" : 4, "Human" : 2 ]
for item in numberOfLegs {
	print( item )
}

for ( specie, legsCount) in numberOfLegs {
	print( specie, legsCount  )
}



//___________________________________________________________
//
// WHILE LOOP
//___________________________________________________________

let finalSquare = 25
var board = [Int]( repeating: 0, count : finalSquare + 1 )

print( board )

board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08

print( board )

var square = 0
var diceRoll = 0 

while square < finalSquare {
	// Roll The Dice 
	// NOTE IT SHOULD BE RANDOM But Time Being Just Incrementing By 1
	diceRoll = diceRoll + 1
	if diceRoll == 7 {
		diceRoll = 1
	}

	// Move By The Rolled Dice Number
	square += diceRoll

	if square < board.count {
		// If We Are Still On Board
		// Move Up Or Down For Snake Or A Ladder
		square += board[ square ]
	}
}

print("Game Over!!!")


//___________________________________________________________
//
// REPEAT-WHILE LOOP
//___________________________________________________________

// Similar To Do-While Loop

square = 0
diceRoll = 0

repeat {
    // move up or down for a snake or ladder
    square += board[square]
    // roll the dice
    diceRoll = diceRoll + 1
    if diceRoll == 7 { diceRoll = 1 }
    // move by the rolled amount
    square += diceRoll
} while square < finalSquare

print("Game over!")

//___________________________________________________________
//
// CONDITIONAL STATEMENTS if-else CONTROL
//___________________________________________________________



var temperatureInFarenheit = 30
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
}

temperatureInFarenheit = 40
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
} else {
    print("It's not that cold. wear a t-shirt.")
}

// if-else Ladder
temperatureInFarenheit = 90
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
} else if temperatureInFarenheit >= 86 {
    print("It's really warm. Don't forget to wear sunscreen.")
} else {
    print("It's not that cold. wear a t-shirt.")
}

temperatureInFarenheit = 72
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
} else if temperatureInFarenheit >= 86 {
    print("It's really warm. Don't forget to wear sunscreen.")
}


//___________________________________________________________
//
// SWITCH CONSTRUCT
//___________________________________________________________

// In SWIFT
//		BY DEFAULT break Is Implicit
//		Multiple Cases Can Be Combined In One Case

let someCharacter: Character = "e"
switch someCharacter {
    case "a", "e", "i", "o", "u":
        print("\(someCharacter) is a vowel")
    case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
        print("\(someCharacter) is a consonant")
    default:
        print("\(someCharacter) is not a vowel or consonant")
}


let anotherCharacter: Character = "a"
switch anotherCharacter {
    case "A":
        print("The letter A")
    case "B":
        print("The letter B")
	case "C":
        print("The letter C")
    default:
        print("Not the letter A")
}

//___________________________________________________________
//
// SWITCH INTERVAL MATCHING
//___________________________________________________________

// SWIFT DESIGN PRICIPLE
//		It's Designed Towards Expressivess!
//		Programmer Should Express The Ideas Intuitively

// In Swift Switch
//		break Is Implicit In Every Case
//		Not Required To Be Added

let approximateCount = 62
let countedThings = "Moon Orbiting Staturn"

var naturalCountMessage: String

switch approximateCount {
case 0:
	naturalCountMessage = "No"
case 1..<5:
	naturalCountMessage = "A Few"
case 5..<12:
	naturalCountMessage = "Several"
case 12..<100:
	naturalCountMessage = "Dozens Of"
case 100..<1000:
	naturalCountMessage = "Hundreds Of"
default:
	naturalCountMessage = "NOTHING"
}

print("There Are \(naturalCountMessage) \(countedThings)")


//___________________________________________________________
//
// SWITCH WITH TUPLES
//___________________________________________________________

let somePoint = (1, 1)
 
switch somePoint {
case (0, 0):
	print("It's An Origin")
case( _, 0): 
	print("Point Is On X-Axis")
case( 0, _): 
	print("Point Is On Y-Axis")
case( -2...2, -2...2 ): 
	print("Point Is Square")
default:
	print("Point Is Outside... ")
}

//___________________________________________________________
//
// Value Binding In Switch Statement
//___________________________________________________________

let anotherPoint = (2, 0)

// Value Binding
switch anotherPoint {
case ( let x, 0 ):
	print("On The x-Axis With An x Value : \(x)" )
case ( 0, let y ):
	print("On The y-Axis With An y Value : \(y)" )
case let (x, y):
	print("Neither On x/y-Axis : \(x), \(y)" )
}


//___________________________________________________________
//
// Where Clause In Switch Statement
//___________________________________________________________

let yetAnotherPoint = ( 1, -1 )

switch yetAnotherPoint {
case let( x, y ) where x == y:
	print("( \(x)), \(y)) Is On The Line x == y")
case let( x, y ) where x == -y:
	print("( \(x)), \(y)) Is On The Line x == - y")
case let( x, y ):
	print("Point ( \(x)), \(y)) Lies Somewhere Else...")
}

//___________________________________________________________
//
//
//___________________________________________________________

let stillAnotherPoint = (9, 0)

switch stillAnotherPoint {
case ( let distance, 0 ), ( 0, let distance ):
	print("On An Axis: \(distance) From Origin")
default:
	print("Not On An Axis")
}


//___________________________________________________________
//
//
//___________________________________________________________

let puzzleInput = "What Is The Capital Of India?"
var puzzleOutput = ""

for character in puzzleInput {
	switch character {
	case "a", "e", "i", "o", "u", " ":
		continue // Continue Statement
	default:
		puzzleOutput.append( character )
	}
}

print( puzzleOutput )

//___________________________________________________________
//
//
//___________________________________________________________

let integerToDescribe = 5
var description = "The Number \(integerToDescribe) Is: "

switch integerToDescribe {
case 2, 3, 5, 7, 11, 13, 17, 19:
	description += " A Prime Number "
	fallthrough
default:
	description += " and also An Integer"
}

print(description)

// fallthrough Is Opposite Of break

//___________________________________________________________
//
// Labeled Statements
//___________________________________________________________

board = [Int]( repeating: 0, count : finalSquare + 1 )

print( board )

board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08

print( board )

square = 0
diceRoll = 0 

// Labelling While Loop
gameLoop: while square < finalSquare {
	// Roll The Dice 
	// NOTE IT SHOULD BE RANDOM But Time Being Just Incrementing By 1
	diceRoll = diceRoll + 1
	if diceRoll == 7 {
		diceRoll = 1
	}

	// Move By The Rolled Dice Number

	switch square + diceRoll {
	case finalSquare:
		break gameLoop 		// Using Label With break
	case let newSquare where newSquare > finalSquare:
		continue gameLoop  	// Using Label With continue
	default:
		square += diceRoll
		square += board[square]
	}
}

print("Game Over!!!")




//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

