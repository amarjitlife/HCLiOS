//___________________________________________________________

/*
Command To Compile Code
swiftc SwiftOperators.swift -o operators

Command To Run Code
./operators
*/

//___________________________________________________________
//
// ASSIGNMENT OPERATOR
//___________________________________________________________

let b = 10
var a = 5

a = b
print(a, b)

let (x, y) = (10, 20)
print(x, y)


//___________________________________________________________
//
// ARITHMETIC OPERTORS
//___________________________________________________________

var result = 0

result = a + b
print( result )

result = a - b
print( result )

result = a * b
print( result )

result = a / b
print( result )

result = 9 % 4
print( result )

//___________________________________________________________
//
// STRING CONCATINATION 
//___________________________________________________________

print( "Hello" + "World" ) // String Concatination

let dog: Character = "🐶"
let dogcow = "🐶" + "🐮"

print( dog )
print( dogcow )


//___________________________________________________________
//
// INCREMENT AND DECREMENT 
//___________________________________________________________

var i = 11

// Increment and Decrement Operators NOT SUPPORTED IN SWIFT
// i++
// print( i )

// ++i
// print( i )

i = i + 1
print( i )

i += 1
print( i )

i = i - 1
print( i )

i -= 1
print( i )


//___________________________________________________________
//
// UNIARY MINUS OPERATOR
//___________________________________________________________


let three = 3
let minusThree = -three
let plusThree = -minusThree

print( minusThree, plusThree )

 
//___________________________________________________________
//
// COMPARISION OPERATORS
//___________________________________________________________

// Can Compare Int, Float, Double Type Data
print( 1 == 1 )
print( 2 != 1 )
print( 2 > 1 )
print( 1 < 2 )
print( 1 <= 2 )
print( 2 >= 1 )

let name = "world"

// Comparing Strings
if name == "world" {
	print("Hello World!")
} else {
	print("Call To Universe....")
}

// Can Compare Tuples
var testResult: Bool

testResult = (1, "Zebra") < (2, "Apple")
print( testResult )

testResult = (3, "Apple") < (3, "Bird")
print( testResult )

testResult = (4, "Dog") == (4, "Dog")
print( testResult )

testResult = ("blue", -1 ) < ("purple", 1)
print( testResult )

testResult = ("purple", -1 ) < ("purple", 1)
print( testResult )

testResult = ("purple", 10 ) < ("purple", 1)
print( testResult )

testResult = (10, "Zebra") < (2, "Apple")
print( testResult )

testResult = (10, "Zebra") < (10, "Apple")
print( testResult )

// NOTE
// The Swift standard library includes tuple comparison operators 
// for tuples with fewer than seven elements. 

// To compare tuples with seven or more elements, you must implement 
// the comparison operators yourself.

// error: binary operator '<' cannot be applied to two '(String, Bool)' operands
// testResult = ("blue", false )  < ("purple", true )
// print( testResult )

// error: binary operator '<' cannot be applied to two 'Bool' operands
// testResult = false < true

//___________________________________________________________
//
// TERNARY OPERATOR
//___________________________________________________________

let contentHeight = 50
let hasHeader = false

var choiceValue: Int

if hasHeader {
	choiceValue = 50
} else if ( contentHeight == 40 ) {
	choiceValue = 10
} else {
	choiceValue = 100
}

print("Choice Value: ", choiceValue )


choiceValue = ( hasHeader ? 50 : ( contentHeight == 40 ) ? 10 : 100 )
print("Choice Value: ", choiceValue )

var rowHeight: Int

if hasHeader {
	rowHeight = contentHeight + 50
} else {
	rowHeight = contentHeight + 20	
}
print("Row Height: ", rowHeight )


rowHeight = contentHeight + ( hasHeader ? 50 : 20 )
print("Row Height: ", rowHeight )

//___________________________________________________________
//
// RANGE OPERATOR
//___________________________________________________________

// for Loop Iterating On Range Operator

// 1...5 Range Operator Is Equivalent To Close Interval [1, 5]
// i.e. Both End Points Are Inclusive
//		Hence Value It Will Generate Are 1, 2, 3, 4, 5
for index in 1...5 {
	print( index )
}

// 1..<5 Range Operator Is Equivalent To Interval [1, 5)
// i.e. Both End Points Are Inclusive
//		Hence Value It Will Generate Are 1, 2, 3, 4
for index in 1..<5 {
	print( index )
}

let names = [ "Kohli", "Bumra", "Rohit", "Shammi", "Iyer" ]
let count = names.count

for i in 0..<count {
	print( i, names[i] )
}


for name in names {
	print( name )
}

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

 

