
//___________________________________________________________

/*
Command To Compile Code
swiftc SwiftFunctions.swift -o functions

Command To Run Code
./functions
*/

//___________________________________________________________
//
// FUNCTIONS IN SWIFT
//___________________________________________________________

// Function Definition
//		It Doesn't Take Any Argument and Doesn't Return Anything
func sayHello() {
	print("Hello World!")
}

sayHello()

// Function Definition
//		It Takes One Argument of Type String and Returns One Value Of Type String
//					Named Argument
// Function Argument Type 	: String
// Function Return Type 	: String
func sayHelloAgain( personName: String ) -> String {
	return "Hello, " + personName + "!"
}

// error: missing argument label 'personName:' in call
// let hello = sayHelloAgain( "Anushka Sharma" )

// In Function Call
//						   Named Argument Must Be Specified 
var hello = sayHelloAgain( personName: "Anushka Sharma" )
print( hello )

hello = sayHelloAgain( personName: "Virat Kohli" )
print( hello )


// Function Definition
//		It Takes Two Arguments of Type Int and Returns One Value Of Type Int
//					Named Arguments
func lengthOfLine( start: Int, end: Int) -> Int {
	return end - start
}

print( lengthOfLine( start: 1, end: 10) )


// Function Definition
//		It Takes One Argument of Type String and Returns One Value Of Type Int
//					Named Argument
// Function Argument Type 	: String
// Function Return Type 	: Int


func printAndCount( stringToPrint: String ) -> Int {
	print( stringToPrint )
	return stringToPrint.count
}

print( printAndCount( stringToPrint: "Hello World!") )
print( printAndCount(stringToPrint: "Ramayana") )

//___________________________________________________________
//
// RETURN MULTIPLE VALUES
//___________________________________________________________

func minimumMaximum( array: [Int] ) -> (min: Int, max: Int) {
	var currentMin = array[0]
	var currentMax = array[0]

	for value in array[1..<array.count] {
		if value < currentMin {
			currentMin = value
		} else if value > currentMax {
			currentMax = value
		}
	}

	return (currentMin, currentMax)
}

var bounds = minimumMaximum( array: [10, 20, 100, -900, 400, 200] )
print( bounds )
print( bounds.0, bounds.1 )
print( bounds.min, bounds.max )


bounds = minimumMaximum( array: [10, 20, 100, 900, 400, 2000] )
print( bounds )
print( bounds.0, bounds.1 )
print( bounds.min, bounds.max )

//___________________________________________________________
//
// Function Parameters Can Have Two Names
// External Parameter Name and Internal Parameter Name
//___________________________________________________________

// Function Definition
//		It Takes One Argument of Type String
//					Named Argument
// Function Argument Type 	: String
// Function Argument Have Two Names
//		externalParameterName
//		internalParameterName

func someFunction( externalParameterName internalParameterName: String ) {
	// internalParametereName Is Local To Function
	//		Hence Used Inside Function
	let hello = "Hello " + internalParameterName 
	print( hello )
}

// internalParametereName Is Parameter Name For Outside World
//		Hence Used In Function Call
someFunction( externalParameterName: "Priyanka Chopra!" )
someFunction( externalParameterName: "Nayantara!" )

// External Parameter Name and Internal Parameter Name Are Like Elephant Theek
//		externalParameterName : Elephant Theeth Used Show
//		internalParameterName : Elephant Theeth Used To Eat


// Suppose Following join Function Comes From Library
//		Function Arguments Names Are Not Good One..

func join( s1: String, s2: String, joiner: String ) -> String {
	return s1 + joiner + s2
}

var result = join( s1: "Hello", s2: "World", joiner: "  ")
print( result )

// This Is Our New join Function With Better External Argument Names
// External Parameters Names: string, toString, withJoiner
// Internal Parameters Names: s1, s2, joiner
func join(string s1: String, toSting s2: String, withJoiner joiner: String ) -> String {
	let result = join( s1: s1, s2: s2, joiner: joiner)
	return result
}

// We Are Calling Our join Function With Better API
result = join( string: "Deepika Padukone", toSting: "Ranbir Singh", withJoiner: " + " )
print( result )


//___________________________________________________________

// If Function Argument Have ONE Name
//		externalParameterName Is Same As internalParameterName

func containsCharacter( string: String, charaterToFind: Character ) -> Bool {
	for character in string {
		if character == charaterToFind {
			return true
		}
	}
	return false
}

var contains = containsCharacter( string: "Ding Dong Ting Tong", charaterToFind: "o")
print( contains )

contains = containsCharacter( string: "Ding Dong Ting Tong", charaterToFind: "M")
print( contains )


//___________________________________________________________
//
// FUNCTION WITH DEFAULT VALUES
//___________________________________________________________


//													Argument With Default Value			
func concatenate(string: String, toString: String, withJoiner: String = " ") -> String {
	return string + withJoiner + toString
}

// Function Can Be Called With 2 Arguments
//		3rd Argument Will Take Default Value
result = concatenate( string: "Hello", toString: "World")
print( result )

// Function Can Be Called With 3 Arguments
result = concatenate( string: "Hello", toString: "World", withJoiner: "####")
print( result )


//___________________________________________________________
//
// Constant Number Of Parameters
//___________________________________________________________

func alignRight( string: String, totalLength: Int, padding: Character ) -> String {
	var stringResult: String = ""
	let amountToPad = totalLength - string.count

	if amountToPad < 1 {
		return string
	}

	let padString = String( padding )

	for _ in 1...amountToPad {
		stringResult = padString + stringResult 
	}

	stringResult = stringResult + string
	return stringResult
}

var originalString = "Hello"
var paddedString = alignRight( string: originalString, totalLength: 10, padding: "_" )
print( paddedString )

originalString = "Good"
paddedString = alignRight( string: originalString, totalLength: 20, padding: "_" )
print( paddedString )


//___________________________________________________________
//
// Variable Number Of Parameters
//___________________________________________________________

// Variadic Functions
//		Variadic Arguments i.e. Variable Number Of Arguments
func arithmeticMean( numbers: Double... ) -> Double {
	var total: Double = 0

	for number in numbers {
		total += number
	}

	return total / Double( numbers.count )
}

var mean: Double = 0.0

mean = arithmeticMean()
print( mean )

mean = arithmeticMean(numbers: 10)
print( mean )

mean = arithmeticMean(numbers: 10, 20)
print( mean )

mean = arithmeticMean(numbers: 10, 20, 30, 40, 50)
print( mean )

mean = arithmeticMean(numbers: 1, 2, 3, 4, 5)
print( mean )

mean = arithmeticMean(numbers: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
print( mean )


//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________


