//
//  ViewController.swift
//  CountryList2
//
//  Created by Nagarajan on 8/27/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var tableView: UITableView!
    var countryList:[[String]] = [["Afghanistan"],
                                  ["Bahrain", "Bangladesh", "Bhutan","Brunei"],
                                  ["China"],
                                  ["East Timor"],
                                  ["India", "Indonesia", "Iran", "Iraq", "Israel"],
                                  ["Japan", "Jordan"],
                                  ["Kazakhstan", "Korea North", "Korea South", "Kuwait", "Kyrgyzstan"],
                                  ["Laos", "Lebanon"],
                                  ["Malaysia", "Maldives", "Mongolia", "Myanmar (Burma)"],
                                  ["Nepal"],
                                  ["Oman"],
                                  ["Pakistan"],
                                  ["Qatar"],
                                  ["Russia"],
                                  ["Saudi Arabia", "Singapore", "Sri Lanka", "Syria"],
                                  ["The Philippines","Taiwan", "Tajikistan", "Thailand", "Turkey", "Turkmenistan"],
                                  ["United Arab Emirates", "Uzbekistan"],
                                  ["Vietnam"],
                                  ["Yemen"]
                                 ]


    let cellIdentifier = "CountryCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func loadView()
    {
        super.loadView()
        self.tableView = UITableView(frame: self.view.bounds, style: UITableView.Style.grouped)
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.view.addSubview(self.tableView)
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return self.countryList.count;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.countryList[section].count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        var cell = tableView.dequeueReusableCell(withIdentifier: self.cellIdentifier)
        if cell == nil
        {
            cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: self.cellIdentifier)
        }
        cell!.textLabel?.text = self.countryList[indexPath.section][indexPath.row]
        return cell!
    }


}

