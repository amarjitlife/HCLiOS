//
//  ViewController.swift
//  CountryList1
//
//  Created by Nagarajan on 8/27/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    
    var tableView: UITableView!
    var countryList:[String] = ["Afghanistan", "Bahrain", "Bangladesh", "Bhutan",
                                "Brunei", "Cambodia", "China", "East Timor", "India",
                                "Indonesia", "Iran", "Iraq", "Israel", "Japan", "Jordan",
                                "Kazakhstan", "Korea North", "Korea South", "Kuwait", "Kyrgyzstan",
                                "Laos", "Lebanon", "Malaysia", "Maldives", "Mongolia", "Myanmar (Burma)",
                                "Nepal", "Oman", "Pakistan", "The Philippines", "Qatar", "Russia",
                                "Saudi Arabia", "Singapore", "Sri Lanka", "Syria", "Taiwan", "Tajikistan",
                                "Thailand", "Turkey", "Turkmenistan", "United Arab Emirates", "Uzbekistan",
                                "Vietnam", "Yemen"]

    let cellIdentifier = "CountryCell"
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func loadView()
    {
        super.loadView()
        self.tableView = UITableView(frame: self.view.bounds, style: UITableView.Style.plain)
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.view.addSubview(self.tableView)
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.countryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        var cell = tableView.dequeueReusableCell(withIdentifier: self.cellIdentifier)
        if cell == nil
        {
            cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: self.cellIdentifier)
        }
        cell!.textLabel?.text = self.countryList[indexPath.row]
        return cell!
    }
}

