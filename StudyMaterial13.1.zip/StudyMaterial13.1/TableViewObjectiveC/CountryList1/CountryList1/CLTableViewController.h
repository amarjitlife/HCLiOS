//
//  CLTableViewController.h
//  1.NameList
//
//  Created by josh on 8/1/14.
//  Copyright (c) 2014 TechHue Systems. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLTableViewController : UITableViewController <UITableViewDataSource, UITableViewDelegate>


@end
