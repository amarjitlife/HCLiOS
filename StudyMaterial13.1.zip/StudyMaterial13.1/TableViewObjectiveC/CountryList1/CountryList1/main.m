//
//  main.m
//  CountryList1
//
//  Created by josh on 8/1/14.
//  Copyright (c) 2014 TechHue Systems. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CLAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CLAppDelegate class]));
    }
}
