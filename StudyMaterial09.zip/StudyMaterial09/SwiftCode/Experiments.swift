

var something: String? = "Hello"
print( something )

print( something! ) // Unwrapping

something = nil

if something != nil {
	print( something! ) // Unwrapping
} else {
	print("Nullable Found")
}

// Following Code 01 And Code 02 Are Equivalent

// CODE 01: if-else Idioms
if let unwrappedValue = something {
	print( unwrappedValue )
} else {
	print("Nullable Found")
}


// CODE 02
if something != nil  {
	let unwrappedValue = something!
	print( unwrappedValue )
} else {
	print("Nullable Found")
}
