//___________________________________________________________

/*
Command To Compile Code
swiftc SwiftStringsAndCharacters.swift -o strings

Command To Run Code
./strings
*/

//___________________________________________________________
//
// EMPTY STRING
//___________________________________________________________

let someString = "Some Dummy String"
print( someString )

// Creating Empty String Using String Quotes
let emptyString = ""
// Creating Empty String Using String Constructor
let anotherEmptyString = String()

if emptyString.isEmpty {
	print("It's Empty String")
}

if anotherEmptyString.isEmpty {
	print("It's Empty String")
}

//___________________________________________________________
//
// STRING MUTABILITY
//___________________________________________________________

// MUTABLE STRING
var variableString = "Horse"
variableString += " and Carriage" // variableString = variableString + " and Carriage"

print(variableString )

// IMMUTABLE STRING
let constantString = "HighLander"
print( constantString )


//___________________________________________________________
//
// STRING CHARACTERS
//___________________________________________________________

let hello = "Hello!"

// Iterating Over String Characters
for character in hello {
	print( character )
}

for character in "Hello!" {
	print( character )
}

// let exclamationMark1 = "!"
let exclamationMark: Character = "!"
print( exclamationMark)

// Array Of Character Type Data 
let catCharacters: [Character] = [ "C", "a", "t" ]
print(catCharacters)

// Constructing String Using Characters Array
let catString = String( catCharacters )
print(catString)

let string1 = "Hello, "
let string2 = "Julie"

var welcome = string1 + string2
print( welcome )

// Concatenating String and Character
welcome.append( exclamationMark )
print( welcome )

// Escaping Quote With Backwards \"
let wiseWords = " \"Imagination Is More Important Than Knowledge\", Albert Einstein"
print( wiseWords )

//___________________________________________________________
//
// UNICODE CHARACTER AND UNICODE POINTS
//___________________________________________________________

// FOR Every Unicode Character There Is/Are Unicode Points
let dollarSign = "\u{24}"
let blackHeart = "\u{2665}"
let sparklingHeart = "\u{1F496}"

print( dollarSign, blackHeart, sparklingHeart )

let smiley1 = "\u{1F600}"
let smiley2 = "\u{1F605}"
let smiley3 = "\u{1F923}"
// U+1F929	
let smiley4 = "\u{1F929}"

print( smiley1, smiley2, smiley3, smiley4 )

// Unicode Character With Single Unicode Point
let eAcute: Character = "\u{00E9}"
print( eAcute )

let eAcute1 = "\u{00E9}"
print( eAcute1 )

// Unicode Character With Multiple Unicode Points
let eAcuteCombined: Character = "\u{0065}\u{0301}"
print( eAcuteCombined )

let eAcuteCombined1 = "\u{0065}\u{0301}"
print( eAcuteCombined1 )

let precomposed: Character = "\u{D55C}"                 // 한
let decomposed: Character = "\u{1112}\u{1161}\u{11AB}"  // ᄒ, ᅡ, ᆫ

print( precomposed )
print( decomposed )

let cafe = "cafe"
print( cafe )
print( "Length Of cafe:", cafe.count )

let cafeAgain = "cafe\u{301}"
print( cafeAgain )
print( "Length Of cafAgain:", cafeAgain.count )

var cafeAgain1 = "cafe"
let something: Character = "\u{301}"
cafeAgain1.append( something )
print( cafeAgain1 )
print( "Length Of cafAgain1:", cafeAgain1.count )

//___________________________________________________________
//
// STRING INDEXING
//___________________________________________________________

// OLDER APIs
// let greeting = "Guten Tag!"
// print( greeting[ greeting.startIndex ] )
// print( greeting[ greeting.endIndex.predecessor() ] )
// print( greeting[ greeting.startIndex.successor() ] )

// NEWER APIs
let greeting = "Guten Tag!"
print( greeting[ greeting.startIndex ] ) // G

print( greeting[ greeting.index( before: greeting.endIndex) ] ) // !
print( greeting[ greeting.index( after: greeting.startIndex) ] ) // u

let index = greeting.index(greeting.startIndex, offsetBy: 7 )
print( greeting[index] ) // a

for index in greeting.indices {
	print( index, greeting[ index ] )
}

for character in greeting {
	print( character )
}


var welcome1 = "Hello"
print( welcome1 )

welcome1.insert( "!", at: welcome1.endIndex )
print( welcome1 )

welcome1.insert( contentsOf: " Jolly", at: welcome1.index( before: welcome1.endIndex ) ) 
print( welcome1 )

// welcome1.insert( contentsOf: " Jolly", at: welcome1.index( before: welcome1.startIndex ) ) 
// print( welcome1 )

welcome1.remove(at: welcome1.index(before: welcome1.endIndex) )
print( welcome1 )

let range = welcome1.index( welcome1.endIndex, offsetBy: -6)..<welcome1.endIndex
welcome1.removeSubrange( range )
print( welcome1 )

// print( greeting[ greeting.endIndex ] )
// print( greeting[ greeting.startIndex ] )

welcome1.insert("!", at: welcome1.startIndex)
print ("my experiment", welcome1)

//___________________________________________________________
//
// COMPARING STRINGS
//___________________________________________________________

// Comparing Strings
let quotation = "We're a lot alike, you and I."
let sameQuotation = "We're a lot alike, you and I."
if quotation == sameQuotation {
    print("These two strings are considered equal")
}

//_________________________

// "Voulez-vous un café?" using LATIN SMALL LETTER E WITH ACUTE
let eAcuteQuestion = "Voulez-vous un caf\u{E9}?"

// "Voulez-vous un café?" using LATIN SMALL LETTER E and COMBINING ACUTE ACCENT
let combinedEAcuteQuestion1 = "Voulez-vous un caf\u{65}\u{301}?"
let combinedEAcuteQuestion2 = "Voulez-vous un cafe\u{301}?"

if eAcuteQuestion == combinedEAcuteQuestion1 {
	print("These Two Strings Are Considered Equal")
} else {
	print( "Unequal Strings ")
}

if eAcuteQuestion == combinedEAcuteQuestion2 {
	print("These Two Strings Are Considered Equal")
} else {
	print( "Unequal Strings ")
}

if combinedEAcuteQuestion1 == combinedEAcuteQuestion2 {
	print("These Two Strings Are Considered Equal")
} else {
	print( "Unequal Strings ")
}

let latinCapitalLeterA: Character = "\u{41}"
let cyrillicCapitalLetterA: Character = "\u{0410}"

print( latinCapitalLeterA )
print( cyrillicCapitalLetterA )

if latinCapitalLeterA != cyrillicCapitalLetterA {
    print("These two characters are not equivalent")
} else {
	print( "Equal Strings ")
}

// Two String values (or two Character values) are considered equal 
// if their extended grapheme clusters are canonically equivalent. 
///Extended grapheme clusters are canonically equivalent if they have 
// the same linguistic meaning and appearance, even if they’re composed 
// from different Unicode scalars behind the scenes.

//___________________________________________________________
//
// Prefix and Suffix Equality
//___________________________________________________________

let romeoAndJuliet = [
    "Act 1 Scene 1: Verona, A public place",
    "Act 1 Scene 2: Capulet's mansion",
    "Act 1 Scene 3: A room in Capulet's mansion",
    "Act 1 Scene 4: A street outside Capulet's mansion",
    "Act 1 Scene 5: The Great Hall in Capulet's mansion",
    "Act 2 Scene 1: Outside Capulet's mansion",
    "Act 2 Scene 2: Capulet's orchard",
    "Act 2 Scene 3: Outside Friar Lawrence's cell",
    "Act 2 Scene 4: A street in Verona",
    "Act 2 Scene 5: Capulet's mansion",
    "Act 2 Scene 6: Friar Lawrence's cell"
]

var act1SceneCount = 0
var act2SceneCount = 0
var mansionCount = 0

for scene in romeoAndJuliet {
    if scene.hasPrefix("Act 1") {
        act1SceneCount += 1
    }

    if scene.hasPrefix("Act 2") {
        act2SceneCount += 1
    }

    if scene.hasSuffix("mansion") {
        mansionCount += 1
    }
}

print("There are \(act1SceneCount) scenes in Act 1")
print("There are \(act2SceneCount) scenes in Act 2")
print("There are \(mansionCount) mansion")

// Unicode Representations of Strings
let dogString = "Dog!!🐶"

for character in dogString {
	print( "\(character)", terminator: " " )
}

print()
for unicodePoint in dogString.utf8 {
	print( "\(unicodePoint)", terminator: " " )
}

print()
for unicodePoint in dogString.utf16 {
	print( "\(unicodePoint)", terminator: " " )
}

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
