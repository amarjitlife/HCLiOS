#include <stdio.h>
#include <limits.h>
#include <stdlib.h>


/*
// Write Following Sum Function Code In C with Given Signature
    int sum( int first, int second) {

    }
*/


// Write Following Sum Function Code In Swift with Given Signature

//___________________________________________________

// DESIGN 01 : BAD DESIGN
// What Is The Challenge With This Design?
//      It Has Overflow/Underflow Issues?


int sumDesign1(int first, int second) {
	return first + second;
}

//___________________________________________________

// DESIGN 02 : BAD DESIGN
// What Is The Challenge With This Design?
//      It Has Overflow/Underflow Issues?
int sumDesign2(int first, int second) {
	int result = 0;

	result = first + second;
	// ALWAYS TRUE CONDITION
	if ( result >= INT_MIN && result <= INT_MAX ) {
		return result;
	} else {
		printf("\nCan't Calcualte Sum Of Given Values\n");
		return 0;
	}
}

void playWithSumDesigns() {
	int result = 0, a, b;

	a = 2147483647;
	b = 10;
	result = sumDesign1(a, b);
	printf("\nDesign 01 : %d", result); // Design 01 : -2147483639

	a = -2147483648;
	b = -10;
	result = sumDesign1(a, b);
	printf("\nDesign 01 Result : %d", result); // Design 01 Result : 2147483638

	a = 2147483647;
	b = 10;
	result = sumDesign2(a, b);
	printf("\nDesign 02 Result : %d", result); // Design 02 Result : -2147483639

	a = -2147483648;
	b = -10;
	result = sumDesign2(a, b);
	printf("\nDesign 02 Result : %d", result); // Design 02 Result : 2147483638
}

// Function: playWithSumDesigns


//___________________________________________________
//___________________________________________________

/*
// DESIGN 03
// Write Following Sum Function Code In C/Swift with Given Signature
    // It Should Return Valid Arithematic Sum 
    //      Otherwise 
    // Print Can't Calculate Sum Of Given Values

// Write Following Sum Function Code In C with Given Signature
    int sum( int first, int second) {

    }

// Write Following Sum Function Code In Swift with Given Signature

    func sum( first: Int, second: Int ) -> Int {

    }
*/

//___________________________________________________
//___________________________________________________

int sumDesign3( int first, int second ) {
	int result = 0;

	if ( ( ( second > 0 ) && first > ( INT_MAX - second ) ) || 
		 ( ( second < 0 ) && first < ( INT_MIN - second ) ) ) {
		printf("\nCan't Calcualte Sum Of Given Values");
		exit( 1 );
		// return 0;
	} else {
		result = first + second;
		return result;
	}
}

void playWithSumDesign3() {
	int result = 0, a, b;

	a = 2147483647;
	b = 10;
	result = sumDesign3(a, b);
	printf("\nDesign 03 Result : %d", result); // Design 02 Result : -2147483639

	a = -2147483648;
	b = -10;
	result = sumDesign3(a, b);
	printf("\nDesign 03 Result : %d", result); // Design 02 Result : 2147483638
}

//___________________________________________________
//___________________________________________________

/*
// DESIGN 04
// Write Following Sum Function Code In C/Swift with Given Signature
    // It Should Return Valid Arithematic Sum 
    //      Otherwise 
    // Return Invalid Result

// Write Following Sum Function Code In C with Given Signature
    int sum( int first, int second) {

    }
*/

typedef struct optional_type {
	int value; // Valid Value Is Embedded Inside Optional
	int valid; // Validity Test
} OptionalInt;

// Type Safety
//		Respecting Type Definition Like A God!
//		Confirming To Type Definition

OptionalInt sumDesign4( int first, int second ) {
	OptionalInt result = { 0, 0 };

	// Type Safe Code
	// Follows Closure Law In C int Type
	if ( ( ( second > 0 ) && first > ( INT_MAX - second ) ) || 
		 ( ( second < 0 ) && first < ( INT_MIN - second ) ) ) {
		result.valid = 0;
	} else {
		result.value = first + second;
		result.valid = 1;
	}

	return result;
}

/*
// In Swift Code Will Be Similar To Above
// int? sumDesign4( int first, int second ) {

func sumDesign4InSwift( first: Int , second: Int ) -> Int? {
	int? result = nil;
	if ( ( ( second > 0 ) && first > ( INT_MAX - second ) ) || 
		 ( ( second < 0 ) && first < ( INT_MIN - second ) ) ) {
		result = nil;
	} else {
		result.value = first + second;
		// result.valid = 1;
	}

	return result;
}
*/

void playWithSumDesign4() {
	OptionalInt result = { 0, 0 }; 
	int a, b;

	a = 2147483647;
	b = 10;
	result = sumDesign4(a, b);

	if ( result.valid != 0 ) {
		printf("\nDesign 04 Result : %d", result.value); 
	} else {
		printf("\nInvalid Sum Value");
	}

	a = -2147483648;
	b = -10;
	result = sumDesign4(a, b);

	if ( result.valid != 0 ) {
		printf("\nDesign 04 Result : %d", result.value ); 
	} else {
		printf("\nInvalid Sum Value");
	}
}


//___________________________________________________
//___________________________________________________

int summation(int x, int y) { return x + y; }
int substraction(int x, int y) { return x - y; }
int multiplication(int x, int y) { return x * y; }

// Polymorphic Function
//		Mechanism: By Passing Behaviour To Behviour
//					i.e. By Passing Function To Function
int calculator(int x, int y, int (*operation)(int, int) ) {
	return operation(x, y);
}

void playWithCalculator() {
	int a = 300;
	int b = 100;

	int result = 0;

	result = calculator(a, b, summation); // Configuring As summation
	printf("\nResult : %d", result);

	result = calculator(a, b, substraction);  // Configuring As substraction
	printf("\nResult : %d", result);

	result = calculator(a, b, multiplication);  // Configuring As substraction
	printf("\nResult : %d", result);
}

// Function: playWithCalculator
// Result : 400
// Result : 200

//___________________________________________________
//___________________________________________________

/* In Java/C++/C#/Swift Following Syntatic Sugar Get Converted Into
//		What Is Written C
class Human {
	int id;
	char name[100];
	// void (*dance)();
	void doBhangara() {
		printf("\nBalleeee Baalleeee.... Oyee Hoyee.!!!!");
	}

	void doBreakdance() {
		printf("\nDoing Break Dance... Slow and Fast Movements!!!");
	}
}
*/

// Encapsulation
typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;


void doBhangara() {
	printf("\nBalleeee Baalleeee.... Oyee Hoyee.!!!!");
}

void doBreakdance() {
	printf("\nDoing Break Dance... Slow and Fast Movements!!!");
}

void playWithHuman() {

					// Constuctor Call
	Human gabbar = { 420, "Gabbar Singh", doBhangara };
	
	printf("\nGabbar ID: %d", gabbar.id );
	printf("\nGabbar Name: %s", gabbar.name );
	gabbar.dance();

					// Constuctor Call
	Human basanti = { 100, "Basanti", doBreakdance };
	
	printf("\nGabbar ID: %d", basanti.id );
	printf("\nGabbar Name: %s", basanti.name );
	basanti.dance();
}

//___________________________________________________
//___________________________________________________
//___________________________________________________
//___________________________________________________
//___________________________________________________
//___________________________________________________

int main() {
	printf("\n\nFunction: playWithSumDesigns");
	playWithSumDesigns();

	printf("\n\nFunction: playWithSumDesign4");
	playWithSumDesign4();

	printf("\nFunction: playWithCalculator");
	playWithCalculator();

	printf("\n\nFunction: playWithHuman");
	playWithHuman();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");

	return 0;
}
