
//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftProtocols.swift -o protocols

Command To Run Code
./protocols
*/
//___________________________________________________________


//___________________________________________________________
//
// PROTOCOLS
//___________________________________________________________

// Protocols

// Define requirements that conforming types must implement.

// A protocol defines a blueprint of methods, properties, and 
// other requirements that suit a particular task or piece of functionality. 
// The protocol can then be adopted by a class, structure, or enumeration 
// to provide an actual implementation of those requirements. 

// Any type that satisfies the requirements of a protocol is said to 
// conform to that protocol.

// In addition to specifying requirements that conforming types must 
// implement, you can extend a protocol to implement some of these 
// requirements or to implement additional functionality that 
// conforming types can take advantage of.


//___________________________________________________________
//
// PROTOCOLS SYNTAX
//___________________________________________________________

// You define protocols in a very similar way to classes, structures, and enumerations:

protocol SomeProtocol {
    // protocol definition goes here
}


// Custom types state that they adopt a particular protocol by placing 
// the protocol’s name after the type’s name, separated by a colon, as 
// part of their definition. 

//Multiple protocols can be listed, and are separated by commas:

protocol FirstProtocol {

}

protocol AnotherProtocol {

}

struct SomeStructure: FirstProtocol, AnotherProtocol {
    // structure definition goes here
}

// +++NOTE+++
// If a class has a superclass, list the superclass name before any protocols 
// it adopts, followed by a comma:

class SomeSuperclass {

}

class SomeClass: SomeSuperclass, FirstProtocol, AnotherProtocol {
    // class definition goes here
}

//___________________________________________________________
//
// Property Requirements
//___________________________________________________________

// Property Requirements
// A protocol can require any conforming type to provide an 
// instance property or type property with a particular name and type. 
// The protocol doesn’t specify whether the property should be a stored property 
// or a computed property — 

// It only specifies the required property name and type. The protocol 
// also specifies whether each property must be gettable or gettable and settable.

// Property requirements are always declared as variable properties, 
// prefixed with the var keyword. Gettable and settable properties are 
// indicated by writing { get set } after their type declaration, and 
// gettable properties are indicated by writing { get }.

protocol SomeProtocolAgain {
	// Instance Properties
	var mustBeSettable: Int { get set }
	var doesNotNeedToBeSettable: Int { get }
}


protocol AnotherProtocolAgain {
	// Type Property
	static var someTypeProperty: Int { get set }
}

//___________________________________________________________
//
// PROTOCOL EXAMPLES
//___________________________________________________________

// Defined Protocol
protocol FullyNamed {
	var fullName: String { get }
}

// Structure Confirming/Implementing To Protocol
struct Person: FullyNamed {
	var fullName: String
}

// Class Confirming/Implementing To Protocol
class StarShip : FullyNamed {
	var prefix: String?
	var name: String 

	init( name: String, prefix: String? = nil ) {
		self.name 	= name
		self.prefix = prefix
	}

	var fullName: String {
		// get() {
		return ( ( prefix != nil  ? prefix! + " " : "" ) + name )
		// }		
	}
}

let gabbar = Person( fullName: "Gabbar Singh")
print( gabbar.fullName )

let vikrant = StarShip( name: "Vikrant", prefix: "INS")
print( vikrant.fullName )


//___________________________________________________________
//
// Implementing Instance Method 
//___________________________________________________________


protocol RandomNumberGenerator {
	func random() -> Double
}

class LinearCongruentialGenerator : RandomNumberGenerator {
	var lastRandom = 42.9
	let m = 33434.0
	let a = 343.0
	let c = 22344.0

	func random() -> Double {
		lastRandom = ( ( lastRandom * a + c )).truncatingRemainder( dividingBy: m )
		return lastRandom / m
	}
}

let generator = LinearCongruentialGenerator()
print("Random Number Generated: ", generator.random() )
print("Random Number Generated: ", generator.random() )
print("Random Number Generated: ", generator.random() )

class SomeRandomGenerator : RandomNumberGenerator {
	var lastRandom = 42.9

	func random() -> Double {
		lastRandom = ( ( lastRandom * 495049504950909 + 89898989 )).truncatingRemainder( dividingBy: 10 )
		return lastRandom / 10
	}
}

let generator1 = SomeRandomGenerator()
print("Random Number Generated: ", generator1.random() )
print("Random Number Generated: ", generator1.random() )
print("Random Number Generated: ", generator1.random() )


//___________________________________________________________
// 
// Mutating Method Requirements
//___________________________________________________________

protocol Togglable {
	mutating func toggle()
}

enum OnOffSwitch : Togglable {
	case off, on 

	mutating func toggle() {
		switch self {
			case .off:
				self = .on
			
			case .on:
				self = .on
		}
	}
}

enum CapsLockButton : Togglable {
	case off, on 

	mutating func toggle() {
		switch self {
			case .off:
				self = .on
			
			case .on:
				self = .on
		}
	}
}


var lightSwitch = OnOffSwitch.off
print( lightSwitch )

lightSwitch.toggle()
print( lightSwitch )

var capsLockButton = CapsLockButton.on
print( capsLockButton )

capsLockButton.toggle()
print( capsLockButton )

//___________________________________________________________
//
// // Required Initializers Using Protocols
//___________________________________________________________

protocol SomeMoreProtocol {
	init( someParameter: Int )
}

class SomeMoreClass : SomeMoreProtocol {
	var someParameter : Int
	// init() {
	required init( someParameter: Int ) {
		self.someParameter = someParameter
		print("SomeClass init Called...: ", someParameter)
	}

	func doSomething( something: String ) {
		print("Doing Something:", something)
	}
}


// You must also write the required modifier before every subclass 
// implementation of a required initializer, to indicate that the 
// initializer requirement applies to further subclasses in the chain. 
// You don’t write the override modifier when overriding a required designated initializer:

class SomeMoreSubClass: SomeMoreClass {
	// var someParameter : Int {
	// 		return 1000
	// }

	required init( someParameter: Int ) {
		super.init( someParameter: someParameter )
		print("SomeSubClass init Called...: ", someParameter)
	}

}

let some = SomeMoreClass( someParameter: 888 )
some.doSomething( something: "Dance")

let someSub = SomeMoreSubClass( someParameter: 999 )
someSub.doSomething( something: "Music")

// let protocolInstance = SomeMoreProtocol() 


//___________________________________________________________
//
// PROTOCOLS AS TYPES
//___________________________________________________________


class Dice {
	let sides: Int
	let generator: RandomNumberGenerator

	init( sides: Int, generator: RandomNumberGenerator ) {
		self.sides 		= sides
		self.generator 	= generator
	}

	func roll() -> Int {
		return Int( generator.random() * Double( sides )) + 1
	}
}


print( "\nTesting Dice Rolling..." )
var dice = Dice( sides: 6, generator: LinearCongruentialGenerator() )

for _ in 1...5 {
	print("Dice Rolling: ", dice.roll() )
}

//_________________________________


protocol DiceGame {
	var dice: Dice { get }
	func play()
}


protocol DiceGameProgressDelegate {
	func gameDidStart( game: DiceGame )
	func game( game: DiceGame, didStartnewTurnWithDiceRoll diceRoll: Int )
	func gameDidEnd( game: DiceGame )
}


class SnakesAndLadders: DiceGame {
	let finalSquare = 25
	var square = 0
	var board: [Int]

	let dice = Dice( sides: 6, generator: LinearCongruentialGenerator() )

	// gameProgress Is As Delegate
	//		Game Play Process Is Delegated To gameProgress Delegate
	//				This Delegate Knows
	//					How To Start Game?
						// How To Monitor Game Progress?
	//					How To End Game?

	// Delegate Is Of Protocol Type
	//		DiceGameProgressDelegate
	var gameProgress: DiceGameProgressDelegate?

	init() {
        board = [Int]( repeating: 0, count: finalSquare + 1 )
        board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
        board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08		
	}

	func play() {
		square = 0

		gameProgress?.gameDidStart( game: self )

		gameLoop: while square != finalSquare {
			let diceRoll = dice.roll()

			gameProgress?.game( game: self, didStartnewTurnWithDiceRoll: diceRoll )

			switch square + diceRoll {
				case finalSquare:
					break gameLoop

				case let newSquare where newSquare > finalSquare:
					continue gameLoop

				default:
					square += diceRoll
					square += board[ square ]
				}
		}

		gameProgress?.gameDidEnd( game: self )
	}
}


class DiceGameProgress: DiceGameProgressDelegate {
	var numnerOfTurns = 0

	func gameDidStart( game: DiceGame ) {
		numnerOfTurns = 0
		if game is SnakesAndLadders {
			print("Game Snakes And Ladders Started...")
		}
		print("Dice Used With Sides: ", game.dice.sides )
	}

	func game( game: DiceGame, didStartnewTurnWithDiceRoll diceRoll: Int ) {
		numnerOfTurns = numnerOfTurns + 1
		print("Rolled Dice: ", diceRoll )
	}

	func gameDidEnd( game: DiceGame ) {
		print("Game Lasted For Turns: ", numnerOfTurns )
	}
}


let snakesAndLaddersGame = SnakesAndLadders()
snakesAndLaddersGame.gameProgress = DiceGameProgress()

print("\nPlaying Snakes And Ladders Game...")
snakesAndLaddersGame.play()


//___________________________________________________________
//___________________________________________________________

/*

class Board {
	var board: [Int]	
}

class SnakesAndLaddersBoard : Board {
	init() {
        board = [Int]( repeating: 0, count: finalSquare + 1 )
        board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
        board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08		
	}
}


class MineSweeperBoard : Board {
	init() {
        board = [Int]( repeating: 0, count: finalSquare + 1 )
        board[03] = -01; board[06] = 11; board[09] = +09; board[10] = +02
        board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08		
	}	
}

class Move {
	func nextMove() { }
	func undoMove() { }
}

class SnakesAndLadderMove: Move {
	var dice: Dice? = nil 

	func nextMove() { 
		var dice = Dice()
		var number = dice.roll()
		return number
	}
}

class MineSweeperMove: Move {
	// Logic Is Local
}

class SnakesAndLadders: DiceGame {
	// Delegate Board Also
	//		Assign Board Based On Game Type
	var board: Board? = nil 

	// Delegate Move Also
	//		Assign Board Based On Game Type
	var move: Move? = nil 
	// gameProgress Is As Delegate
	//		Game Play Process Is Delegated To gameProgress Delegate
	//				This Delegate Knows
	//					How To Start Game?
						// How To Monitor Game Progress?
	//					How To End Game?

	var gameProgress: DiceGameProgressDelegate?

	func play() {
		square = 0

		gameProgress?.gameDidStart( game: self )

		gameLoop: while square != finalSquare {
			let move = move.nextMove()

			gameProgress?.game( game: self, didStartnewTurn: move )

			switch square + diceRoll {
				case finalSquare:
					break gameLoop

				case let newSquare where newSquare > finalSquare:
					continue gameLoop

				default:
					square += diceRoll
					square += board[ square ]
				}
		}

		gameProgress?.gameDidEnd( game: self )
	}
}

*/


//___________________________________________________________
//
// Adding Protocol Conformance with an Extension
//___________________________________________________________


protocol TextRepresentable {
    var textualDescription: String { get }

	func asText() -> String
}

// Using Extensions You Can Make Class Confirms To Protocol
extension Dice: TextRepresentable {
    var textualDescription: String { 
    	return "DICE"
    }

	func asText() -> String {
		return "A \(sides)-Sided Dice!"
	}
}

print( dice.asText() )

let diceAgain1 = Dice( sides: 12, generator: LinearCongruentialGenerator() )
print( diceAgain1.asText() )

let diceAgain2 = Dice( sides: 10, generator: LinearCongruentialGenerator() )
print( diceAgain2.asText() )


// Adding Protocol Conformance with an Extension To Existing Class
extension SnakesAndLadders: TextRepresentable {
    var textualDescription: String { 
    	return "SnakesAndLadders Game:"
    }

	func asText() -> String {
		return "A Snakes And Ladders Game With: \(finalSquare)"
	}
}

print( snakesAndLaddersGame.asText() )


struct Decoit {
	var name: String

    var textualDescription: String { 
    	return "Decoit:"
    }

	func asText() -> String {
		return "A Dacoit Named \(name)"
	}
}

// Adding Protocol Conformance with an Extension To Existing Structure
extension Decoit: TextRepresentable {}

let gabbarDakku = Decoit( name: "Gabbar Singh" )
let somethingTextRepresentable: TextRepresentable = gabbarDakku
print( somethingTextRepresentable.asText() )

//___________________________________________________________
// 
// Conditionally Conforming to a Protocol
//___________________________________________________________


/**
extension Array: TextRepresentable where Element: TextRepresentable {

	func asText() -> String {
		return "Array Dummy Code..."
	}

	var textualDescription: String {
		let itemsAsText = self.map { $0.textualDescription } 
		return "[" + itemsAsText.joined( seperator: ", " ) + "]"
	}
}


let myDice = [dice, diceAgain1, diceAgain2]
print( myDice.textualDescription )
*/


//___________________________________________________________
// 
// Adopting a Protocol Using a Synthesized Implementation
//___________________________________________________________


// Swift can automatically provide the protocol conformance for 
// Equatable, Hashable, and Comparable in many simple cases. 
// Using this synthesized implementation means you don’t have to 
// write repetitive boilerplate code to implement the protocol requirements yourself.

// Swift provides a synthesized implementation of Equatable for the following kinds of custom types:

// Structures that have only stored properties that conform to the Equatable protocol
// Enumerations that have only associated types that conform to the Equatable protocol
// Enumerations that have no associated types

struct Vector3D: Equatable {
	var x = 0.0, y = 0.0, z = 0.0
}

let first3D 	= Vector3D( x: 2.0, y: 3.0, z: 4.0 )
let second3D 	= Vector3D( x: 3.0, y: 3.0, z: 3.0 )
let third3D 	= Vector3D( x: 2.0, y: 3.0, z: 4.0 )

print( first3D )
print( second3D )

if first3D == second3D {
	print( "Two Vectors Are Equal! ")
} else {
	print( "Two Vectors Are UnEqual! ")
}

if first3D == third3D {
	print( "Two Vectors Are Equal! ")
} else {
	print( "Two Vectors Are UnEqual! ")
}


//___________________________________________________________
// 
// Collections Of Protocol Types
//___________________________________________________________


let things: [TextRepresentable] = [dice, diceAgain1, diceAgain2, snakesAndLaddersGame, gabbarDakku] 
print( things )

for thing in things {
	print( thing.asText() ) 
}


//___________________________________________________________
//
// Protocol Of Protocols
//___________________________________________________________

protocol SomeOnceMoreProtocol: SomeProtocol, AnotherProtocol {
    // protocol definition goes here
}

protocol PrettyTextRepresentable : TextRepresentable {
	var prettyTextualDescription: String { get }
}

extension SnakesAndLadders : PrettyTextRepresentable {
	var prettyTextualDescription: String {
		var output = textualDescription + ":\n"

		for index in 1...finalSquare {
			switch board[ index ] {
			case let ladder where ladder > 0:
				output += "=="

			case let snake where snake < 0:
				output += "~~"

			default:
				output += "--"
			}
		}

		return output
	}

}

print( snakesAndLaddersGame.prettyTextualDescription )

//___________________________________________________________
//
// Comparable Enumerations
//___________________________________________________________

// enum SkillLevel {
enum SkillLevel: Comparable {
	case Beginner
	case Intermediate
	case Expert( stars: Int )
}

var levels: [SkillLevel] = [ .Intermediate, .Beginner, .Expert( stars : 5 ), .Expert( stars: 3) ]
print( levels )

// error: referencing instance method 'sorted()' on 'Sequence' 
// requires that 'SkillLevel' conform to 'Comparable'
var sortedLevels = levels.sorted() 
print( sortedLevels )


//___________________________________________________________
//
// Class Only Protocols
//___________________________________________________________

protocol SomeClassOnlyProtocol : AnyObject, SomeOnceMoreProtocol {
	// This Is Class Only Protocol
}

//___________________________________________________________
//___________________________________________________________

protocol Named {
    var name: String { get }
}

protocol Aged {
    var age: Int { get }
}

struct PersonAgain: Named, Aged {
    var name: String
    var age: Int
}

// Following Function Takes Object Of 
//	Type Which Is Both Named As Well As Aged
//	i.e.  Type Which Is Comforming Both Named As Well As Aged Protocol
func wishHappyBirthday(to celebrator: Named & Aged) {
    print("Happy birthday, \(celebrator.name), you're \(celebrator.age)!")
}

let birthdayPerson = PersonAgain(name: "Malcolm", age: 21)
wishHappyBirthday(to: birthdayPerson)


//___________________________________________________________
//___________________________________________________________

class Location {
    var latitude: Double
    var longitude: Double
    init(latitude: Double, longitude: Double) {
        self.latitude = latitude
        self.longitude = longitude
    }
}

class City: Location, Named {
    var name: String
    init(name: String, latitude: Double, longitude: Double) {
        self.name = name
        super.init(latitude: latitude, longitude: longitude)
    }
}

func beginConcert(in location: Location & Named ) {
    print("Hello, \(location.name)!")
}


let seattle = City(name: "Seattle", latitude: 47.6, longitude: -122.3)
beginConcert(in: seattle)


//___________________________________________________________
//___________________________________________________________

protocol HasArea {
    var area: Double { get }
}

class Circle: HasArea {
    let pi = 3.1415927
    var radius: Double
    var area: Double { return pi * radius * radius }
    init(radius: Double) { self.radius = radius }
}

class Country: HasArea {
    var area: Double
    init(area: Double) { self.area = area }
}

class Animal {
    var legs: Int
    init(legs: Int) { self.legs = legs }
}

let objects: [AnyObject] = [
    Circle(radius: 2.0),
    Country(area: 243_610),
    Animal(legs: 4)
]

for object in objects {
	if let objectWithArea = object as? HasArea {
		print("Area : ", objectWithArea.area )
	} else {
		print("Some Objects Doesn't Have Areas")
	}
}

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

