
//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftGenerics.swift -o generics

Command To Run Code
./generics
*/
//___________________________________________________________


//___________________________________________________________
//
// WRITING STACK
//___________________________________________________________

struct IntStack {
	var items = [Int]()

	mutating func push( item: Int ) {
		items.append( item )
	}

	mutating func pop() -> Int {
		return items.removeLast()
	}
}

struct StringStack {
	var items = [String]()

	mutating func push( item: String ) {
		items.append( item )
	}

	mutating func pop() -> String {
		return items.removeLast()
	}
}

struct DoubleStack {
	var items = [Double]()

	mutating func push( item: Double ) {
		items.append( item )
	}

	mutating func pop() -> Double {
		return items.removeLast()
	}
}

struct HumanStack {
	var items = [Human]()

	mutating func push( item: Human ) {
		items.append( item )
	}

	mutating func pop() -> Human {
		return items.removeLast()
	}
}

//_________________________________

var stackIntegers: IntStack = IntStack()

stackIntegers.push( item: 10 )
stackIntegers.push( item: 20 )
stackIntegers.push( item: 22 )
stackIntegers.push( item: 99 )

print( stackIntegers.pop() )
print( stackIntegers.pop() )
print( stackIntegers.pop() )
print( stackIntegers.pop() )

// error: cannot convert value of type 'String' to expected argument type 'Int'

//_________________________________

var stackStrings = StringStack()

stackStrings.push( item: "Hello" )
stackStrings.push( item: "World" )
stackStrings.push( item: "Great" )

print( stackStrings.pop() )
print( stackStrings.pop() )
print( stackStrings.pop() )

//_________________________________

var stackDoubles = DoubleStack()

stackDoubles.push( item: 90.90 )
stackDoubles.push( item: 70.70 )
stackDoubles.push( item: 80.80 )

print( stackDoubles.pop() )
print( stackDoubles.pop() )
print( stackDoubles.pop() )

//_________________________________

struct Human {
	var id: Int
	var name: String
}

var stackHuman = HumanStack()

stackHuman.push( item: Human( id: 420, name: "Gabbar Singh") )
stackHuman.push( item: Human( id: 100, name: "Basanti") )
stackHuman.push( item: Human( id: 300, name: "Veeru") )
stackHuman.push( item: Human( id: 200, name: "Jay") )

print( stackHuman.pop() )
print( stackHuman.pop() )
print( stackHuman.pop() )
print( stackHuman.pop() )

//___________________________________________________________
//
// GENERICS
//___________________________________________________________

// Generics or Templates
//		Code Which Generates Code At Compile Time

//	T Is Type Type Placeholder
//		It Will Be Sustituted With Type Specified By Programmer At Compile Time

struct Stack<T> {
	var items = [T]()

	mutating func push( item: T ) {
		items.append( item )
	}

	mutating func pop() -> T {
		return items.removeLast()
	}
}

//_________________________________

// Programmer Is Specifying T To Be Int Type
//		Hence Compiler Will Substitute Int At Place Of T Type Placeholder
//		And Generate Corresponding After Substituting T Type Placeholder

var stackIntegersAgain = Stack<Int>()

stackIntegersAgain.push( item: 10 )
stackIntegersAgain.push( item: 20 )
stackIntegersAgain.push( item: 22 )
stackIntegersAgain.push( item: 99 )

print( stackIntegersAgain.pop() )
print( stackIntegersAgain.pop() )
print( stackIntegersAgain.pop() )
print( stackIntegersAgain.pop() )

//_________________________________

// Programmer Is Specifying T To Be String Type
//		Hence Compiler Will Substitute Int At Place Of T Type Placeholder
//		And Generate Corresponding After Substituting T Type Placeholder

var stackStringsAgain = Stack<String>()

stackStringsAgain.push( item: "Hello" )
stackStringsAgain.push( item: "World" )
stackStringsAgain.push( item: "Great" )

print( stackStringsAgain.pop() )
print( stackStringsAgain.pop() )
print( stackStringsAgain.pop() )

//_________________________________

// Programmer Is Specifying T To Be Double Type
//		Hence Compiler Will Substitute Int At Place Of T Type Placeholder
//		And Generate Corresponding After Substituting T Type Placeholder


var stackDoublesAgain = Stack<Double>()

stackDoublesAgain.push( item: 90.90 )
stackDoublesAgain.push( item: 70.70 )
stackDoublesAgain.push( item: 80.80 )

print( stackDoublesAgain.pop() )
print( stackDoublesAgain.pop() )
print( stackDoublesAgain.pop() )


//_________________________________

// Programmer Is Specifying T To Be Human Type
//		Hence Compiler Will Substitute Int At Place Of T Type Placeholder
//		And Generate Corresponding After Substituting T Type Placeholder


var stackHumansAgain = Stack<Human>()

stackHumansAgain.push( item: Human( id: 420, name: "Gabbar Singh") )
stackHumansAgain.push( item: Human( id: 100, name: "Basanti") )
stackHumansAgain.push( item: Human( id: 300, name: "Veeru") )
stackHumansAgain.push( item: Human( id: 200, name: "Jay") )

print( stackHumansAgain.pop() )
print( stackHumansAgain.pop() )
print( stackHumansAgain.pop() )
print( stackHumansAgain.pop() )

//_________________________________

// Programmer Is Specifying T To Be (Int, Int) Type
//		Hence Compiler Will Substitute Int At Place Of T Type Placeholder
//		And Generate Corresponding After Substituting T Type Placeholder

var stackCoordinates = Stack<(Int, Int)>()
print( stackCoordinates )

stackCoordinates.push( item: (10, 10) )
stackCoordinates.push( item: (0, 0) )
stackCoordinates.push( item: (99, 88) )
stackCoordinates.push( item: ( -5, -6) )

print( stackCoordinates.pop() )
print( stackCoordinates.pop() )
print( stackCoordinates.pop() )
print( stackCoordinates.pop() )


//___________________________________________________________
//___________________________________________________________

func swapTwoInts( first: inout Int, second: inout Int ) {
	let temporary = first
	first = second
	second = temporary
}

func swapTwoStrings( first: inout String, second: inout String ) {
	let temporary = first
	first = second
	second = temporary
}

var firstInt = 88
var secondInt = 99

print( firstInt, secondInt )

swapTwoInts( first: &firstInt, second: &secondInt )
print( firstInt, secondInt )


var firstString = "Hello"
var secondString = "Hi"

print( firstString, secondString )

swapTwoStrings( first: &firstString, second: &secondString )
print( firstString, secondString )


func  swapping<T>( first: inout T, second: inout T ) {
	let temporary = first
	first = second
	second = temporary
}

swapping( first: &firstInt, second: &secondInt )
print( firstInt, secondInt )

swapping( first: &firstString, second: &secondString )
print( firstString, secondString )

//___________________________________________________________
//
// TYPE CONSTRAINTS IN GENERICS
//___________________________________________________________

class SomeClass {

}

protocol SomeProtocol {

}

// There Are Two PlaceHolders T and U
//		Here T Can Be Instance Of SomeClass Or SomeClass Subclasses
//		and U Can Be Instance Of Type Which Comforms To SomeProtocol

func someFunction<T: SomeClass, U: SomeProtocol>( someT: T, someU: U ) {

}

//___________________________________________________________
//___________________________________________________________

// There Is One PlaceHolder T
//		T Can Be Instance Of Type Which Comforms To Equatable

func findIndex<T : Equatable>( of valueToFind: T, in array: [T] ) -> Int? {
	for ( index, value ) in array.enumerated() {
		if value == valueToFind {
			return index
		}
	}

	return nil
}

let doubleArray: [Double] = [10.10, 20.02, 10.20, 90.90, 100.1, 10.11 ]
let doubleIndex = findIndex( of: 90.90, in: doubleArray )

print( doubleIndex ?? "Doesn't Exists" )


let names = ["Ding", "Dong", "Ting", "Tong"]
let nameIndex = findIndex( of: "Ting", in: names )
print( nameIndex ?? "Doesn't Exists" )

let nameIndex1 = findIndex( of: "Zing", in: names )
print( nameIndex1 ?? "Doesn't Exists" )


//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________


