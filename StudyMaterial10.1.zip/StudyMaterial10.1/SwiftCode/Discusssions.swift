//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________


[11:05] jitendra sharma  (HCL Financial Services), Gurgaon

// DEFINITION OF TYPE IS MESSED UP

// In Mind Returning Mathematical Integer ( Z )
// In Actual Returns Swift Int
func sum (first: Int, second: Int) -> Int {
	return first + second
}

[11:06] Keerthan N
func sum(first: Int, second: Int)-> Int{
    return first  + second
}

[11:06] Basvana Bhavana
func sum(first: Int, second: Int)-> Int{   let total = first + second  return total}


[11:06] jitendra sharma  (HCL Financial Services), Gurgaon

int sum (int first, int second){

	return first + second

}
[11:07] Dileep Kumar Gade

int sum(int first, int second) {

[11:07] Dileep Kumar Gade
    return first+ second

[11:09] Matre Akshay Dilansing

func sum(first:Int, second:Int) -> Int{
    return first + second
}

[11:09] Akhila Arupula
func sum(first: Int, second: Int) -> Int {

    return first + second

}

[11:15] 
Amarjit Singh (Guest) no longer has access to the chat.

[11:16] 
Amarjit Singh (Guest) has temporarily joined the chat.


//___________________________________________________________
//___________________________________________________________

// DESIGN 02
// Write Following Sum Function Code In C/Swift with Given Signature
    // It Should Return Valid Arithematic Sum 
    //      Otherwise 
    // Print Can't Calculate Sum Of Given Values

// Write Following Sum Function Code In C with Given Signature
    int sum( int first, int second) {

    }

// Write Following Sum Function Code In Swift with Given Signature

    func sum( first: Int, second: Int ) -> Int {

    }



[11:22] Matre Akshay Dilansing

// Wrong Direction
func validSum(first:Int, second:Int) -> Int{
 
    if first >= 0 && second >= 0 {
        return first + second
    }else{
        print("Error : Sum is invalid")
        return 0
    }
}


[11:30] Basvana Bhavana

// Wrong Direction

func sum(first: Int, second: Int)-> Int{   

    if first>=0 && second >= 0 {

            return first + second

    } else {
         print("Can't calculate Sum of Given values")                        
         return 0

    }

}

[11:31] Dileep Kumar Gade

func Sum(first:Int,  second:Int)  {
 
    if first >= 0 && second >= 0 {
        return first + second
    } else{
        print(" Sum is invalid")
        return 0
    }
}

[11:32] Keerthan N

// Signature Itself Changed
// Wrong Direction
func calculatesum( _ value: Int.. ) {
    if value.count ==2 {
    
    let sum = values.reduce(0, +)
        print("sum: \(sum)")}
    else {
        print("can't calculate) } 
}

calculatesum(2, 3)


[11:32] Akhila Arupula

// Wrong Logic
// DEFINITION OF TYPE IS MESSED UP
// Closure Law Is Not Understood
func sum(first: Int, second: Int) -> Int? {

   let result: Int  = first + second

   // ALWAYS TRUE CONDITION WHICH FOLLOWS CLOSURE LAW
   // if-else Condition Is Always Going To TRUE
   if result >= Int.min && result <= Int.max {
        // Thinking It's Valid Result
       return result
   } else { // NEVER EXECUTE
       print("Can't calculate sum of given values")
       return 0
   }

}

[11:37] jitendra sharma  (HCL Financial Services), Gurgaon

// Wrong Direction
func sum (first: Int, second: Int) -> Int {
    var sum: Int = 0

    do{ 
        try sum = first + second
        return sum
    } catch {
        print("Overflow error")

    }
}

//___________________________________________________________
//___________________________________________________________

/*
// Write Following Sum Function Code In C with Given Signature
    int sum( int first, int second) {

    }


// Write Following Sum Function Code In Swift with Given Signature

    func sum( first: Int, second: Int ) -> Int {

    }
*/


// Write Following Sum Function Code In Swift with Given Signature

// DESIGN 01
// What Is The Challenge With This Design?
//      It Has Overflow/Underflow Issues?

    func sum( first: Int, second: Int ) -> Int {
        return first + second
    }


//___________________________________________________________
//___________________________________________________________


// DESIGN 03
// Write Following Sum Function Code In C/Swift with Given Signature
    // It Should Return Valid Arithematic Sum 
    //      Otherwise 
    // Print Can't Calculate Sum Of Given Values

// Write Following Sum Function Code In C with Given Signature
    int sum( int first, int second) {

    }

// Write Following Sum Function Code In Swift with Given Signature

    func sum( first: Int, second: Int ) -> Int {

    }

//___________________________________________________________
//___________________________________________________________


[12:28] jitendra sharma  (HCL Financial Services), Gurgaon

int sumDesign(int first, int second) {

    int result = 0;
 
    if (first <= 0){

        if ((INT_MIN - first) > second || (second <= INT_MAX) ){
            printf("\nCan't Calcualte Sum Of Given Values\n");
        }

    }
 
    if (first > 0){
        if ((second >= INT_MIN  ) || (second > (INT_MAX - first) )){
            printf("\nCan't Calcualte Sum Of Given Values\n");
        }

    }
 
    return first + second;

}

[12:37] jitendra sharma  (HCL Financial Services), Gurgaon
Kindly consider this

[12:37] jitendra sharma  (HCL Financial Services), Gurgaon
int sumDesign(int first, int second) {

    int result = 0;
 
    if (first <= 0){

        if ((INT_MIN - first) > second || (second > INT_MAX) ){
            printf("\nCan't Calcualte Sum Of Given Values\n");
        }

    }
 
    if (first > 0){

        if ((second < INT_MIN   ) || (second > (INT_MAX - first) )){

            printf("\nCan't Calcualte Sum Of Given Values\n");

        }

    }
 
    return first + second;

}

//___________________________________________________________
//___________________________________________________________

QUESTION 02: WHAT IS DATA TYPE???

[14:53] Amarjit Singh (Guest)
QUESTION 02: WHAT IS DATA TYPE???

[14:54] Dileep Kumar Gade
data type is specifies the size 

Size???

[14:55] jitendra sharma  (HCL Financial Services), Gurgaon
Data Type is (meta )information about the data

What Is Meta Information???


[14:55] Basvana Bhavana

Data Type is the type of value  a variable or constant has

Type???

[14:55] Keerthan N
which tells what type of data we are storing in variable

Type???

[14:56] Matre Akshay Dilansing
data type is specifies that which type of value a variable can hold
 
Type???
 
[14:57] Akhila Arupula
a data type is a classification of a variable or constant that defines the type of data that can hold

Classification???
Type???


//___________________________________________________________

[14:59] Keerthan N
type means entity of the object

What Is Entity, Object, Instance????


[15:00] Matre Akshay Dilansing
type means category of data that stored 

Category????

[15:00] jitendra sharma  (HCL Financial Services), Gurgaon
meta information is attributes of data. like if data is a 

number or text or bool, 
Examples Of Data Type?

what would be its min or max size ????

++++ Its min or max Values

[15:01] Dileep Kumar Gade
size means the memory stored by variables like int has 2 or 4 bytes

Size???

[15:02] Basvana Bhavana

type means is it of  

numbers(int, float) or the data is of type text(string) or the data is of type logical(bool)
Examples Of Data Type???


[15:03] Akhila Arupula
classification refers to the process of organizing different kinds of data based on their characters

Classification???
Kinds???


[15:03] jitendra sharma  (HCL Financial Services), Gurgaon
meta information is attributes of data. like if data is a number or text or bool, 
what would be its min or max size. Also it indicates how data should be handled.

Handling???



//___________________________________________________________

QUESTION 03: WHAT AN OBJECT ORIENTED PROGRAMMING?
//___________________________________________________________

[15:39] Amarjit Singh (Guest)
QUESTION 03: WHAT AN OBJECT ORIENTED PROGRAMMING?

[15:41] Keerthan N
which creates a object which contains data and methods to manipulate the data

Encapsulation

[15:42] Dileep Kumar Gade
which contain data and code 

Encapsulation

[15:43] Basvana Bhavana
OOPs is a programming concept which is based on objects which contain data and operation/ procedure

Encapsulation


[15:44] jitendra sharma  (HCL Financial Services), Gurgaon
Object oriented programming is to consider all subjects as an object that 
carry its attributes and capabilities along with it (embedded) and 
program is nothing but 

Encapsulation

++++ Interaction between these objects

Inheritance
    For Reusability

Abstraction
Polymoprhism

[15:45] Akhila Arupula
OOPs is a programming concept which is based on objects which contain data or operations

Encapsulation


[15:46] Matre Akshay Dilansing
OOPs is a programmming concept  is based on object which contains data and methods

Encapsulation

//___________________________________________________________

QUETION 04: WHAT IS ALL FOLLOWING?

//___________________________________________________________

Abstraction? :
Encapsulation? :
Inheritance? : 
Polymoprhism? : 

//___________________________________________________________

[15:51] Amarjit Singh (Guest)

WHAT IS ALL FOLLOWING?
 
Abstraction? :
Encapsulation? :
Inheritance? : 
Polymoprhism? : 

[15:55] jitendra sharma  (HCL Financial Services), Gurgaon

Abstraction : Revealing only Essentials and hiding trivals
    Hiding State/Data

Encapsulation: Embed attributes and behaviour in itself
        

Inheritance: Inherit all attributes and behaviour from its parent
    Purpose : Resuse

Polymorphism: One thing many forms

[15:57] Basvana Bhavana

Abstraction? : It only shows functionality and it hides the background details
    
Encapsulation? :wrapping data and code into a single unit
    
Inheritance? : an object acquires properties of parent object

Polymoprhism? : if the task is performed in more than one form


[15:58] Dileep Kumar Gade
Abstraction? : showing only neccessary 3functionallities  

Encapsulation? :  integrating the variables and methods into a single unit 

Inheritance? :  acquires the properties of one class to another

Polymoprhism? : performing single action in different ways

[15:58] Akhila Arupula
Abstraction: Focusing on essential qualities while ignoring unnecessary details

Encapsulation : Bundling data and methods that operate on the data into a single unit

Inheritance : Allowing a class to inherit properties and behaviors from another class

Polymoprhism : Polymorphism allows objects of different types to be treated as objects of a common type and simplifying code

[15:59] Keerthan N
Abstraction?  it shows functionality of the program and hide details in background

Encapsulation? : binds data and methods together in a class and we can call using specific method

Inheritance? : it allows child class to call methods from parent class

Polymoprhism? :  it allows the method to use in different objects 


[16:01] Matre Akshay Dilansing
Abstraction -
    the process to hide the internal mechanism
Encapsulation -
    the process to bundle the data and method that works on the data within the object
Inheritance -
    Inherit the parent with its behviour


//___________________________________________________________
//___________________________________________________________

WHAT IS STRUCTURED PROGRAMMING?

//___________________________________________________________
//___________________________________________________________


[16:52] Keerthan N
which organize the code in sequential structure for readability and maintain

[16:54] Matre Akshay Dilansing
It is the idea to organizing code in well structured and easily understandable blocks 
to improve and maintain clarity, quality and efficiency

[16:55] Dileep Kumar Gade
it means the code execute the instruction by instruction one after another


[16:55] Basvana Bhavana
It is a creation of program with readable code 

[16:56] jitendra sharma  (HCL Financial Services), Gurgaon
structured programming follows a protocol/rules/template


//___________________________________________________________
// IN OBJECTIVE-C
//___________________________________________________________
// - Means Instance Member Function
// + Means Type Member Function
// In Objective C
// Function Defintion
//      Function Signature
//          setTitle:forState:
//          As Many : That Many Arguments

// SomeClass Declaration Write in .h File
@interface SomeClass 
    //  Instance Member Function Defintion
    - (void) setTitle:(NSString *)title forState:(UIControlState)state;

@end

// SomeClass Definition Write in .m/.c/.cc/.cpp File
@implementation SomeClass 
    //  Instance Member Function Defintion
    - (void) setTitle:(NSString *)title forState:(UIControlState)state {
        // Here Your Logic Goes
    }
@end

// In Objective C
//  Message To A Object Along Payload

SomeClass someObject = [ [ SomeClass alloc ] init ];
[ someObject setTitle: title forState: state ]

//____________________________________________
// IN C++/JAVA/C#
//____________________________________________

// In C++/Java/C#
// SomeClass Definition
class SomeClass {
    //  Instance Member Function Defintion
    void setTitleForState( NSString * title, UIControlState state ) {
        // Here Your Logic Goes
    }
}

// In C++/Java/C#
//  Function Call

SomeClass someObject = new SomeClass();

// Function Call
//      It's NOT Function Call
//      It's Sending setTitleForState Message To someObject
//          with Payload (title, state )
someObject.setTitleForState( title, state );

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________

