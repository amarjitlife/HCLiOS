class Room2 {
	let name: String
	init(name: String){self.name = name}
}

class Address2 {
	var nation: String = "India"
	var buildingName: String?
	var buildingNumber: String?
	var street: String?

	func buildingIdentifier() -> String? {
		if (buildingName != nil) {return buildingName}
		else if (buildingNumber != nil) {return buildingNumber}
		else {return nil}
	}

}

class Residence2 {
	var rooms = [Room2]()
	var address: Address2?

	var numberOfRooms: Int {
		return rooms.count
	}

	subscript(index: Int) -> Room2 {
		return rooms[index]
	}

	func printNumberOfRooms(){
		print ("Room Count: ", numberOfRooms)
	}
}

class Person2 {
	var residence: Residence2?
}

let gabbar = Person2()

if let nation = gabbar.residence?.address?.nation {
	print(nation)
} else {
	print ("Gabbar Dont Have residence")
}

