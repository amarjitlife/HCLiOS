
//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftOperators.swift -o operators

Command To Run Code
./operators
*/
//___________________________________________________________

//___________________________________________________________
//___________________________________________________________

// Bitwise Not Operator
let initialBits: UInt8 = 0b00001111
let invertedBits = ~initialBits  // equals 11110000

// Bitwise And Operator
let firstSixBits: UInt8 = 0b11111100
let lastSixBits: UInt8  = 0b00111111
let middleFourBits = firstSixBits & lastSixBits  // equals 00111100

let someBits: UInt8 = 0b10110010
let moreBits: UInt8 = 0b01011110
let combinedbits = someBits | moreBits  // equals 11111110

let firstBits: UInt8 = 0b00010100
let otherBits: UInt8 = 0b00000101
let outputBits = firstBits ^ otherBits  // equals 00010001

//___________________________________________________________


let shiftBits: UInt8 = 4   // 00000100 in binary
shiftBits << 1             // 00001000
shiftBits << 2             // 00010000
shiftBits << 5             // 10000000
shiftBits << 6             // 00000000
shiftBits >> 2             // 00000001

let pink: UInt32 = 0xCC6699
let redComponent = (pink & 0xFF0000) >> 16    // redComponent is 0xCC, or 204
let greenComponent = (pink & 0x00FF00) >> 8   // greenComponent is 0x66, or 102
let blueComponent = pink & 0x0000FF  


//___________________________________________________________

var potentialOverflow = Int16.max
// potentialOverflow equals 32767, which is the maximum value an Int16 can hold

// Overflow/Underflow Aware + Operator
// potentialOverflow += 1
// this causes an error

// Not Overflow/Underflow Aware &+ Operator
potentialOverflow &+= 1

//___________________________________________________________
//___________________________________________________________

struct Vector2D {
	var x = 0.0, y = 0.0
}

extension Vector2D {
	static func + ( left: Vector2D, right: Vector2D ) -> Vector2D {
		let xx = left.x + right.x
		let yy = left.y + right.y

		return Vector2D( x: xx, y: yy )
	}
}

let vector1 = Vector2D( x: 2.0, y: 3.0 )
let vector2 = Vector2D( x: 4.0, y: 7.0 )

print( vector1 )
print( vector2 )

let vector3 = vector1 + vector2
print( vector3 )

extension Vector2D {
	static func - ( left: Vector2D, right: Vector2D ) -> Vector2D {
		let xx = left.x - right.x
		let yy = left.y - right.y

		return Vector2D( x: xx, y: yy )
	}
}

let vector4 = vector1 - vector2
print( vector4 )

// Compound Assignment Operator
//	x += 1 meand x = x + 1

// It is not possible to overload the default assignment operator (=). 
// Only the Compound Assignment operators can be overloaded. 
// Similarly, the ternary conditional operator (a ? b : c) cannot be overloaded.

extension Vector2D {
    static func += (left: inout Vector2D, right: Vector2D) {
        left = left + right
    }
}

var original = Vector2D(x: 1.0, y: 2.0)
let vectorToAdd = Vector2D(x: 3.0, y: 4.0)
original += vectorToAdd
// original now has values of (4.0, 6.0)


extension Vector2D: Equatable {

    static func == (left: Vector2D, right: Vector2D) -> Bool {
       return (left.x == right.x) && (left.y == right.y)
    }
}

let twoThree = Vector2D(x: 2.0, y: 3.0)
let anotherTwoThree = Vector2D(x: 2.0, y: 3.0)

if twoThree == anotherTwoThree {
    print("These two vectors are equivalent.")
}
// Prints "These two vectors are equivalent."



// CUSTOM OPERATORS
// Custom Operators

// Custom operators can be defined only with the characters 
// 			= - + * / % < > ! & | ^ . ~

prefix operator +++

extension Vector2D {
   
    static prefix func +++ (vector: inout Vector2D) -> Vector2D {
        vector += vector
        return vector
    }
}


var toBeDoubled = Vector2D(x: 1.0, y: 4.0)
let afterDoubling = +++toBeDoubled
// toBeDoubled now has values of (2.0, 8.0)
// afterDoubling also has values of (2.0, 8.0)

//___________________________________________________________
//___________________________________________________________

// Precedence and Associativity for Custom Infix Operators

infix operator +- : AdditionPrecedence

extension Vector2D {
	static func +- ( left: Vector2D, right: Vector2D ) -> Vector2D {
		let xx = left.x + right.y
		let yy = left.x - right.y

		return Vector2D( x: xx, y: yy )
	}
}

let vector11 = Vector2D( x: 2.0, y: 3.0 )
let vector22 = Vector2D( x: 4.0, y: 7.0 )

print( vector11 )
print( vector22 )

let vector33 = vector11 +- vector22
print( vector33 )


//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
