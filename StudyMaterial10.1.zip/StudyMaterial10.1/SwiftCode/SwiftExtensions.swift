
//___________________________________________________________
/*
Command To Compile Code
swiftc SwiftExtensions.swift -o extensions

Command To Run Code
./extensions
*/
//___________________________________________________________


//___________________________________________________________
//
// EXTENSIONS
//___________________________________________________________

// Extensions1
//		Used To Add Functionality To Exisiting Types

// Extensions add new functionality to an existing class, structure, 
// enumeration, or protocol type. This includes the ability to extend 
// types for which you don’t have access to the original source code 

// Extensions in Swift can:
//     Add computed instance properties and computed type properties
//     Define instance methods and type methods
//     Provide new initializers
//     Define subscripts
//     Define and use new nested types
//     Make an existing type conform to a protocol

// In Swift, you can even extend a protocol to provide implementations of 
// its requirements or add additional functionality that conforming types 
// can take advantage of. 

// Extension Syntaxin page link
//     Declare extensions with the extension keyword:

//      extension SomeType {
//          // new functionality to add to SomeType goes here
//      }

        // extension SomeType: SomeProtocol, AnotherProtocol {
        //     // implementation of protocol requirements goes here
        // }


//___________________________________________________________
//
// Adding Computed Properties Using Computed Properties
//___________________________________________________________

// Adding Computed Properties To Double Type Using Extensions

extension Double {
	// Computed Properties
    var km: Double 	{ return self * 1_000.0 }
    var m:  Double 	{ return self }
    var cm: Double 	{ return self / 100.0 }
    var mm: Double 	{ return self / 1_000.0 }
    var ft: Double 	{ return self / 3.28084 }
}

let oneInch = 25.4.mm
print("One inch is \(oneInch) meters")

let threeFeet = 3.ft
print("Three feet is \(threeFeet) meters")

let aMarathon = 42.km + 195.m
print("A marathon is \(aMarathon) meters long")


//___________________________________________________________
//
// Adding Initialisers Using Extensions
//___________________________________________________________


struct Size {
    var width = 0.0, height = 0.0
}

struct Point {
    var x = 0.0, y = 0.0
}

struct Rectangle {
    var origin = Point()
    var size = Size()
}

let defaultRect = Rectangle()
let memberwiseRect = Rectangle(origin: Point(x: 2.0, y:2.0), size: Size(width: 5.0, height: 5.0))
print( defaultRect )
print( memberwiseRect )

// Adding Initialisers To Rectangle Type Using Extensions 
// NOTE :
//  If you provide a new initializer with an extension, 
//  you are still responsible for making sure that each instance 
//  is fully initialized once the initializer completes.

extension Rectangle {
	init( center: Point, size: Size ) {
        let originX = center.x - (size.width / 2)
        let originY = center.y - (size.height / 2)
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}

let centerRect = Rectangle(center: Point(x: 4.0, y: 4.0), size: Size(width: 3.0, height:3.0))
print( centerRect )


//___________________________________________________________
//
//  Adding Methods Using Extensions
//___________________________________________________________

// Extensions can add new instance methods and 
//      type methods to existing types.


extension Int {
    func repetitions( task: () -> Void ) {
        for _ in 0..<self {
            task()
        }
    }
}


2.repetitions( task: { print("Good Morning!") } )

// Trailing Lambda Syntax
2.repetitions { 
    print("Good Morning!!!") 
}

// Trailing Lambda Syntax
5.repetitions { 
    print("Hello!") 
}


//___________________________________________________________
// 
// Mutating Instance Methods
//___________________________________________________________

// Instance methods added with an extension can also modify 
// (or mutate) the instance itself. Structure and enumeration 
// methods that modify self or its properties must mark the 
// instance method as mutating, just like mutating methods 
// from an original implementation.

extension Int {
    mutating func square() {
        self = self * self
    }
}

var someInt = 3

print( someInt )
someInt.square()
print( someInt )

var someInt1 = 5

print( someInt1 )
someInt1.square()
print( someInt1 )


//___________________________________________________________
//
// Adding Subscripts Using Extensions
//___________________________________________________________

// Subscripts
// Extensions can add new subscripts to an existing type.

extension Int {
    // Subscript Operator Used To Specify Digit Place From RHS
    subscript( digitIndex: Int ) -> Int {
        var decimalBase = 1
        
        for _ in 0..<digitIndex {
            decimalBase *= 10
        }

        return ( self / decimalBase ) % 10
    }

}

var digit: Int

digit = 9876567890123[0]
print( digit )

digit = 9876567890123[1]
print( digit )

digit = 9876567890123[2]
print( digit )

digit = 9876567890123[7]
print( digit )

digit = 9876567890123[8]
print( digit )

digit = 9876567890123[9]
print( digit )


//___________________________________________________________
//
// Adding NEsted Types Using Extensions
//___________________________________________________________

// Nested Types

// Extensions can add new nested types to existing classes, 
// structures, and enumerations

extension Int {
    // Nested Enumeration Type
    enum Kind {
        case negative, zero, positive
    }

    var kind: Kind {
        switch self {
            case 0:
                return .zero
            case let x where x > 0:
                return .positive
            default:
                return .negative
        }
    }
}


func printIntergerKinds( numbers: [Int] ) {
    for number in numbers {
        switch number.kind {
        case .negative:
            print("_ ", terminator: "")
        
        case .zero:
            print("0 ", terminator: "")
        
        case .positive:
            print("+ ", terminator: "")

        }
    }
    print("")
}

printIntergerKinds( numbers: [10, 20, -10, -20, 0, 11, 99, 0, 88, -88])
printIntergerKinds( numbers: [1, 0, -1, -2, 0, 1, 9, 0, 0, -8])

//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________
//___________________________________________________________


