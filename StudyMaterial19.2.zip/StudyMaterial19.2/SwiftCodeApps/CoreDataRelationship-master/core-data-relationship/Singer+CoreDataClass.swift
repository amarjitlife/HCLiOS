//
//  Singer+CoreDataClass.swift
//  CoreDataRelationship
//
//  Created by Megi Sila on 2.5.22.
//  Copyright © 2022 Megi Sila. All rights reserved.
//

import Foundation
import CoreData

@objc(Singer)
public class Singer: NSManagedObject {

}
