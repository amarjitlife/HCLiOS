# SwiftUICalculator

SwiftUI 实现的计算器

<img width="25%" height="25%" src="screenShots/1.png"/> <img width="50%" height="50%" src="screenShots/2.png"/>

## Requirements

* Xcode 11 Beta
* Swift 5.1
* iOS 13.0
